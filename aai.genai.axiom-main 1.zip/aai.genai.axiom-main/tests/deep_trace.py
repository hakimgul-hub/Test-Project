import os
import json
from datetime import datetime

# --- CONFIG ---
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "Data") if os.path.exists(os.path.join(PROJECT_ROOT, "Data")) else os.path.join(PROJECT_ROOT, "data")

def load_json(path):
    try:
        with open(path, 'r') as f: return json.load(f)
    except: return None

def trace_data_flow():
    print(f"🕵️  STARTING DEEP DATA TRACE")
    print(f"📂  Root: {DATA_DIR}\n")

    # 1. FIND TEACHER FILES
    teacher_dir = os.path.join(DATA_DIR, "Teacher")
    if not os.path.exists(teacher_dir): return print("❌ Teacher folder missing.")

    found_chains = 0

    for root, _, files in os.walk(teacher_dir):
        for t_file in files:
            if not t_file.endswith(".json") or not t_file.startswith("Teacher_"): continue
            
            # --- LEVEL 1: TEACHER ---
            t_path = os.path.join(root, t_file)
            t_data = load_json(t_path)
            if not t_data: continue
            
            questions = t_data.get("question_set", {}).get("turns", [])
            if not questions: continue # Skip empty files

            print(f"🔹 [TEACHER] Found: {t_file}")
            print(f"    └── ID: {t_data.get('run_id')} | Qs: {len(questions)}")
            print(f"    └── Data Check: Q1='{questions[0].get('question')[:30]}...' | Expect='{str(questions[0].get('expected_answer'))[:30]}...'")

            # --- LEVEL 2: LOOK FOR MATCHING EXAMINER ---
            # We look for an Examiner file that references this Teacher file
            examiner_dir = os.path.join(DATA_DIR, "Examiner")
            e_match = None
            e_data = None

            for e_root, _, e_files in os.walk(examiner_dir):
                for e_file in e_files:
                    if not e_file.endswith(".json"): continue
                    path = os.path.join(e_root, e_file)
                    data = load_json(path)
                    
                    # LINKAGE CHECK: Does this file reference the Teacher file?
                    if data and data.get("source_file") == t_file:
                        e_match = e_file
                        e_data = data
                        break # Found the pair
                    
                    # FALLBACK LINKAGE: Check if run_id matches (older versions)
                    if data and data.get("source_l1_artifact") == t_file:
                        e_match = e_file
                        e_data = data
                        break

            if e_match:
                print(f"    ✅ [EXAMINER] Matched: {e_match}")
                results = e_data.get("results", [])
                print(f"       └── Data Check: Student Answer Present? { 'YES' if results and 'student_answer' in results[0] else 'NO' }")
                if results and 'student_answer' in results[0]:
                    print(f"       └── Sample: '{results[0].get('student_answer')[:40]}...'")
                
                # --- LEVEL 3: LOOK FOR MATCHING JUDGE ---
                judge_dir = os.path.join(DATA_DIR, "Judge")
                j_match = None
                
                for j_root, _, j_files in os.walk(judge_dir):
                    for j_file in j_files:
                        if not j_file.endswith(".json"): continue
                        path = os.path.join(j_root, j_file)
                        data = load_json(path)
                        
                        # LINKAGE CHECK
                        if data and data.get("examiner_file") == e_match:
                            j_match = j_file
                            # Deep check of score
                            verdict = data.get("results", [{}])[0].get("judge_verdict", {})
                            print(f"       ✅ [JUDGE] Matched: {j_match}")
                            print(f"          └── Score: {verdict.get('score')}/10")
                            print(f"          └── Reasoning: {str(verdict.get('reasoning'))[:50]}...")
                            found_chains += 1
                            break
                
                if not j_match:
                    print(f"       ❌ [JUDGE] Missing. (Run evaluation on {e_match})")
            else:
                print(f"    ❌ [EXAMINER] Missing. (Run exam on {t_file})")
            
            print("-" * 40)
            if found_chains >= 3: break # Stop after finding 3 full chains to avoid spam

    if found_chains == 0:
        print("\n⚠️  No complete chains (Teacher->Examiner->Judge) found.")
        print("    Try running the full pipeline on one file to test.")

if __name__ == "__main__":
    trace_data_flow()