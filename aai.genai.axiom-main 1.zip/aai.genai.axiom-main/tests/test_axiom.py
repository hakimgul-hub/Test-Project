# Layer 1 smoke test. Run from repo root: python -m pytest tests/test_axiom.py -v
# or: PYTHONPATH=. python tests/test_axiom.py
from src.axiom_core.layer1_teacher.brains import OpenSourceTeacher, PremiumTeacher
from src.axiom_core.layer1_teacher.strategies import CoraAdasStrategy, OmniLegisStrategy
from src.axiom_core.layer1_teacher.generator import GoldenDatasetGenerator

def run_test():
    print("--- 🛡️ STARTING AXIOM LAYER 1 TEST ---")
    
    USE_PREMIUM = False
    INDUSTRY = "AUTOMOTIVE"

    if USE_PREMIUM:
        brain = PremiumTeacher(api_key="secret")
    else:
        brain = OpenSourceTeacher()

    if INDUSTRY == "AUTOMOTIVE":
        strategy = CoraAdasStrategy()
    else:
        strategy = OmniLegisStrategy()

    axiom = GoldenDatasetGenerator(brain, strategy)

    dummy_text = """
    The Automated Lane Keeping System (ALKS) shall not operate at speeds exceeding 60 km/h.
    If the driver does not take over after 10 seconds, a Minimum Risk Maneuver (MRM) is initiated.
    """
    axiom.inject_source_material(dummy_text)

    exam = axiom.create_exam()
    
    print("\n--- 📄 GENERATED EXAM ---")
    print(exam)

if __name__ == "__main__":
    run_test()
