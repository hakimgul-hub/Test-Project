import os
import json
from datetime import datetime

# --- CONFIGURATION: SMART PATH FINDER ---
# This looks 1 level up from "tests/" to find the Project Root
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)

# Check for "Data" or "data" (case-sensitive systems)
if os.path.exists(os.path.join(PROJECT_ROOT, "Data")):
    DATA_DIR = os.path.join(PROJECT_ROOT, "Data")
elif os.path.exists(os.path.join(PROJECT_ROOT, "data")):
    DATA_DIR = os.path.join(PROJECT_ROOT, "data")
else:
    # Fallback: Maybe we are already in root?
    if os.path.exists("Data"): DATA_DIR = "Data"
    elif os.path.exists("data"): DATA_DIR = "data"
    else:
        print(f"❌ CRITICAL ERROR: Could not find 'Data' folder at {PROJECT_ROOT}")
        exit(1)

print(f"📂 Target Data Directory: {DATA_DIR}")

def validate_timestamp(ts, filename):
    """Scientific check: Is the timestamp a valid ISO string?"""
    if isinstance(ts, (int, float)):
        print(f"❌ FAIL: {filename} has a numeric timestamp: {ts}")
        return False
    try:
        datetime.fromisoformat(ts)
        return True
    except ValueError:
        print(f"❌ FAIL: {filename} has invalid ISO format: {ts}")
        return False

def check_layer(layer_name):
    print(f"\n🔍 Scanning Layer: {layer_name}...")
    layer_path = os.path.join(DATA_DIR, layer_name)
    
    if not os.path.exists(layer_path):
        print(f"⚠️ Warning: Folder {layer_name} does not exist at {layer_path}")
        return []

    valid_files = []
    # Walk through all subfolders (Discovery, Project, SingleDoc, etc.)
    for root, _, files in os.walk(layer_path):
        for f in files:
            if f.endswith(".json"):
                full_path = os.path.join(root, f)
                try:
                    with open(full_path, 'r') as file_obj:
                        data = json.load(file_obj)
                        
                        # 1. Check ID existence
                        if "run_id" not in data and "session_id" not in data:
                            print(f"   🔸 Note: {f} missing 'run_id' (might be old format)")
                        
                        # 2. Check Timestamp (The cause of your recent crashes)
                        ts = data.get("created_at") or data.get("timestamp")
                        
                        if ts:
                            if validate_timestamp(ts, f):
                                valid_files.append(f)
                        else:
                            print(f"   ⚠️ Warn: {f} missing timestamp field")

                except json.JSONDecodeError:
                    print(f"   ❌ FAIL: {f} is corrupted JSON")
                except Exception as e:
                    print(f"   ❌ ERROR reading {f}: {str(e)}")

    print(f"✅ {len(valid_files)} valid artifacts found in {layer_name}")
    return valid_files

# EXECUTE CHECKS
print("🧪 STARTING DATA INTEGRITY AUDIT")
print("================================")
t_files = check_layer("Teacher")
e_files = check_layer("Examiner")
j_files = check_layer("Judge")

total = len(t_files) + len(e_files) + len(j_files)
print("\n" + "="*30)
print(f"🎉 Audit Complete. Total Valid Files: {total}")
print("If you see any ❌ FAIL messages above, delete those specific files.")
