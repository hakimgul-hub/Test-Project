# API-level tests (run from repo root with PYTHONPATH=. or pytest)
