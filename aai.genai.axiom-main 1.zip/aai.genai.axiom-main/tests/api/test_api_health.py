# Run from repo root: PYTHONPATH=. pytest tests/api/test_api_health.py -v
"""Smoke tests for API (no server required if using TestClient)."""
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)


def test_health_via_testclient():
    """Test root and config endpoints using FastAPI TestClient (no live server)."""
    from fastapi.testclient import TestClient
    from src.axiom_core.api.main import app
    client = TestClient(app)
    r = client.get("/")
    assert r.status_code == 200
    data = r.json()
    assert data.get("status") == "AXIOM Core Online"
    assert "version" in data


def test_config_layer1():
    from fastapi.testclient import TestClient
    from src.axiom_core.api.main import app
    client = TestClient(app)
    r = client.get("/config/layer1")
    assert r.status_code == 200
    data = r.json()
    assert "strategies" in data or "personas" in data
