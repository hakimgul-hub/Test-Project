# Run from repo root: PYTHONPATH=. python -m pytest tests/api/test_teacher_layer.py -v
# Or: PYTHONPATH=. python tests/api/test_teacher_layer.py
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

import requests
import json
import time

CONFIG_NAMES = [
    "test_teacher_config.json",
    "src/config/test_teacher_config.json",
    os.path.join(_REPO_ROOT, "test_teacher_config.json"),
    os.path.join(_REPO_ROOT, "src/config/test_teacher_config.json"),
]


def load_config():
    for path in CONFIG_NAMES:
        p = path if os.path.isabs(path) else os.path.join(_REPO_ROOT, path)
        if os.path.exists(p):
            with open(p, "r") as f:
                return json.load(f)
    raise FileNotFoundError(f"Config not found. Tried: {CONFIG_NAMES}")


def run_test_scenario(name, payload, base_url):
    url = f"{base_url}/generate"
    try:
        start_time = time.time()
        resp = requests.post(url, json=payload, timeout=300)
        duration = round(time.time() - start_time, 2)
        if resp.status_code == 200:
            data = resp.json()
            assert "filename" in data or "data" in data
            return True
        return False
    except Exception:
        return False


def test_teacher_single_doc():
    """Requires API running and config file."""
    try:
        config = load_config()
    except FileNotFoundError:
        import pytest
        pytest.skip("test_teacher_config.json not found")
        return
    common = config.get("common", {})
    scenarios = config.get("scenarios", {})
    base_url = config.get("base_url", "http://localhost:8000")
    api_common = {**common, "count": common.get("density", common.get("count", 3)), "models": common.get("models", ["local_llama3"])}
    s = scenarios.get("single_doc", {})
    if not s.get("enabled"):
        import pytest
        pytest.skip("single_doc scenario disabled")
        return
    payload = {
        **api_common,
        "context": "ISO 26262 is the functional safety standard for road vehicles. It defines ASIL levels A through D.",
        "source_metadata": {"source_type": s.get("source_type", "single_doc"), "id": s.get("doc_id")},
    }
    ok = run_test_scenario("Single Document", payload, base_url)
    assert ok, "Teacher single_doc scenario failed"


if __name__ == "__main__":
    config = load_config()
    common = config["common"]
    scenarios = config["scenarios"]
    base_url = config["base_url"]
    api_common = common.copy()
    api_common.setdefault("count", 3)
    api_common.setdefault("models", ["local_llama3"])
    if scenarios.get("single_doc", {}).get("enabled"):
        payload = {**api_common, "context": "ISO 26262 functional safety. ASIL A-D.", "source_metadata": {"source_type": "single_doc"}}
        run_test_scenario("Single Document", payload, base_url)
