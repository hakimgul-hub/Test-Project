/**
 * API base URL for the AXIOM backend.
 * Set VITE_API_URL in .env (e.g. VITE_API_URL=http://localhost:8000) to override.
 */
export const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";
