import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

// SAFETY NET: If the app crashes, show the error here instead of white screen
class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false, error: null }; }
  static getDerivedStateFromError(error) { return { hasError: true, error }; }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{padding: '40px', background: '#fee2e2', color: '#b91c1c', fontFamily: 'monospace'}}>
          <h1>💥 CRITICAL FRONTEND CRASH</h1>
          <h3>{this.state.error.toString()}</h3>
          <p>Check your browser console (F12) for the exact file line number.</p>
        </div>
      );
    }
    return this.props.children; 
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>,
)