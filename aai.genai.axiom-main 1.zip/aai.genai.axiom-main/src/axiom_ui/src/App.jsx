import { useState, useEffect } from 'react';
import './styles/App.css';

// DEBUG LOGS
console.log("🚀 App.jsx is loading...");

// Lazy load components to isolate the crash
import Sidebar from './components/Sidebar';
import TeacherTab from './components/TeacherTab';
import ExaminerTab from './components/ExaminerTab';
import InterrogatorTab from './components/InterrogatorTab';
import JudgeTab from './components/JudgeTab';
import EvaluationTab from './components/EvaluationTab';
import SettingsTab from './components/SettingsTab'; 

// ✅ IMPORT NEW DOCS COMPONENTS
import UserDocs from './components/UserDocs';
import DevDocs from './components/DevDocs';

console.log("✅ All components imported successfully.");

export default function App() {
  const [activeTab, setActiveTab] = useState('teacher');
  const [error, setError] = useState(null);

  useEffect(() => {
    console.log(`🔄 Active Tab Changed to: ${activeTab}`);
  }, [activeTab]);

  return (
    <div id="root">
      {/* Sidebar controls the 'activeTab' state */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="main">
        {/* Render Tabs Conditionally with Error Catching */}
        {activeTab === 'teacher' && <TeacherTab />}
        {activeTab === 'examiner' && <ExaminerTab />}
        {activeTab === 'interrogator' && <InterrogatorTab />}
        {activeTab === 'judge' && <JudgeTab onGradingComplete={() => setActiveTab('evaluation')} />}
        {activeTab === 'evaluation' && <EvaluationTab />}
        {activeTab === 'settings' && <SettingsTab />}
        
        {/* ✅ RENDER NEW DOCS */}
        {activeTab === 'user_docs' && <UserDocs />}
        {activeTab === 'dev_docs' && <DevDocs />}
      </div>
    </div>
  );
}