import React from 'react';
import { BookOpen, Search, Zap, Gavel, Activity, Share2 } from 'lucide-react';

export default function UserDocs() {
  return (
    <div className="animate-fade" style={{padding: '40px', maxWidth: '1000px', margin: '0 auto', overflowY: 'auto', height: '100%'}}>
      
      {/* HEADER */}
      <div style={{textAlign: 'center', marginBottom: '50px'}}>
        <h1 style={{fontSize: '2.5rem', color: '#1e293b', marginBottom: '10px'}}>AXIOM User Guide</h1>
        <p style={{fontSize: '1.2rem', color: '#64748b'}}>Scientific Verification & Validation (V-Model) for GenAI Certification.</p>
      </div>

      {/* THE V-MODEL */}
      <div className="card" style={{marginBottom: '40px', padding: '30px', borderLeft: '5px solid #3b82f6'}}>
        <h2 style={{marginTop: 0, color: '#1e3a8a'}}>The V-Model Methodology</h2>
        <p style={{lineHeight: '1.6', color: '#334155'}}>
          The AXIOM platform implements the rigorous <strong>V-Model</strong> lifecycle used in safety-critical systems engineering. 
          It mathematically proves that the AI (Layer 3) understands the "Digital Twin" of knowledge (Layer 1) created by the Teacher.
        </p>
        <div style={{background: '#f8fafc', padding: '20px', borderRadius: '10px', marginTop: '20px', textAlign: 'center'}}>
           <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', maxWidth: '600px', margin: '0 auto', fontSize: '0.9rem', fontWeight: 'bold'}}>
              <div style={{textAlign: 'center'}}>
                  <div style={{background: '#dbeafe', padding: '10px', borderRadius: '8px', marginBottom: '10px'}}>Layer 1: Teacher (Knowledge)</div>
                  <div style={{color: '#94a3b8'}}>↓</div>
                  <div style={{background: '#dbeafe', padding: '10px', borderRadius: '8px', marginBottom: '10px'}}>Layer 2: Examiner (Tests)</div>
              </div>
              <div style={{fontSize: '2rem', color: '#cbd5e1'}}>➤</div>
              <div style={{textAlign: 'center'}}>
                  <div style={{background: '#dcfce7', padding: '10px', borderRadius: '8px', marginBottom: '10px'}}>Layer 4: Judge (Verification)</div>
                  <div style={{color: '#94a3b8'}}>↑</div>
                  <div style={{background: '#fef3c7', padding: '10px', borderRadius: '8px', marginBottom: '10px'}}>Layer 3: Student (AI)</div>
              </div>
           </div>
        </div>
      </div>

      {/* COMPONENT DEFINITIONS */}
      <h2 style={{borderBottom: '1px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px'}}>System Components</h2>
      
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '40px'}}>
        <div className="card">
          <h3 style={{display: 'flex', alignItems: 'center', gap: '10px', color: '#3b82f6'}}>
            <BookOpen size={20}/> 1. The Teacher
          </h3>
          <p style={{fontSize: '0.9rem', color: '#475569'}}>
            The <strong>Source of Truth</strong>. The Teacher ingests raw documents (PDFs, Standards, Regulations) and organizes them into a structured curriculum. It does not hallucinate; it only knows what is in the documents.
          </p>
        </div>

        <div className="card">
          <h3 style={{display: 'flex', alignItems: 'center', gap: '10px', color: '#8b5cf6'}}>
            <Search size={20}/> 2. The Examiner
          </h3>
          <p style={{fontSize: '0.9rem', color: '#475569'}}>
            The <strong>Question Generator</strong>. Using the Teacher's knowledge, the Examiner creates difficult exam questions ("Golden Datasets") with known correct answers (Ground Truth).
          </p>
        </div>

        <div className="card">
          <h3 style={{display: 'flex', alignItems: 'center', gap: '10px', color: '#f59e0b'}}>
            <Zap size={20}/> 2a. The Interrogator
          </h3>
          <p style={{fontSize: '0.9rem', color: '#475569'}}>
            The <strong>Viva Voce Interface</strong>. Unlike a static exam, the Interrogator conducts a live, dynamic interview. It probes the user's depth of knowledge by asking follow-up questions based on previous answers.
          </p>
        </div>

        <div className="card">
          <h3 style={{display: 'flex', alignItems: 'center', gap: '10px', color: '#ef4444'}}>
            <Gavel size={20}/> 4. The Judge
          </h3>
          <p style={{fontSize: '0.9rem', color: '#475569'}}>
            The <strong>Evaluator</strong>. The Judge compares the Student's answers against the Examiner's Ground Truth. It is impartial and uses a strict rubric to assign a Pass/Fail grade.
          </p>
        </div>
      </div>

      {/* THE 4D FRAMEWORK */}
      <div className="card" style={{marginBottom: '40px', borderTop:'4px solid #7c3aed'}}>
          <h2 style={{marginTop: 0, color: '#4c1d95', display:'flex', alignItems:'center', gap:'10px'}}>
              <Activity size={24}/> The 4-Dimensional (4D) Evaluation Framework
          </h2>
          <p style={{color:'#475569', marginBottom:'20px'}}>
              AXIOM evaluates AI performance across four orthogonal dimensions, ensuring a holistic certification that goes beyond simple "correctness."
          </p>
          
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'20px'}}>
              <div style={{background:'#eff6ff', padding:'15px', borderRadius:'8px'}}>
                  <div style={{fontWeight:'bold', color:'#1e3a8a', marginBottom:'5px'}}>1. Factual Accuracy (The "What")</div>
                  <div style={{fontSize:'0.9rem', color:'#334155'}}>Does the answer align strictly with the Ground Truth established by Layer 2? Measured via vector similarity and logical entailment.</div>
              </div>
              <div style={{background:'#f5f3ff', padding:'15px', borderRadius:'8px'}}>
                  <div style={{fontWeight:'bold', color:'#5b21b6', marginBottom:'5px'}}>2. Grounding (The "Source")</div>
                  <div style={{fontSize:'0.9rem', color:'#334155'}}>Is every claim supported by a citation? Prevents hallucinations by verifying references against the source text (RAGAS approach).</div>
              </div>
              <div style={{background:'#fff7ed', padding:'15px', borderRadius:'8px'}}>
                  <div style={{fontWeight:'bold', color:'#9a3412', marginBottom:'5px'}}>3. Completeness (The "Scope")</div>
                  <div style={{fontSize:'0.9rem', color:'#334155'}}>Did the AI miss any critical details? Uses "Recall" metrics to ensure 100% of the required information is present.</div>
              </div>
              <div style={{background:'#f0fdf4', padding:'15px', borderRadius:'8px'}}>
                  <div style={{fontWeight:'bold', color:'#166534', marginBottom:'5px'}}>4. Safety & Alignment (The "Guardrails")</div>
                  <div style={{fontSize:'0.9rem', color:'#334155'}}>Does the AI refuse out-of-scope or harmful prompts? Ensures compliance with operational boundaries.</div>
              </div>
          </div>
      </div>

      {/* SCIENTIFIC METRICS TABLE */}
      <h2 style={{borderBottom: '1px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px'}}>
          Scientific KPIs & Methodology
      </h2>
      <div className="card" style={{padding: '0', overflow: 'hidden', marginBottom:'40px'}}>
        <table style={{width: '100%', borderCollapse: 'collapse'}}>
          <thead style={{background: '#f1f5f9'}}>
            <tr>
              <th style={{padding: '15px', textAlign: 'left', color: '#475569', width: '15%'}}>Metric</th>
              <th style={{padding: '15px', textAlign: 'left', color: '#475569', width: '30%'}}>Definition</th>
              <th style={{padding: '15px', textAlign: 'left', color: '#475569', width: '40%'}}>Scientific Methodology</th>
              <th style={{padding: '15px', textAlign: 'left', color: '#475569', width: '15%'}}>Target</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{borderBottom: '1px solid #e2e8f0'}}>
              <td style={{padding: '15px', fontWeight: 'bold', color: '#2563eb'}}>Accuracy</td>
              <td style={{padding: '15px', color: '#334155'}}>Factual alignment with Ground Truth.</td>
              <td style={{padding: '15px', color: '#64748b', fontSize: '0.9rem'}}>
                <strong>G-Eval / GPT-Score:</strong> Using an LLM-as-a-Judge to grade semantic equivalence.<br/>
                <strong>Vector Similarity:</strong> Cosine distance of embeddings (e.g., OpenAI text-embedding-3).
              </td>
              <td style={{padding: '15px', color: '#16a34a'}}>&gt; 90%</td>
            </tr>
            <tr style={{borderBottom: '1px solid #e2e8f0'}}>
              <td style={{padding: '15px', fontWeight: 'bold', color: '#7c3aed'}}>Grounding</td>
              <td style={{padding: '15px', color: '#334155'}}>Absence of hallucinations.</td>
              <td style={{padding: '15px', color: '#64748b', fontSize: '0.9rem'}}>
                <strong>RAGAS Faithfulness:</strong> Checks if distinct claims in the answer can be inferred from the retrieved context.<br/>
                <strong>Citation Check:</strong> Verifies reference links exist in source.
              </td>
              <td style={{padding: '15px', color: '#16a34a'}}>100%</td>
            </tr>
            <tr style={{borderBottom: '1px solid #e2e8f0'}}>
              <td style={{padding: '15px', fontWeight: 'bold', color: '#d97706'}}>Completeness</td>
              <td style={{padding: '15px', color: '#334155'}}>Coverage of required details.</td>
              <td style={{padding: '15px', color: '#64748b', fontSize: '0.9rem'}}>
                <strong>Information Retrieval (Recall):</strong> The ratio of key entities (Entities_Found / Entities_Total) extracted from Ground Truth.
              </td>
              <td style={{padding: '15px', color: '#16a34a'}}>&gt; 80%</td>
            </tr>
            <tr>
              <td style={{padding: '15px', fontWeight: 'bold', color: '#dc2626'}}>Safety</td>
              <td style={{padding: '15px', color: '#334155'}}>Refusal of harmful prompts.</td>
              <td style={{padding: '15px', color: '#64748b', fontSize: '0.9rem'}}>
                <strong>Binary Classification:</strong> Strict check against predefined "Jailbreak" and "Injection" patterns.
              </td>
              <td style={{padding: '15px', color: '#16a34a'}}>100%</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* REFERENCES */}
      <div className="card" style={{background:'#f8fafc', border:'1px solid #e2e8f0'}}>
          <h3 style={{marginTop:0, fontSize:'1.1rem', color:'#334155', display:'flex', alignItems:'center', gap:'10px'}}>
              <Share2 size={18}/> Scientific References
          </h3>
          <ul style={{fontSize:'0.9rem', color:'#475569', paddingLeft:'20px', lineHeight:'1.8'}}>
              <li>
                  <strong>[1] RAGAS (2023):</strong> "Automated Evaluation of Retrieval Augmented Generation." 
                  <span style={{color:'#64748b'}}> Basis for our Grounding and Faithfulness metrics.</span>
              </li>
              <li>
                  <strong>[2] G-Eval (2023):</strong> "NLG Evaluation using GPT-4 with Better Human Alignment." 
                  <span style={{color:'#64748b'}}> Methodology for using LLM-as-a-Judge (Layer 4).</span>
              </li>
              <li>
                  <strong>[3] JudgeLLM (2023):</strong> "Fine-tuning Large Language Models for Scalable Evaluation." 
                  <span style={{color:'#64748b'}}> Supports our approach of using specialized models for grading.</span>
              </li>
              <li>
                  <strong>[4] Chain-of-Verification (CoVe):</strong> "Reducing Hallucinations in Large Language Models." 
                  <span style={{color:'#64748b'}}> Technique used by Layer 2 to generate verified Ground Truth.</span>
              </li>
          </ul>
      </div>

      {/* FUTURE ROADMAP */}
      <h2 style={{borderBottom: '1px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px', marginTop: '40px', color: '#64748b'}}>
          🚀 Coming Next: Advanced Certification
      </h2>

      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px'}}>
          <div className="card" style={{borderLeft: '4px solid #f43f5e'}}>
              <h3 style={{marginTop:0, color:'#be123c'}}>5. Adversarial Red Teaming</h3>
              <p style={{color:'#475569', fontSize:'0.9rem'}}>
                  <strong>Objective:</strong> Proactively attack the model to find vulnerabilities rather than waiting for failure.<br/>
                  <strong>Methodology:</strong> Automated "Attacker LLMs" will generate edge-case inputs (e.g., prompt injections, ambiguous logic) to test the Student's robustness under pressure.
              </p>
          </div>

          <div className="card" style={{borderLeft: '4px solid #8b5cf6'}}>
              <h3 style={{marginTop:0, color:'#6d28d9'}}>6. Human-in-the-Loop (HITL) Calibration</h3>
              <p style={{color:'#475569', fontSize:'0.9rem'}}>
                  <strong>Objective:</strong> Verify the Judge itself.<br/>
                  <strong>Methodology:</strong> A feedback mechanism where human experts can review and "override" the AI Judge's verdict. This data is then used to fine-tune the Judge model (RLHF), increasing the confidence level of automated scoring.
              </p>
          </div>

          <div className="card" style={{borderLeft: '4px solid #0891b2'}}>
              <h3 style={{marginTop:0, color:'#0e7490'}}>7. Longitudinal Regression Testing</h3>
              <p style={{color:'#475569', fontSize:'0.9rem'}}>
                  <strong>Objective:</strong> Ensure new model versions do not forget old knowledge.<br/>
                  <strong>Methodology:</strong> Automatically re-running the "Golden Dataset" every time the system is updated. If the Accuracy score drops by &gt;2% on the historical baseline, the update is flagged as a regression.
              </p>
          </div>

          <div className="card" style={{borderLeft: '4px solid #ca8a04'}}>
              <h3 style={{marginTop:0, color:'#a16207'}}>8. Bias & Fairness Quantification</h3>
              <p style={{color:'#475569', fontSize:'0.9rem'}}>
                  <strong>Objective:</strong> Detect statistical skew in responses.<br/>
                  <strong>Methodology:</strong> Running the model against counterfactual datasets (e.g., changing names/genders in the prompt) and measuring the variance in the generated answer's sentiment and utility.
              </p>
          </div>
      </div>

    </div>
  );
}