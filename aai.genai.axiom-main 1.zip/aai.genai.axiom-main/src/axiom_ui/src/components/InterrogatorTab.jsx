import { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, FileText, Globe, Folder, UploadCloud, 
  Send, Bot, Database, Plus, Trash2, X, Play, StopCircle, RefreshCw, 
  Cpu, Brain, BookOpen, Link as LinkIcon, ChevronDown, ChevronUp, Image as ImageIcon
} from 'lucide-react';

import { API_BASE } from '../api';

// --- SUB-COMPONENT FOR CHUNK ---
const EvidenceChunk = ({ chunk }) => {
    const [expanded, setExpanded] = useState(false);
    
    // Check type from backend (Chunk vs Link)
    const isLink = chunk.type === "Link";
    
    // Safety check for null text
    const text = chunk.text || chunk.chunk_text || "";
    const hasImage = !!chunk.image;
    
    // Truncation logic
    const shortText = text.substring(0, 150);
    const isLong = text.length > 150;

    // RENDER LINK
    if (isLink) {
        return (
            <div style={{background:'#f0fdf4', padding:'8px', borderRadius:'6px', marginBottom:'6px', borderLeft:'3px solid #22c55e'}}>
                <div style={{fontWeight:'bold', color:'#166534', fontSize:'0.75rem', marginBottom:'4px', display:'flex', alignItems:'center', gap:'5px'}}>
                    <LinkIcon size={12}/> {chunk.doc_name}
                </div>
                <a 
                    href={text.replace('URL: ', '')} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    style={{fontSize:'0.8rem', color:'#2563eb', textDecoration:'underline', wordBreak:'break-all'}}
                >
                    {text}
                </a>
            </div>
        );
    }

    // RENDER TEXT CHUNK
    return (
        <div style={{background:'rgba(0,0,0,0.03)', padding:'8px', borderRadius:'6px', marginBottom:'6px', borderLeft:'3px solid #cbd5e1'}}>
            <div style={{fontWeight:'bold', color:'#334155', fontSize:'0.75rem', marginBottom:'4px', display:'flex', justifyContent:'space-between'}}>
                <span style={{display:'flex', alignItems:'center', gap:'5px'}}>
                    <BookOpen size={12}/> {chunk.doc_name} {chunk.page ? `(Page ${chunk.page})` : ''}
                </span>
                {hasImage && <ImageIcon size={12} color="#f59e0b"/>}
            </div>
            
            {/* TEXT CONTENT */}
            {text && (
                <div style={{fontSize:'0.8rem', color:'#475569', fontStyle:'italic', lineHeight:'1.4', whiteSpace:'pre-wrap'}}>
                    "{expanded ? text : shortText}{isLong && !expanded && "..."}"
                </div>
            )}

            {/* IMAGE CONTENT (Base64 or URL) */}
            {hasImage && (
                <div style={{marginTop:'8px', textAlign:'center'}}>
                    <img 
                        src={chunk.image.startsWith('http') ? chunk.image : `data:image/png;base64,${chunk.image}`} 
                        alt="Evidence" 
                        style={{maxWidth:'100%', maxHeight:'200px', borderRadius:'4px', border:'1px solid #e2e8f0'}} 
                    />
                </div>
            )}

            {/* TOGGLE */}
            {isLong && (
                <button 
                    onClick={() => setExpanded(!expanded)}
                    style={{background:'none', border:'none', color:'#3b82f6', fontSize:'0.7rem', cursor:'pointer', padding:'0', marginTop:'4px', display:'flex', alignItems:'center', gap:'2px'}}
                >
                    {expanded ? <><ChevronUp size={10}/> Show Less</> : <><ChevronDown size={10}/> Show Full Text</>}
                </button>
            )}
        </div>
    );
};

export default function InterrogatorTab() {
  const [mode, setMode] = useState('single_doc'); 
  const [models, setModels] = useState([]);
  const [selectedModel, setSelectedModel] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [libraryResults, setLibraryResults] = useState([]);
  const [selectedDoc, setSelectedDoc] = useState(null); 
  const [projectDocs, setProjectDocs] = useState([]);   
  const [discoveryTopic, setDiscoveryTopic] = useState("");
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionContext, setSessionContext] = useState(null);
  const [chatHistory, setChatHistory] = useState([]);
  const [question, setQuestion] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const chatEndRef = useRef(null);
  const [isAutoMode, setIsAutoMode] = useState(false);
  const [isRunningAuto, setIsRunningAuto] = useState(false);
  const [maxTurns, setMaxTurns] = useState(10); 
  const [turnCount, setTurnCount] = useState(0);

  useEffect(() => {
    fetch(`${API_BASE}/config/llms`)
      .then(r => r.json())
      .then(data => {
          setModels(data);
          const preferred = data.find(m => m.id.includes("llama3") || m.id.includes("haiku"));
          if(data.length > 0) setSelectedModel(preferred ? preferred.id : data[0].id);
      })
      .catch(console.error);
  }, []);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [chatHistory, isThinking]);

  useEffect(() => {
      if (isRunningAuto && !isThinking && isSessionActive) {
          if (turnCount < maxTurns) {
              const timeout = setTimeout(() => { triggerAutoTurn(); }, 2000); 
              return () => clearTimeout(timeout);
          } else {
              setIsRunningAuto(false);
              setChatHistory(prev => [...prev, { role: 'system', content: `✅ Viva Voce Complete (${maxTurns} turns).` }]);
          }
      }
  }, [isRunningAuto, isThinking, turnCount, isSessionActive]);

  const triggerAutoTurn = async () => {
      setIsThinking(true);
      try {
          const historyPayload = chatHistory.map(m => ({ role: m.role, content: m.content || "" }));
          const genRes = await fetch(`${API_BASE}/interrogator/generate_question`, {
              method: 'POST', headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ chat_history: historyPayload, model_id: selectedModel, doc_title: selectedDoc?.title || "the context" })
          });
          const genData = await genRes.json();
          const nextQ = genData.question;
          const reasoning = genData.reasoning;

          setChatHistory(prev => [...prev, { role: 'user', content: nextQ, isAuto: true, reasoning: reasoning }]);

          const chatRes = await fetch(`${API_BASE}/interrogator/chat`, {
              method: 'POST', headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ session_context: sessionContext, question: nextQ, model_id: selectedModel, examiner_grounding: reasoning })
          });
          const chatData = await chatRes.json();

          setChatHistory(prev => [...prev, { 
              role: 'assistant', 
              content: chatData.answer_text,
              // ✅ FIXED MAPPING: Use 'links' from backend
              citations: chatData.links || [],
              grounding: chatData.clean_grounding || []
          }]);
          setTurnCount(prev => prev + 1);
      } catch (err) {
          setChatHistory(prev => [...prev, { role: 'error', content: "Auto-Examiner Error: " + err.message }]);
          setIsRunningAuto(false);
      } finally { setIsThinking(false); }
  };

  const handleLibrarySearch = async () => {
    if(!searchQuery) return;
    try {
        const res = await fetch(`${API_BASE}/interrogator/library/search?q=${searchQuery}`);
        setLibraryResults(await res.json());
    } catch(err) { alert(err.message); }
  };

  const selectSingleDoc = (doc) => { setSelectedDoc(doc); setLibraryResults([]); setSearchQuery(""); };
  const addProjectDoc = (doc) => { if (!projectDocs.find(d => d.id === doc.id)) setProjectDocs([...projectDocs, doc]); setLibraryResults([]); setSearchQuery(""); };
  const removeProjectDoc = (id) => { setProjectDocs(prev => prev.filter(d => d.id !== id)); };
  
  const handleStartSession = async () => {
      setChatHistory([]); setIsThinking(true); setTurnCount(0);
      const payload = { mode: mode, model_id: selectedModel };
      if (mode === 'single_doc' || mode === 'user_doc') payload.doc_id = selectedDoc?.id;
      if (mode === 'project') payload.doc_ids = projectDocs.map(d => d.id);
      if (mode === 'discovery') payload.topic_text = discoveryTopic;

      try {
          const res = await fetch(`${API_BASE}/interrogator/start`, {
              method: 'POST', headers: {'Content-Type': 'application/json'},
              body: JSON.stringify(payload)
          });
          const data = await res.json();
          if (res.status !== 200) throw new Error(data.detail || "Failed to start");
          setSessionContext(data.session_context);
          setIsSessionActive(true);
          let info = mode === 'single_doc' ? `Document: ${selectedDoc.title}` : mode === 'project' ? `Project: ${projectDocs.length} docs` : "Discovery Mode";
          
          if (mode === 'discovery' && discoveryTopic) {
             setChatHistory([{ role: 'user', content: discoveryTopic }]);
             setTimeout(() => sendFirstDiscoveryMsg(data.session_context, discoveryTopic), 500);
          } else {
             setChatHistory([{ role: 'system', content: `✅ Viva Voce Active\nCONTEXT: ${info}\n\nCandidate Ready.` }]);
             if (isAutoMode) setIsRunningAuto(true);
          }
      } catch (err) { alert("Error: " + err.message); } finally { setIsThinking(false); }
  };

  const sendFirstDiscoveryMsg = async (ctx, topic) => {
      setIsThinking(true);
      try {
          const res = await fetch(`${API_BASE}/interrogator/chat`, {
              method: 'POST', headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ session_context: ctx, question: topic, model_id: selectedModel })
          });
          const data = await res.json();
          setChatHistory(prev => [...prev, { 
              role: 'assistant', 
              content: data.answer_text, 
              // ✅ FIXED MAPPING
              citations: data.links || [], 
              grounding: data.clean_grounding || [] 
          }]);
          if (isAutoMode) setIsRunningAuto(true);
      } catch(e) { setChatHistory(prev => [...prev, { role: 'error', content: e.message }]); } finally { setIsThinking(false); }
  };

  const handleSend = async () => {
      if (!question.trim() || !sessionContext) return;
      const q = question; setQuestion("");
      setChatHistory(prev => [...prev, { role: 'user', content: q }]);
      setIsThinking(true);
      try {
          const res = await fetch(`${API_BASE}/interrogator/chat`, {
              method: 'POST', headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ session_context: sessionContext, question: q, model_id: selectedModel })
          });
          const data = await res.json();
          setChatHistory(prev => [...prev, { 
              role: 'assistant', 
              content: data.answer_text, 
              // ✅ FIXED MAPPING
              citations: data.links || [], 
              grounding: data.clean_grounding || [] 
          }]);
      } catch (err) { setChatHistory(prev => [...prev, { role: 'error', content: "Error: " + err.message }]); } finally { setIsThinking(false); }
  };

  const handleKeyPress = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } };

  return (
    <div className="animate-fade" style={{height: '100%', display: 'flex', flexDirection: 'column'}}>
      <header className="header" style={{flexShrink: 0}}><h1>Layer 2a: The Interrogator (Viva)</h1></header>

      {!isSessionActive ? (
          <div className="card" style={{maxWidth: '800px', margin: '20px auto', width: '100%'}}>
              <h3>🎤 Session Setup</h3>
              <div style={{display: 'flex', gap: '10px', marginBottom: '20px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px'}}>
                {['single_doc', 'discovery', 'project', 'user_doc'].map(m => (
                    <button key={m} onClick={() => setMode(m)} className={`btn btn-sub ${mode === m ? 'active' : ''}`} style={{textTransform:'capitalize'}}>{m.replace('_', ' ')}</button>
                ))}
              </div>
              <div style={{minHeight: '150px'}}>
                  {(mode === 'single_doc' || mode === 'user_doc') && (
                      <div className="input-group">
                          <label>Select Document</label>
                          <div style={{display:'flex', gap:'10px'}}>
                             <input type="text" placeholder="Search Title, ID..." value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} style={{flex:1}}/>
                             <button onClick={handleLibrarySearch} style={{padding:'0 15px', borderRadius:'6px', border:'1px solid #cbd5e1'}}><Database size={16}/></button>
                          </div>
                          {libraryResults.length > 0 && <div style={{border:'1px solid #e2e8f0', borderRadius:'6px', marginTop:'5px', maxHeight:'150px', overflowY:'auto'}}>
                              {libraryResults.map(d => <div key={d.id} onClick={()=>selectSingleDoc(d)} style={{padding:'8px', cursor:'pointer', borderBottom:'1px solid #f1f5f9'}}>{d.title}</div>)}
                          </div>}
                          {selectedDoc && <div style={{marginTop:'10px', padding:'8px', background:'#f0fdf4', borderRadius:'6px', border:'1px solid #bbf7d0', color:'#166534'}}>✅ {selectedDoc.title}</div>}
                      </div>
                  )}
                  {mode === 'project' && (
                      <div className="input-group">
                          <label>Add Documents to Project Scope</label>
                          <div style={{display:'flex', gap:'10px'}}>
                             <input type="text" placeholder="Search..." value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} style={{flex:1}}/>
                             <button onClick={handleLibrarySearch} style={{padding:'0 15px', borderRadius:'6px', border:'1px solid #cbd5e1'}}><Plus size={16}/></button>
                          </div>
                          {libraryResults.length > 0 && <div style={{border:'1px solid #e2e8f0', borderRadius:'6px', marginTop:'5px', maxHeight:'150px', overflowY:'auto'}}>
                              {libraryResults.map(d => <div key={d.id} onClick={()=>addProjectDoc(d)} style={{padding:'8px', cursor:'pointer', borderBottom:'1px solid #f1f5f9'}}><Plus size={12}/> {d.title}</div>)}
                          </div>}
                          <div style={{marginTop:'10px', fontSize:'0.9rem', color:'#64748b'}}>{projectDocs.length} documents added.</div>
                      </div>
                  )}
                  {mode === 'discovery' && (
                      <div className="input-group">
                          <label>Discovery Topic</label>
                          <textarea value={discoveryTopic} onChange={(e) => setDiscoveryTopic(e.target.value)} placeholder="e.g., What are the safety requirements?" style={{width:'100%', height:'100px', padding:'10px', border:'1px solid #cbd5e1', borderRadius:'6px'}}/>
                      </div>
                  )}
              </div>
              <div className="input-group">
                  <label>Interrogator Model</label>
                  <select value={selectedModel} onChange={e => setSelectedModel(e.target.value)}>
                      {models.map(m => {
                          const statusLabel = m.status === 'available' ? '' : (m.status === 'unavailable' ? ' (Unavailable)' : ' (Not set up)');
                          return <option key={m.id} value={m.id}>{m.name}{statusLabel}</option>;
                      })}
                  </select>
                  {selectedModel && (() => {
                      const m = models.find(x => x.id === selectedModel);
                      if (!m || m.status === 'available') return null;
                      return (
                          <div style={{fontSize:'0.75rem', marginTop:'4px', color: m.status === 'unavailable' ? '#94a3b8' : '#eab308'}}>
                              {m.status === 'unavailable' ? 'Ollama may be offline or model not pulled.' : 'Set up the model (pull in Ollama or add API key in Settings).'}
                          </div>
                      );
                  })()}
              </div>
              <div style={{background:'#eff6ff', padding:'15px', borderRadius:'8px', border:'1px solid #dbeafe', marginBottom:'20px', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                  <div><div style={{fontWeight:'bold', color:'#1e40af'}}>🤖 Auto-Pilot (Viva Mode)</div><div style={{fontSize:'0.8rem', color:'#60a5fa'}}>AI Examiner interviews CORA.</div></div>
                  <div style={{display:'flex', alignItems:'center', gap:'15px'}}>
                      <label className="switch"><input type="checkbox" checked={isAutoMode} onChange={e => setIsAutoMode(e.target.checked)} /><span className="slider round"></span></label>
                      {isAutoMode && (<div style={{display:'flex', alignItems:'center', gap:'10px', fontSize:'0.9rem'}}><span>Turns: <strong>{maxTurns}</strong></span><input type="range" min="1" max="50" value={maxTurns} onChange={e => setMaxTurns(parseInt(e.target.value))} style={{width:'100px'}}/></div>)}
                  </div>
              </div>
              {selectedModel && models.find(m => m.id === selectedModel)?.status !== 'available' && (
                  <div style={{fontSize:'0.75rem', color:'#eab308', marginBottom:'8px', display:'flex', alignItems:'center', gap:'6px'}}>
                      Model not available. Set up in Ollama or add API key in Settings.
                  </div>
              )}
              <button 
                  className="btn btn-primary" 
                  onClick={handleStartSession} 
                  disabled={isThinking || !selectedModel || models.find(m => m.id === selectedModel)?.status !== 'available' || ((mode==='single_doc' || mode==='user_doc') && !selectedDoc) || (mode==='project' && projectDocs.length===0)} 
                  style={{width:'100%', ...((selectedModel && models.find(m => m.id === selectedModel)?.status !== 'available') ? {opacity: 0.7, cursor: 'not-allowed'} : {})}}
              >
                  {isThinking ? "Connecting..." : isAutoMode ? "🚀 Start" : "🔴 Start Live"}
              </button>
          </div>
      ) : (
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', paddingBottom: '20px'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 20px', background: 'white', borderBottom: '1px solid #e2e8f0'}}>
                  <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                      <div style={{width: '10px', height: '10px', borderRadius: '50%', background: isRunningAuto ? '#eab308' : '#22c55e', animation: 'pulse 2s infinite'}}></div>
                      <span style={{fontWeight: 'bold', color: '#334155'}}>{isRunningAuto ? `Auto-Pilot: Turn ${turnCount}/${maxTurns}` : `Live: ${mode.toUpperCase()}`}</span>
                  </div>
                  <div style={{display:'flex', gap:'10px'}}>
                      {isAutoMode && (<button onClick={() => setIsRunningAuto(!isRunningAuto)} className="btn" style={{background: isRunningAuto ? '#eab308' : '#22c55e', color:'white', padding:'6px 12px', fontSize:'0.8rem', display:'flex', alignItems:'center', gap:'4px'}}>{isRunningAuto ? <><StopCircle size={14}/> Pause</> : <><Play size={14}/> Resume</>}</button>)}
                      <button onClick={() => {setIsSessionActive(false); setIsRunningAuto(false);}} className="btn" style={{background: '#ef4444', color: 'white', padding: '6px 12px', fontSize: '0.8rem'}}>End Session</button>
                  </div>
              </div>
              
              <div style={{flex: 1, overflowY: 'auto', padding: '20px', display: 'flex', flexDirection: 'column', gap: '15px'}}>
                  {chatHistory.map((msg, i) => (
                      <div key={i} style={{alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '80%', background: msg.role === 'user' ? (msg.isAuto ? '#7c3aed' : '#3b82f6') : (msg.role === 'system' ? '#f1f5f9' : 'white'), color: msg.role === 'user' ? 'white' : '#1e293b', padding: '12px 16px', borderRadius: '12px', border: msg.role === 'assistant' ? '1px solid #e2e8f0' : 'none', boxShadow: '0 2px 4px rgba(0,0,0,0.05)'}}>
                          {msg.role === 'assistant' && <div style={{fontSize:'0.75rem', fontWeight:'bold', marginBottom:'4px', color:'#64748b', display:'flex', alignItems:'center', gap:'4px'}}><Bot size={12}/> Candidate (CORA)</div>}
                          {msg.role === 'user' && msg.isAuto && <div style={{fontSize:'0.75rem', fontWeight:'bold', marginBottom:'4px', color:'#ddd6fe', display:'flex', alignItems:'center', gap:'4px'}}><Cpu size={12}/> AI Examiner</div>}
                          
                          {msg.reasoning && (<div style={{marginBottom:'8px', fontSize:'0.8rem', fontStyle:'italic', color:'#ddd6fe', background:'rgba(0,0,0,0.1)', padding:'6px', borderRadius:'6px'}}><div style={{display:'flex', alignItems:'center', gap:'4px', fontWeight:'bold', marginBottom:'2px'}}><Brain size={10}/> Thought:</div>{msg.reasoning}</div>)}
                          
                          <div style={{whiteSpace:'pre-wrap', lineHeight:'1.5'}}>{msg.content || <span style={{fontStyle:'italic', opacity:0.6}}>No textual response.</span>}</div>

                          {/* 1. CITATIONS (Links/References from API) */}
                          {msg.citations && msg.citations.length > 0 && (
                              <div style={{marginTop:'12px', paddingTop:'8px', borderTop:'1px solid rgba(0,0,0,0.1)', fontSize:'0.75rem'}}>
                                  <div style={{fontWeight:'bold', display:'flex', alignItems:'center', gap:'4px', marginBottom:'4px', color:'#1d4ed8'}}><LinkIcon size={10}/> References:</div>
                                  <div style={{display:'flex', flexWrap:'wrap', gap:'5px'}}>
                                    {msg.citations.map((c, idx) => (<a key={idx} href={c.url} target="_blank" rel="noopener noreferrer" style={{background:'#dbeafe', color:'#1e40af', padding:'2px 6px', borderRadius:'4px', border:'1px solid #bfdbfe', textDecoration:'none'}}>{c.title || c.document_name}</a>))}
                                  </div>
                              </div>
                          )}

                          {/* 2. GROUNDING (Text/Images/Rich Links from 'clean_grounding') */}
                          {msg.grounding && msg.grounding.length > 0 && (
                              <div style={{marginTop:'12px', paddingTop:'8px', borderTop:'1px dashed rgba(0,0,0,0.1)', fontSize:'0.75rem'}}>
                                  <div style={{fontWeight:'bold', display:'flex', alignItems:'center', gap:'4px', marginBottom:'4px', color:'#64748b'}}><BookOpen size={10}/> Evidence (Grounding):</div>
                                  {msg.grounding.map((c, idx) => <EvidenceChunk key={idx} chunk={c} />)}
                              </div>
                          )}
                      </div>
                  ))}
                  {isThinking && <div style={{alignSelf:'flex-start', background:'white', padding:'10px', borderRadius:'12px', border:'1px solid #e2e8f0'}}><div className="spin" style={{border:'2px solid #cbd5e1', borderTop:'2px solid #3b82f6', width:'16px', height:'16px', borderRadius:'50%'}}></div></div>}
                  <div ref={chatEndRef}></div>
              </div>
              
              {!isRunningAuto && (
                  <div style={{padding: '0 20px'}}>
                      <div style={{display: 'flex', gap: '10px', background: 'white', padding: '10px', borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'}}>
                          <input type="text" value={question} onChange={e => setQuestion(e.target.value)} onKeyDown={handleKeyPress} placeholder="Type your next question..." style={{flex: 1, border: 'none', outline: 'none'}} autoFocus/>
                          <button onClick={handleSend} disabled={!question.trim() || (selectedModel && models.find(m => m.id === selectedModel)?.status !== 'available')} style={{background: (selectedModel && models.find(m => m.id === selectedModel)?.status !== 'available') ? '#94a3b8' : '#3b82f6', color: 'white', border: 'none', borderRadius: '6px', width: '40px', cursor: (selectedModel && models.find(m => m.id === selectedModel)?.status !== 'available') ? 'not-allowed' : 'pointer'}}><Send size={18}/></button>
                      </div>
                  </div>
              )}
          </div>
      )}
    </div>
  );
}