import { useState, useEffect } from 'react';
import { 
  BookOpen, Search, Zap, Shield, BarChart3, Settings, Cpu, ChevronUp, FileText, Code 
} from 'lucide-react';
import { API_BASE } from '../api';

export default function Sidebar({ activeTab, setActiveTab }) {
  const [models, setModels] = useState([]);
  const [activeModel, setActiveModel] = useState("loading...");
  const [showModelMenu, setShowModelMenu] = useState(false);
  const [version, setVersion] = useState(null);

  // 0. LOAD VERSION FROM API (single source: main.py __version__)
  useEffect(() => {
    fetch(API_BASE)
      .then(r => r.json())
      .then(data => setVersion(data?.version ?? null))
      .catch(() => setVersion(null));
  }, []);

  // 1. LOAD MODELS ON START (and active profile from server)
  useEffect(() => {
    Promise.all([
      fetch(`${API_BASE}/config/llms`).then(r => r.json()),
      fetch(`${API_BASE}/config/active_model`).then(r => r.json())
    ])
      .then(([llmData, activeData]) => {
          if (Array.isArray(llmData) && llmData.length > 0) {
              setModels(llmData);
              const serverActive = activeData?.active_profile;
              const validActive = serverActive && llmData.some(m => m.id === serverActive)
                ? serverActive
                : llmData[0].id;
              setActiveModel(validActive);
          }
      })
      .catch(console.error);
  }, []);

  // 2. HANDLE SWITCHING
  const switchModel = async (modelId) => {
      setActiveModel(modelId);
      setShowModelMenu(false);
      
      try {
          await fetch(`${API_BASE}/config/active_model`, {
              method: 'POST',
              headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({ model_id: modelId })
          });
      } catch (e) {
          console.error("Failed to update active model", e);
      }
  };

  const activeProfile = models.find(m => m.id === activeModel);
  const activeDisplay = activeProfile?.name || activeModel;
  const isActiveAvailable = activeProfile?.status === 'available';
  const isActiveUnavailable = activeProfile?.status === 'unavailable';

  return (
    <div style={{
        width: '260px', 
        background: '#0f172a', 
        color: '#94a3b8', 
        display: 'flex', 
        flexDirection: 'column',
        borderRight: '1px solid #1e293b',
        flexShrink: 0
    }}>
      {/* BRAND HEADER */}
      <div style={{padding: '25px 20px', color: 'white', fontWeight: 'bold', fontSize: '1.2rem', display:'flex', alignItems:'center', gap:'10px'}}>
          <div style={{width:24, height:24, background:'linear-gradient(45deg, #3b82f6, #8b5cf6)', borderRadius:'6px'}}></div>
          AXIOM <span style={{fontSize:'0.7rem', background:'#1e293b', padding:'2px 6px', borderRadius:'4px', marginLeft:'auto', color:'#64748b'}}>{version ?? '…'}</span>
      </div>

      {/* NAVIGATION ITEMS */}
      <div style={{flex: 1, padding: '0 10px', overflowY:'auto'}}>
          
          {/* MAIN MODULES */}
          <NavItem id="teacher" icon={BookOpen} label="The Teacher" active={activeTab} set={setActiveTab} />
          <NavItem id="examiner" icon={Search} label="The Examiner" active={activeTab} set={setActiveTab} />
          <NavItem id="interrogator" icon={Zap} label="The Interrogator" active={activeTab} set={setActiveTab} />
          <NavItem id="judge" icon={Shield} label="The Judge" active={activeTab} set={setActiveTab} />

          <div style={{height:'1px', background:'#334155', margin:'15px 10px', opacity:0.5}}></div>

          {/* SECONDARY MODULES */}
          <NavItem 
            id="evaluation" 
            icon={BarChart3} 
            label="Evaluation" 
            active={activeTab} 
            set={setActiveTab} 
            color={activeTab === 'evaluation' ? '#a78bfa' : '#94a3b8'}
          />
          <NavItem id="settings" icon={Settings} label="Settings" active={activeTab} set={setActiveTab} />

          <div style={{height:'1px', background:'#334155', margin:'15px 10px', opacity:0.5}}></div>

          {/* 📘 DOCUMENTATION SECTION (The missing part!) */}
          <div style={{paddingLeft:'10px', marginTop:'10px'}}>
              <div style={{fontSize:'0.75rem', fontWeight:'bold', color:'#475569', marginBottom:'8px', textTransform:'uppercase'}}>Documentation</div>
              
              {/* User Guide - Standard Font */}
              <div 
                onClick={() => setActiveTab('user_docs')} 
                style={{
                    display:'flex', alignItems:'center', gap:'10px', padding:'8px', 
                    cursor:'pointer', color: activeTab === 'user_docs' ? 'white' : '#cbd5e1', 
                    marginBottom:'5px', borderRadius:'6px',
                    background: activeTab === 'user_docs' ? '#1e293b' : 'transparent'
                }}>
                  <FileText size={16}/> <span style={{fontWeight:500}}>User Guide</span>
              </div>

              {/* Dev Docs - Smaller Font */}
              <div 
                onClick={() => setActiveTab('dev_docs')} 
                style={{
                    display:'flex', alignItems:'center', gap:'10px', padding:'8px', 
                    cursor:'pointer', color: activeTab === 'dev_docs' ? '#94a3b8' : '#64748b', 
                    fontSize:'0.85rem', borderRadius:'6px',
                    background: activeTab === 'dev_docs' ? '#1e293b' : 'transparent'
                }}>
                  <Code size={14}/> <span>Developer Docs</span>
              </div>
          </div>

      </div>

      {/* 🚀 DYNAMIC BRAIN SWITCHER */}
      <div style={{padding: '20px', borderTop: '1px solid #1e293b', position:'relative'}}>
          <div style={{fontSize: '0.75rem', fontWeight: 'bold', color: '#475569', marginBottom: '8px', textTransform:'uppercase'}}>
              Active Brain
          </div>
          
          <div 
            onClick={() => setShowModelMenu(!showModelMenu)}
            style={{
                background: '#1e293b', 
                borderRadius: '8px', 
                padding: '10px', 
                cursor: 'pointer',
                border: '1px solid #334155',
                display: 'flex', alignItems: 'center', gap: '10px',
                transition: 'all 0.2s'
            }}
            className="hover:bg-slate-800"
          >
              <Cpu size={20} color={isActiveAvailable ? '#22c55e' : (isActiveUnavailable ? '#94a3b8' : '#eab308')} />
              <div style={{flex:1, overflow:'hidden'}}>
                  <div style={{color:'white', fontSize:'0.85rem', whiteSpace:'nowrap', textOverflow:'ellipsis', fontWeight:500}}>
                      {activeDisplay}
                  </div>
                  <div style={{fontSize:'0.7rem', color: isActiveAvailable ? '#22c55e' : (isActiveUnavailable ? '#94a3b8' : '#eab308'), display:'flex', alignItems:'center', gap:'4px'}}>
                      <span style={{width:6, height:6, borderRadius:'50%', background: isActiveAvailable ? '#22c55e' : (isActiveUnavailable ? '#94a3b8' : '#eab308'), display:'inline-block'}}></span>
                      {isActiveAvailable ? 'Online' : (isActiveUnavailable ? 'Unavailable' : 'Not set up')}
                  </div>
              </div>
              <ChevronUp size={14} style={{transform: showModelMenu ? 'rotate(180deg)' : 'rotate(0deg)', transition:'transform 0.2s'}}/>
          </div>

          {/* POPUP MENU */}
          {showModelMenu && (
              <div style={{
                  position: 'absolute', bottom: '90px', left: '10px', right: '10px',
                  background: '#1e293b', border: '1px solid #334155', borderRadius: '8px',
                  boxShadow: '0 -5px 20px rgba(0,0,0,0.5)', overflow: 'hidden', zIndex: 100,
                  maxHeight:'300px', overflowY:'auto'
              }}>
                  {models.map(m => {
                      const available = m.status === 'available';
                      const unavailable = m.status === 'unavailable';
                      const dotColor = available ? '#22c55e' : (unavailable ? '#94a3b8' : '#eab308');
                      return (
                      <div 
                        key={m.id}
                        onClick={() => switchModel(m.id)}
                        style={{
                            padding: '10px 12px', 
                            fontSize: '0.85rem', 
                            color: activeModel === m.id ? '#fff' : '#94a3b8',
                            background: activeModel === m.id ? '#334155' : 'transparent',
                            cursor: 'pointer',
                            display:'flex', alignItems:'center', gap:'8px',
                            borderBottom: '1px solid #334155'
                        }}
                      >
                          <div style={{width:6, height:6, borderRadius:'50%', background: activeModel === m.id ? dotColor : 'transparent'}}></div>
                          <span style={{flex:1}}>{m.name}</span>
                          <span style={{fontSize:'0.7rem', color: dotColor}}>
                              {available ? 'Online' : (unavailable ? 'Unavailable' : 'Not set up')}
                          </span>
                      </div>
                  );})}
              </div>
          )}
      </div>
    </div>
  );
}

// --- HELPER COMPONENT ---
function NavItem({ id, icon: Icon, label, active, set, color }) {
    const isActive = active === id;
    return (
        <div 
            onClick={() => set(id)}
            style={{
                display: 'flex', alignItems: 'center', gap: '12px',
                padding: '12px 15px',
                marginBottom: '5px',
                borderRadius: '8px',
                cursor: 'pointer',
                background: isActive ? '#1e293b' : 'transparent',
                color: isActive ? '#fff' : '#64748b',
                fontWeight: isActive ? 500 : 400,
                transition: 'all 0.2s',
                borderLeft: isActive ? '3px solid #3b82f6' : '3px solid transparent'
            }}
        >
            <Icon size={18} color={color || (isActive ? '#60a5fa' : '#64748b')} />
            {label}
        </div>
    );
}