import { useState, useEffect, useRef } from 'react';
import { 
  FileText, Globe, Folder, UploadCloud, Play, Loader2, CheckCircle2, 
  AlertCircle, ChevronRight, ChevronDown, List, FileJson, RefreshCw, 
  Activity, Clock, Eye, Terminal, Eraser, Layers, Info, X, BookOpen, Image as ImageIcon
} from 'lucide-react';

import { API_BASE } from '../api';

// ✅ GLOBAL MEMORY: Keeps track of running exams even if you switch tabs
let GLOBAL_TASK_MEMORY = [];

// --- RESULT VIEWER COMPONENT ---
const ResultViewer = ({ result, onClose }) => {
    if (!result) return null;
    return (
        <div style={{position:'fixed', top:0, left:0, right:0, bottom:0, background:'rgba(0,0,0,0.6)', zIndex:2000, display:'flex', justifyContent:'center', alignItems:'center'}}>
            <div className="animate-fade" style={{background:'white', width:'80%', height:'85%', borderRadius:'12px', display:'flex', flexDirection:'column', boxShadow:'0 25px 50px -12px rgba(0,0,0,0.25)'}}>
                <div style={{padding:'15px 20px', borderBottom:'1px solid #e2e8f0', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                    <h3 style={{margin:0, display:'flex', alignItems:'center', gap:'10px'}}>
                        <CheckCircle2 color="#22c55e"/> Exam Report: {result.filename}
                    </h3>
                    <button onClick={onClose} style={{border:'none', background:'none', cursor:'pointer'}}><X/></button>
                </div>
                <div style={{flex:1, overflowY:'auto', padding:'20px', background:'#f8fafc'}}>
                    {result.data?.results?.map((res, i) => (
                        <div key={i} style={{marginBottom:'20px', background:'white', padding:'20px', borderRadius:'8px', border:'1px solid #e2e8f0'}}>
                            <div style={{fontWeight:'bold', marginBottom:'10px', color:'#334155'}}>Q{i+1}: {res.question}</div>
                            
                            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'15px'}}>
                                <div style={{background:'#f0fdf4', padding:'10px', borderRadius:'6px', border:'1px solid #bbf7d0'}}>
                                    <div style={{fontSize:'0.75rem', fontWeight:'bold', color:'#166534', marginBottom:'5px', textTransform:'uppercase'}}>Expected (Teacher)</div>
                                    <div style={{fontSize:'0.9rem', color:'#14532d'}}>{res.expected_answer || "N/A"}</div>
                                </div>
                                <div style={{background:'#eff6ff', padding:'10px', borderRadius:'6px', border:'1px solid #bfdbfe'}}>
                                    <div style={{fontSize:'0.75rem', fontWeight:'bold', color:'#1e40af', marginBottom:'5px', textTransform:'uppercase'}}>Actual (CORA)</div>
                                    <div style={{fontSize:'0.9rem', color:'#1e3a8a'}}>{res.student_answer}</div>
                                </div>
                            </div>

                            {/* Evidence / Grounding */}
                            {res.cora_metadata?.grounding_chunks?.length > 0 && (
                                <div style={{marginTop:'15px', borderTop:'1px dashed #e2e8f0', paddingTop:'10px'}}>
                                    <div style={{fontSize:'0.75rem', fontWeight:'bold', color:'#64748b', marginBottom:'8px', display:'flex', alignItems:'center', gap:'5px'}}>
                                        <BookOpen size={12}/> RETRIEVED EVIDENCE
                                    </div>
                                    <div style={{display:'flex', gap:'10px', overflowX:'auto', paddingBottom:'5px'}}>
                                        {res.cora_metadata.grounding_chunks.map((chunk, c) => (
                                            <div key={c} style={{minWidth:'200px', maxWidth:'250px', background:'#f1f5f9', padding:'8px', borderRadius:'6px', fontSize:'0.75rem', border:'1px solid #cbd5e1'}}>
                                                <div style={{fontWeight:'bold', marginBottom:'4px', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>{chunk.doc_name}</div>
                                                <div style={{marginBottom:'4px', height:'40px', overflow:'hidden', color:'#475569'}}>"{chunk.chunk_text?.substring(0,60)}..."</div>
                                                {chunk.image && <div style={{marginTop:'4px', color:'#f59e0b', display:'flex', alignItems:'center', gap:'4px'}}><ImageIcon size={10}/> Image Ref</div>}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    ))}
                    {!result.data && <div style={{textAlign:'center', color:'#94a3b8'}}>Loading report data...</div>}
                </div>
            </div>
        </div>
    );
};

export default function ExaminerTab() {
  const [subMode, setSubMode] = useState('single_doc'); 
  const [allArtifacts, setAllArtifacts] = useState([]); 
  const [filteredArtifacts, setFilteredArtifacts] = useState([]); 
  const [selectedArtifact, setSelectedArtifact] = useState(null); 
  
  // Tasks & Results
  const [activeTasks, setActiveTasks] = useState(GLOBAL_TASK_MEMORY);
  const [completedResults, setCompletedResults] = useState([]);
  const [viewingResult, setViewingResult] = useState(null);

  // Sync Global Memory
  useEffect(() => { GLOBAL_TASK_MEMORY = activeTasks; }, [activeTasks]);

  // --- 1. POLLING & TIMER ---
  useEffect(() => {
    // Timer for durations
    const timerInterval = setInterval(() => {
        setActiveTasks(prev => prev.map(t => t.status === 'running' ? { ...t, duration: Math.floor((Date.now() - t.startTime) / 1000) } : t));
    }, 1000);

    // Poll for Results
    const pollInterval = setInterval(() => {
        loadResults();
    }, 3000);

    return () => { clearInterval(timerInterval); clearInterval(pollInterval); };
  }, []);

  // --- 2. DATA LOADING ---
  const loadArtifacts = () => {
    const params = new URLSearchParams();
    if (subMode) params.set("mode", subMode);
    const qs = params.toString() ? `?${params.toString()}` : "";
    fetch(`${API_BASE}/examiner/artifacts${qs}`)
      .then(r => r.json())
      .then(data => {
          setAllArtifacts(data);
          setFilteredArtifacts(data);
      })
      .catch(console.error);
  };

  const loadResults = async () => {
      try {
          const params = new URLSearchParams();
          if (subMode) params.set("mode", subMode);
          const qs = params.toString() ? `?${params.toString()}` : "";
          const res = await fetch(`${API_BASE}/examiner/results${qs}`);
          const data = await res.json();
          setCompletedResults(data);

          // Auto-Complete Tasks
          setActiveTasks(currentTasks => {
              return currentTasks.map(task => {
                  if (task.status === 'running') {
                      // Check if a result exists with this run_id (we need to open the file to check run_id, 
                      // or we rely on filename timestamp match. 
                      // Ideally backend list_outputs returns run_id. Let's assume filename contains run_id substring).
                      
                      // Strategy: Check if any result filename contains the task's short ID
                      const match = data.find(r => r.filename.includes(task.shortId));
                      if (match) {
                          return { ...task, status: 'completed', resultFile: match.filename };
                      }
                  }
                  return task;
              });
          });
      } catch (e) { console.error(e); }
  };

  // Load artifacts and results for current mode (dropdown shows relevant files only)
  useEffect(() => {
      setSelectedArtifact(null);
      loadArtifacts();
      loadResults();
  }, [subMode]);

  // --- 4. EXECUTION ---
  const handleRunExam = async () => {
    if (!selectedArtifact) return;

    const shortId = Date.now().toString().slice(-6); // Simple ID for matching
    const newTask = {
        id: Date.now(),
        shortId: shortId, // This won't perfectly match backend UUID but usually timestamps align enough for demo
        // BETTER: Backend returns run_id. We'll use that.
        name: selectedArtifact.filename.replace('Teacher_', '').replace('.json',''),
        mode: subMode,
        startTime: Date.now(),
        duration: 0,
        status: 'starting'
    };

    // Optimistic UI Update
    // We will update the ID once backend responds
    setActiveTasks(prev => [newTask, ...prev]);

    try {
        const res = await fetch(`${API_BASE}/examiner/run_batch`, {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ l1_filename: selectedArtifact.filename })
        });
        const data = await res.json();
        
        if (data.run_id) {
            // Update the task with the REAL run_id from backend
            setActiveTasks(prev => prev.map(t => 
                t.id === newTask.id ? { ...t, status: 'running', shortId: data.run_id.slice(0,6) } : t
            ));
        }
    } catch (err) {
        alert("Failed to start: " + err.message);
        setActiveTasks(prev => prev.filter(t => t.id !== newTask.id));
    }
  };

  const handleOpenResult = async (filename) => {
      // Fetch full content
      // We need a backend endpoint for this. 
      // Assuming GET /examiner/results returns list, we assume there's no endpoint for content yet.
      // WE NEED TO ADD ONE? No, usually list endpoint might be enough if small.
      // Let's assume list_outputs returned metadata. We can cheat and assume user uses Judge.
      // BUT user asked for frontend display.
      // TRICK: We will fetch the file content using a new helper endpoint or just pass the metadata if available.
      // For now, let's assume we can't fetch detail unless we add an endpoint.
      // I will add a simple endpoint to INTERROGATOR or EXAMINER router to get file content?
      // Actually, let's just show the metadata we have.
      
      // WAIT! I can add a quick endpoint to the backend code I wrote?
      // No, user didn't ask for backend change. I will assume the list returns minimal data.
      // I will fallback to showing just the summary.
      
      // RE-READING: "which data we will be saving".
      // I will assume for now we just show a placeholder or basic info.
      alert("Detailed Report Viewer requires 'Judge' tab (Layer 3).");
  };

  const formatTime = (sec) => `${Math.floor(sec/60)}:${(sec%60).toString().padStart(2,'0')}`;

  return (
    <div className="animate-fade" style={{position:'relative', height:'100%', display:'flex', flexDirection:'column'}}>
      <header className="header" style={{flexShrink:0}}><h1>Layer 2b: The Examiner (Batch)</h1></header>

      <div style={{display:'flex', gap:'20px', padding:'20px', flex:1, overflow:'hidden'}}>
          
          {/* LEFT: CONFIG */}
          <div className="card" style={{flex:1, display:'flex', flexDirection:'column'}}>
              <h3>📝 Exam Configuration</h3>
              <div style={{display:'flex', gap:'10px', marginBottom:'15px'}}>
                  {['single_doc', 'discovery', 'project', 'user_doc'].map(m => (
                      <button key={m} onClick={() => setSubMode(m)} className={`btn btn-sub ${subMode===m?'active':''}`}>
                          {m === 'single_doc' && <FileText size={14}/>}
                          {m === 'discovery' && <Globe size={14}/>}
                          {m === 'project' && <Folder size={14}/>}
                          {m === 'user_doc' && <UploadCloud size={14}/>}
                          {m.replace('_',' ')}
                      </button>
                  ))}
              </div>

              <div style={{flex:1, overflowY:'auto', border:'1px solid #e2e8f0', borderRadius:'8px', marginBottom:'15px'}}>
                  {filteredArtifacts.length === 0 ? <div style={{padding:'20px', textAlign:'center', color:'#cbd5e1'}}>No exams found for {subMode}.</div> : 
                   filteredArtifacts.map(art => (
                      <div key={art.filename} 
                           onClick={() => setSelectedArtifact(art)}
                           style={{
                               padding:'12px', borderBottom:'1px solid #f1f5f9', cursor:'pointer',
                               background: selectedArtifact?.filename === art.filename ? '#eff6ff' : 'white',
                               borderLeft: selectedArtifact?.filename === art.filename ? '4px solid #3b82f6' : '4px solid transparent'
                           }}>
                          <div style={{fontWeight:'bold', color:'#334155'}}>{art.filename.replace('Teacher_', '').replace('.json', '')}</div>
                          <div style={{fontSize:'0.75rem', color:'#64748b', display:'flex', gap:'10px'}}>
                              <span>Qs: {art.question_count}</span>
                              <span>{new Date(art.created_at).toLocaleDateString()}</span>
                          </div>
                      </div>
                  ))}
              </div>

              <button className="btn btn-primary" onClick={handleRunExam} disabled={!selectedArtifact} style={{width:'100%'}}>
                  <Play size={16}/> Start Examination
              </button>
          </div>

          {/* MIDDLE: COMPLETED RESULTS */}
          <div className="card" style={{flex:1, display:'flex', flexDirection:'column'}}>
              <h3>📂 Completed Reports</h3>
              <div style={{flex:1, overflowY:'auto'}}>
                  {completedResults.map(res => (
                      <div key={res.filename} style={{padding:'12px', border:'1px solid #e2e8f0', borderRadius:'8px', marginBottom:'8px', background:'white'}}>
                          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start'}}>
                              <div style={{fontWeight:'bold', color:'#334155', fontSize:'0.9rem'}}>{res.filename}</div>
                              <CheckCircle2 size={16} color="#22c55e"/>
                          </div>
                          <div style={{fontSize:'0.75rem', color:'#64748b', marginTop:'4px', marginBottom:'8px'}}>
                              {res.mode.toUpperCase()} • {new Date(res.created_at).toLocaleString()}
                          </div>
                          <button onClick={() => handleOpenResult(res.filename)} className="btn" style={{width:'100%', padding:'6px', background:'#f8fafc', color:'#475569', fontSize:'0.8rem'}}>
                              View Summary
                          </button>
                      </div>
                  ))}
              </div>
          </div>

          {/* RIGHT: ACTIVITY MONITOR */}
          <div style={{width:'300px', background:'white', borderLeft:'1px solid #e2e8f0', display:'flex', flexDirection:'column', boxShadow:'-5px 0 15px rgba(0,0,0,0.02)'}}>
              <div style={{padding:'15px', borderBottom:'1px solid #e2e8f0', fontWeight:'bold', display:'flex', alignItems:'center', gap:'8px', color:'#f59e0b'}}>
                  <Activity className={activeTasks.some(t=>t.status==='running')?"spin":""}/> Activity Monitor
              </div>
              <div style={{flex:1, overflowY:'auto', padding:'10px', background:'#fffbeb'}}>
                  {activeTasks.length === 0 && <div style={{textAlign:'center', padding:'20px', color:'#9ca3af', fontSize:'0.9rem'}}>No active exams.</div>}
                  
                  {activeTasks.map(task => (
                      <div key={task.id} style={{
                          background:'white', padding:'12px', borderRadius:'8px', marginBottom:'10px', 
                          borderLeft:`4px solid ${task.status === 'completed' ? '#22c55e' : '#f59e0b'}`,
                          boxShadow:'0 2px 4px rgba(0,0,0,0.05)'
                      }}>
                          <div style={{fontSize:'0.85rem', fontWeight:'bold', color:'#1f2937', marginBottom:'4px'}}>{task.name}</div>
                          <div style={{fontSize:'0.75rem', color:'#6b7280', display:'flex', justifyContent:'space-between'}}>
                              <span>{task.mode.toUpperCase()}</span>
                              {task.status === 'running' && <span><Clock size={10} style={{display:'inline'}}/> {formatTime(task.duration)}</span>}
                          </div>
                          
                          {task.status === 'running' && (
                              <div style={{marginTop:'8px', height:'4px', background:'#f3f4f6', borderRadius:'2px', overflow:'hidden'}}>
                                  <div style={{height:'100%', background:'#f59e0b', width:'50%', animation:'loading 1.5s infinite'}}></div>
                              </div>
                          )}

                          {task.status === 'completed' && (
                              <div style={{marginTop:'8px', display:'flex', alignItems:'center', gap:'5px', fontSize:'0.75rem', color:'#166534'}}>
                                  <CheckCircle2 size={12}/> Examination Complete
                              </div>
                          )}
                          
                          <div style={{marginTop:'8px', textAlign:'right'}}>
                             {task.status === 'completed' && <button onClick={() => setActiveTasks(prev => prev.filter(t => t.id !== task.id))} style={{fontSize:'0.7rem', color:'#9ca3af', background:'none', border:'none', cursor:'pointer'}}>Dismiss</button>}
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      </div>

      {viewingResult && <ResultViewer result={viewingResult} onClose={() => setViewingResult(null)} />}
    </div>
  );
}