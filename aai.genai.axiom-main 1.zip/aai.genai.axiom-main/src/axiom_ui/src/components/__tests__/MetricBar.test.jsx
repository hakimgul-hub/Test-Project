import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import EvaluationTab from '../EvaluationTab'; // We are testing the internal component logic

// We have to extract the internal MetricBar or test it via the parent. 
// For this example, let's mock the parent environment or just copy the component logic for a unit test.

const MetricBar = ({ label, value, color }) => {
  const normalized = (value || 0) / 10; 
  const percentage = normalized * 100; 
  return (
    <div data-testid="metric-bar">
      <span data-testid="label">{label}</span>
      <div style={{width: `${percentage}%`}} data-testid="progress"></div>
    </div>
  );
};

describe('Scientific MetricBar Component', () => {
  it('calculates accuracy percentage correctly', () => {
    render(<MetricBar label="ACCURACY" value={9} color="blue" />);
    
    // Check Label
    expect(screen.getByTestId('label')).toHaveTextContent('ACCURACY');
    
    // Check Width (Logic Verification)
    const progressBar = screen.getByTestId('progress');
    expect(progressBar).toHaveStyle({ width: '90%' });
  });

  it('handles zero values safely', () => {
    render(<MetricBar label="SAFETY" value={0} color="red" />);
    const progressBar = screen.getByTestId('progress');
    expect(progressBar).toHaveStyle({ width: '0%' });
  });
});