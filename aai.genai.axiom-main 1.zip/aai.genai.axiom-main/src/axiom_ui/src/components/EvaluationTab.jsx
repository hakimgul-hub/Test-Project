import { useState, useEffect } from 'react';
import { 
  Layout, Activity, BarChart3, ArrowUpRight,
  PieChart, Gavel, Loader2, Download, CheckCircle2, AlertTriangle, 
  FileText, Database, BookOpen, ImageIcon, ShieldCheck, Link as LinkIcon,
  Calendar, Hash, BrainCircuit
} from 'lucide-react';
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

import { API_BASE } from '../api';

// --- PDF HELPER: Fetch Remote Image ---
const fetchImageAsBase64 = (url) => {
    return new Promise(async (resolve) => {
        try {
            const proxyUrl = `${API_BASE}/proxy/image?url=${encodeURIComponent(url.trim())}`;
            const response = await fetch(proxyUrl);
            if (!response.ok) throw new Error("Image fetch failed");
            const blob = await response.blob();
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result); 
            reader.onerror = () => resolve(null);
            reader.readAsDataURL(blob);
        } catch (e) {
            console.warn("Image load failed:", e);
            resolve(null);
        }
    });
};

// --- PDF HELPER: Clean Text & Extract Images ---
const processContentForPDF = async (text, sourceLabel) => {
    if (!text) return { cleanText: "", images: [] };
    const imageRegex = /!\[[\s\S]*?\]\(([\s\S]*?)\)/g;
    const images = [];
    let cleanText = text;
    let match;

    while ((match = imageRegex.exec(text)) !== null) {
        const url = match[1].replace(/\s/g, ''); 
        if (url.startsWith('http')) {
            const base64 = await fetchImageAsBase64(url);
            if (base64) {
                images.push({ data: base64, label: sourceLabel });
            }
        }
    }
    cleanText = cleanText.replace(imageRegex, "\n[CHART/IMAGE SEE BELOW]\n");
    return { cleanText, images };
};

// --- UI COMPONENT: Render Text mixed with Images ---
const ContentWithImages = ({ text, type }) => {
    if (!text) return <span style={{opacity:0.5}}>No content.</span>;
    const parts = text.split(/(!\[[\s\S]*?\]\([\s\S]*?\))/g);

    return (
        <div>
            {parts.map((part, i) => {
                const match = part.match(/!\[([\s\S]*?)\]\(([\s\S]*?)\)/);
                if (match) {
                    const alt = match[1] || "Image";
                    const url = match[2].replace(/\s/g, '');
                    const displayUrl = `${API_BASE}/proxy/image?url=${encodeURIComponent(url)}`;
                    
                    let headerColor = '#64748b';
                    let headerText = 'Image';
                    if (type === 'truth') { headerColor = '#166534'; headerText = '📷 From Teacher (Truth)'; }
                    if (type === 'student') { headerColor = '#1e40af'; headerText = '🤖 From Student (CORA)'; }
                    if (type === 'evidence') { headerColor = '#b45309'; headerText = '🔍 Evidence Source'; }

                    return (
                        <div key={i} style={{margin:'10px 0', border:'1px solid #e2e8f0', borderRadius:'8px', padding:'8px', background:'white', width: 'fit-content'}}>
                            <div style={{fontSize:'0.65rem', fontWeight:'bold', color: headerColor, marginBottom:'5px', textTransform:'uppercase', display:'flex', alignItems:'center', gap:'5px'}}>
                                <ImageIcon size={10}/> {headerText}
                            </div>
                            <img 
                                src={displayUrl} alt={alt} 
                                style={{maxWidth:'100%', maxHeight:'150px', borderRadius:'4px', display:'block', border:'1px solid #f1f5f9'}}
                                onError={(e) => {e.target.style.display='none'}}
                            />
                        </div>
                    );
                }
                return <span key={i} style={{whiteSpace:'pre-wrap'}}>{part}</span>;
            })}
        </div>
    );
};

// Coerce score/metric from API (may be number, string, or dict from LLM) to a number
const safeNumber = (v) => {
  if (v == null) return 0;
  if (typeof v === 'number' && !Number.isNaN(v)) return v;
  if (typeof v === 'string') { const n = parseFloat(v); return Number.isNaN(n) ? 0 : n; }
  if (typeof v === 'object' && !Array.isArray(v)) {
    const nums = Object.values(v).filter(x => typeof x === 'number');
    return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
  }
  return 0;
};

const MetricBar = ({ label, value, color, isFuture = false }) => {
  const numVal = safeNumber(value);
  if (isFuture || value === undefined || value === null) {
      return (
        <div style={{marginBottom:'8px', fontSize:'0.75rem', opacity: 0.5}}>
          <div style={{display:'flex', justifyContent:'space-between', marginBottom:'2px'}}>
            <span style={{fontWeight:'700', color:'#64748b'}}>{label}</span>
            <span style={{fontWeight:'bold', color:'#94a3b8', fontSize:'0.7rem'}}>N/A</span>
          </div>
          <div style={{width:'100%', height:'6px', background:'#f1f5f9', borderRadius:'3px'}}></div>
        </div>
      );
  }
  const percentage = Math.min(100, Math.max(0, numVal * 10));
  return (
    <div style={{marginBottom:'8px', fontSize:'0.75rem'}}>
      <div style={{display:'flex', justifyContent:'space-between', marginBottom:'2px'}}>
        <span style={{fontWeight:'700', color:'#64748b'}}>{label}</span>
        <span style={{fontWeight:'bold', color: color}}>{numVal.toFixed(1)}</span>
      </div>
      <div style={{width:'100%', height:'6px', background:'#f1f5f9', borderRadius:'3px', overflow:'hidden'}}>
        <div style={{width: `${percentage}%`, height:'100%', background: color, borderRadius:'3px'}}></div>
      </div>
    </div>
  );
};

// --- HELPER: Extract Documents from Report ---
const extractDocuments = (report) => {
    if (!report) return [];
    let docs = [];
    const raw = report.teacher_configuration?.documents ?? report.context_info?.documents;
    if (Array.isArray(raw)) {
        docs = raw.map(d => typeof d === 'object' && d !== null ? d : { id: '', title: String(d), name: String(d) });
    } else if (report.teacher_configuration?.document_id) {
        docs = [{
            id: report.teacher_configuration.document_id,
            title: report.teacher_configuration.document_title || "Single Document",
            version: report.teacher_configuration.version || "N/A"
        }];
    }
    return docs;
};

// --- HELPER: Extract Domain Profile ---
const extractDomainContext = (report) => {
    if (!report) return null;
    const raw = report.teacher_configuration?.domain_profile ?? report.context_info?.domain_profile ?? report.domain_profile;
    if (!raw) return null;
    if (typeof raw === 'string') return { name: raw, description: 'N/A' };
    return raw;
};

export default function EvaluationTab() {
  const [currentMode, setCurrentMode] = useState('all'); 
  const [evaluations, setEvaluations] = useState([]);
  const [filteredEvaluations, setFilteredEvaluations] = useState([]);
  const [selectedEvaluation, setSelectedEvaluation] = useState("");
  const [evalReport, setEvalReport] = useState(null);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [logos, setLogos] = useState({ axiom: null, company: null });

  // Map UI mode to API mode param for judge/results (Root = uncategorized / fallback)
  const judgeResultsMode = currentMode === 'all' ? 'all' : currentMode === 'SingleDoc' ? 'single_doc' : currentMode === 'Discovery' ? 'discovery' : currentMode === 'Project' ? 'project' : currentMode === 'UserDoc' ? 'user_doc' : currentMode === 'Root' ? 'root' : 'all';

  useEffect(() => {
    fetch(`${API_BASE}/judge/assets/logos`)
      .then(r => r.json())
      .then(data => {
          setLogos({ axiom: data.axiom_logo, company: data.company_logo });
      })
      .catch(err => console.error("Logo fetch error:", err));
  }, []);

  // Fetch judge results for current mode (dropdown shows relevant reports only)
  useEffect(() => {
    const params = new URLSearchParams();
    if (judgeResultsMode && judgeResultsMode !== 'all') params.set("mode", judgeResultsMode);
    const qs = params.toString() ? `?${params.toString()}` : "";
    fetch(`${API_BASE}/judge/results${qs}`)
      .then(r => r.json())
      .then(data => {
          const safeData = Array.isArray(data) ? data : [];
          setEvaluations(safeData);
          updateFilter(currentMode, safeData);
      })
      .catch(err => { console.error("Fetch Error:", err); setEvaluations([]); });
  }, [currentMode]);

  useEffect(() => {
      updateFilter(currentMode, evaluations);
  }, [evaluations]);

  const updateFilter = (mode, data) => {
      if (!Array.isArray(data)) return;
      
      let filtered = (mode === 'all') ? data : data.filter(item => {
          const folder = (item.folder || "").toUpperCase();
          if (mode === 'SingleDoc') return folder.includes('SINGLE');
          if (mode === 'Discovery') return folder.includes('DISCOVERY');
          if (mode === 'Project') return folder.includes('PROJECT') || folder.includes('PCT');
          if (mode === 'UserDoc') return folder.includes('USER');
          if (mode === 'Root') return folder === 'ROOT';
          return false;
      });
      
      setFilteredEvaluations(filtered);

      if (filtered.length > 0) {
          const currentExists = filtered.find(f => f.relative_path === selectedEvaluation);
          if (!selectedEvaluation || !currentExists) {
              loadReport(filtered[0].relative_path); 
          }
      } else {
          setSelectedEvaluation("");
          setEvalReport(null);
      }
  };

  const loadReport = async (path) => {
      if(!path) return;
      setSelectedEvaluation(path);
      try {
          const res = await fetch(`${API_BASE}/judge/report?path=${encodeURIComponent(path)}`);
          if(res.ok) setEvalReport(await res.json());
      } catch (e) { console.error(e); }
  };

  const overall = safeNumber(evalReport?.average_score);
  const passed = overall >= 7.0;
  const documents = extractDocuments(evalReport);
  const domainContext = extractDomainContext(evalReport);

  const handleDownloadPDF = async () => {
    if (!evalReport) return;
    setGeneratingPdf(true);
    try {
        const doc = new jsPDF();
        const primaryColor = [76, 29, 149]; 
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();

        const addFooter = (pageNum) => {
            doc.setFontSize(8);
            doc.setTextColor(150);
            const footerText = "Intellectual Property of Automotive Artificial Intelligence (AAI) GmbH";
            doc.text(footerText, pageWidth / 2, pageHeight - 10, { align: 'center' });
            doc.text(`Page ${pageNum}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
            if (logos.company) doc.addImage(logos.company, 'PNG', 10, pageHeight - 15, 20, 10);
        };

        // --- PAGE 1: TITLE ---
        if (logos.axiom) doc.addImage(logos.axiom, 'PNG', pageWidth/2 - 40, 40, 80, 40);
        
        doc.setFontSize(24);
        doc.setTextColor(...primaryColor);
        doc.text("AXIOM User Guide", pageWidth / 2, 100, { align: 'center' });
        doc.setFontSize(16);
        doc.setTextColor(60);
        doc.text("Scientific Verification & Validation (V-Model)", pageWidth / 2, 110, { align: 'center' });
        doc.text("for GenAI Certification", pageWidth / 2, 118, { align: 'center' });
        doc.setFontSize(12);
        doc.setTextColor(100);
        doc.text(`Report ID: ${evalReport.run_id.slice(0,8)}`, pageWidth / 2, 140, { align: 'center' });
        doc.text(`Date: ${new Date(evalReport.created_at).toLocaleDateString()}`, pageWidth / 2, 146, { align: 'center' });
        addFooter(1);

        // --- PAGE 2: METRICS ---
        doc.addPage();
        doc.setFontSize(18);
        doc.setTextColor(0);
        doc.text("Evaluation Framework & Definitions", 20, 30);
        
        autoTable(doc, {
            startY: 50,
            head: [['Metric', 'Definition', 'Scientific Methodology']],
            body: [
                ['ACCURACY', 'Factual alignment with Ground Truth established by Layer 2.', 'G-Eval / GPT-Score: LLM-as-a-Judge grading.'],
                ['GROUNDING', 'Absence of hallucinations; every claim supported by a citation.', 'RAGAS Faithfulness: Verifies claims against context.'],
                ['COMPLETE', 'Coverage of all required critical details from the source.', 'Information Retrieval (Recall): Ratio of key entities found vs. total entities in Truth.'],
                ['SAFETY', 'Refusal of harmful or out-of-scope prompts.', 'Binary Classification against jailbreak patterns.'],
                ['ROBUST', 'Resistance to adversarial attacks and prompt injections.', 'Adversarial Red Teaming: Automated "Attacker LLMs" generating edge-case inputs.'],
                ['FAIRNESS', 'Statistical neutrality across demographics.', 'Counterfactual Testing: Variance in sentiment when changing names/genders.'],
                ['HUMAN', 'Alignment with expert human judgment.', 'HITL Calibration: Delta between AI Judge score and Human Expert override.']
            ],
            theme: 'grid',
            headStyles: { fillColor: primaryColor, fontSize: 10 },
            styles: { fontSize: 9, cellPadding: 4 }
        });
        addFooter(2);

        // --- PAGE 3: SUMMARY ---
        doc.addPage();
        doc.setFontSize(18);
        doc.setTextColor(...primaryColor);
        doc.text("1. Executive Summary", 20, 30);

        // Prepare Basic Summary Data
        const summaryBody = [
            ['Candidate File', evalReport.candidate_file],
            ['Reference File', evalReport.teacher_file],
            ['Total Questions', evalReport.total_turns],
            ['Average Score', `${evalReport.average_score} / 10`],
            ['Final Verdict', passed ? "PASS" : "FAIL"],
            ['Judge Model', evalReport.judge_model || "Unknown"]
        ];

        // ✅ FIX 1: Inject Domain Context into PDF
        if (domainContext) {
            summaryBody.push(['--- DOMAIN PROFILE ---', '']);
            summaryBody.push(['Domain Name', domainContext.name || "N/A"]);
            const desc = domainContext.description || "";
            // Wrap long descriptions
            const cleanDesc = desc.length > 200 ? desc.substring(0, 200) + "..." : desc;
            summaryBody.push(['Description', cleanDesc]);
        }

        // ✅ FIX 2: Inject Documents List into PDF
        if (documents && documents.length > 0) {
            summaryBody.push(['--- CONTEXT DOCUMENTS ---', `Total: ${documents.length}`]);
            documents.forEach((doc, idx) => {
                const idStr = doc.id ? `[${doc.id.substring(0,8)}]` : "[NO_ID]";
                const titleStr = doc.title || doc.name || "Untitled";
                const verStr = doc.version ? `(v${doc.version})` : "";
                
                // Add row: "Doc 1" -> "[ID] Title (Version)"
                summaryBody.push([`Document ${idx + 1}`, `${idStr} ${titleStr} ${verStr}`]);
            });
        }

        autoTable(doc, {
            startY: 40,
            head: [['Metric', 'Value']],
            body: summaryBody,
            theme: 'striped',
            headStyles: { fillColor: primaryColor },
            // Ensure long text wraps correctly in the Value column
            columnStyles: { 
                0: { cellWidth: 50, fontStyle: 'bold' },
                1: { cellWidth: 'auto' } 
            }
        });
        
        let summaryY = doc.lastAutoTable.finalY + 15;
        
        // Averages
        let totalAcc = 0, totalGnd = 0, totalComp = 0, totalSafe = 0;
        const count = evalReport.details ? evalReport.details.length : 0;
        if (count > 0) {
            evalReport.details.forEach(d => {
                const m = d.metrics || {};
                totalAcc += safeNumber(m.accuracy);
                totalGnd += safeNumber(m.grounding);
                totalComp += safeNumber(m.completeness);
                totalSafe += safeNumber(m.safety);
            });
        }
        const avgM = {
            accuracy: count ? totalAcc / count : 0,
            grounding: count ? totalGnd / count : 0,
            completeness: count ? totalComp / count : 0,
            safety: count ? totalSafe / count : 0
        };

        doc.setFontSize(12);
        doc.setTextColor(0);
        doc.text("Global 7D Performance Matrix:", 20, summaryY);
        
        autoTable(doc, {
            startY: summaryY + 5,
            head: [['ACCURACY', 'GROUNDING', 'COMPLETE', 'SAFETY', 'ROBUST', 'FAIRNESS', 'HUMAN']],
            body: [['', '', '', '', '', '', '']],
            theme: 'plain',
            styles: { cellPadding: 5, minCellHeight: 15 },
            headStyles: { fillColor: [241, 245, 249], textColor: 100, fontSize: 8, halign: 'center' },
            columnStyles: {
                0: {cellWidth: 26}, 1: {cellWidth: 26}, 2: {cellWidth: 26}, 3: {cellWidth: 26},
                4: {cellWidth: 26}, 5: {cellWidth: 26}, 6: {cellWidth: 26}
            },
            margin: { left: 14, right: 14 },
            didDrawCell: (data) => {
                if (data.section === 'body' && data.column.index !== undefined) {
                    const x = data.cell.x + 2;
                    const y = data.cell.y + 2;
                    const w = data.cell.width - 4;
                    let val = 0; 
                    let color = [200, 200, 200];
                    let label = "N/A"; 

                    if (data.column.index === 0) { val = avgM.accuracy; color = [59, 130, 246]; label = val.toFixed(1); }
                    if (data.column.index === 1) { val = avgM.grounding; color = [139, 92, 246]; label = val.toFixed(1); }
                    if (data.column.index === 2) { val = avgM.completeness; color = [234, 179, 8]; label = val.toFixed(1); }
                    if (data.column.index === 3) { val = avgM.safety; color = [16, 185, 129]; label = val.toFixed(1); }
                    
                    doc.setFontSize(9);
                    doc.setTextColor(data.column.index >= 4 ? 150 : 0);
                    doc.text(label, x, y + 4);
                    doc.setFillColor(241, 245, 249);
                    doc.rect(x, y + 6, w, 4, 'F');
                    if (val > 0) {
                        const barW = (w * val) / 10;
                        doc.setFillColor(...color);
                        doc.rect(x, y + 6, barW, 4, 'F');
                    }
                }
            }
        });

        const finalY = doc.lastAutoTable.finalY + 30;
        doc.setFontSize(14);
        doc.setTextColor(100);
        doc.text("Overall 7D Composite Score:", pageWidth/2, finalY, {align:'center'});
        doc.setFontSize(40);
        doc.setTextColor(...(passed ? [22, 163, 74] : [220, 38, 38])); 
        doc.text(`${evalReport.average_score}`, pageWidth/2, finalY + 15, {align:'center'});
        addFooter(4);

        // --- PAGE 5+: DETAILS ---
        let pageIdx = 5;
        if (evalReport.details) {
            for (let i = 0; i < evalReport.details.length; i++) {
                const item = evalReport.details[i];
                
                doc.addPage();
                doc.setFontSize(16);
                doc.setTextColor(...primaryColor);
                doc.text(`Question ${i+1}`, 20, 30);
                doc.setFontSize(11);
                doc.setTextColor(0);
                doc.text(doc.splitTextToSize(item.question, 170), 20, 40);
                
                // Metric Bar Table (safeNumber in case API stored dicts)
                const m = item.metrics || {};
                const mAcc = safeNumber(m.accuracy);
                const mGnd = safeNumber(m.grounding);
                const mComp = safeNumber(m.completeness);
                const mSafe = safeNumber(m.safety);
                autoTable(doc, {
                    startY: 60,
                    head: [['ACCURACY', 'GROUNDING', 'COMPLETE', 'SAFETY', 'ROBUST', 'FAIRNESS', 'HUMAN']],
                    body: [['', '', '', '', '', '', '']],
                    theme: 'plain',
                    styles: { cellPadding: 5, minCellHeight: 15 },
                    headStyles: { fillColor: [241, 245, 249], textColor: 100, fontSize: 7, halign: 'center' },
                    columnStyles: {
                        0: {cellWidth: 26}, 1: {cellWidth: 26}, 2: {cellWidth: 26}, 3: {cellWidth: 26},
                        4: {cellWidth: 26}, 5: {cellWidth: 26}, 6: {cellWidth: 26}
                    },
                    margin: { left: 14, right: 14 },
                    didDrawCell: (data) => {
                        if (data.section === 'body' && data.column.index !== undefined) {
                            const x = data.cell.x + 2;
                            const y = data.cell.y + 2;
                            const w = data.cell.width - 4;
                            let val = 0; 
                            let color = [200, 200, 200];
                            let label = "N/A"; 

                            if (data.column.index === 0) { val = mAcc; color = [59, 130, 246]; label = val.toFixed(1); }
                            if (data.column.index === 1) { val = mGnd; color = [139, 92, 246]; label = val.toFixed(1); }
                            if (data.column.index === 2) { val = mComp; color = [234, 179, 8]; label = val.toFixed(1); }
                            if (data.column.index === 3) { val = mSafe; color = [16, 185, 129]; label = val.toFixed(1); }
                            if (data.column.index >= 4) { color = [226, 232, 240]; label = "N/A"; val = 0; }

                            doc.setFontSize(8);
                            doc.setTextColor(data.column.index >= 4 ? 150 : 0);
                            doc.text(label, x, y + 4);
                            doc.setFillColor(241, 245, 249);
                            doc.rect(x, y + 6, w, 4, 'F');
                            if (val > 0) {
                                const barW = (w * val) / 10;
                                doc.setFillColor(...color);
                                doc.rect(x, y + 6, barW, 4, 'F');
                            }
                        }
                    }
                });

                // Process Text (Extract Images & Label Source)
                const candProcessed = await processContentForPDF(item.candidate_answer, "Student (CORA) Chart");
                const teacherProcessed = await processContentForPDF(item.reference_answer, "Teacher (Truth) Chart");
                
                // Process Evidence Images
                const evidenceImages = [];
                let studentEv = "No grounding provided.";
                
                if (item.student_evidence && item.student_evidence.length > 0) {
                    const evPromises = item.student_evidence.map(async (g, idx) => {
                        if (g.type === "Link") return `[REF ${idx+1}]: ${g.doc_name}\n${g.text}`;
                        
                        const chunkProcessed = await processContentForPDF(g.text || "", `Evidence Chart (Source: ${g.doc_name})`);
                        if(chunkProcessed.images.length > 0) evidenceImages.push(...chunkProcessed.images);
                        
                        return `[DOC ${idx+1}]: ${g.doc_name}\n"${chunkProcessed.cleanText.substring(0, 300)}..."`;
                    });
                    const evLines = await Promise.all(evPromises);
                    studentEv = evLines.join("\n\n");
                }
                
                let teacherEv = item.teacher_context || "No context.";

                // Draw Main Comparison Table
                autoTable(doc, {
                    startY: doc.lastAutoTable.finalY + 10,
                    head: [['Teacher (Truth)', 'Student (CORA)', 'Judge Analysis']],
                    body: [[
                        `${teacherProcessed.cleanText}\n\n[Context]:\n${teacherEv}`,
                        `${candProcessed.cleanText}\n\n[Evidence]:\n${studentEv}`,
                        `VERDICT: ${item.failure_category}\n\nREASONING:\n${item.judge_verdict}`
                    ]],
                    theme: 'grid',
                    styles: { fontSize: 8, cellPadding: 4, overflow: 'linebreak' },
                    columnStyles: { 0: { cellWidth: 65 }, 1: { cellWidth: 65 }, 2: { cellWidth: 50 } },
                    headStyles: { fillColor: [59, 130, 246] }, 
                    margin: { left: 14, right: 14 }
                });

                // EMBED IMAGES WITH HEADINGS (Reduced Size 80x60)
                let currentY = doc.lastAutoTable.finalY + 10;
                const allImages = [...candProcessed.images, ...teacherProcessed.images, ...evidenceImages];
                
                if (allImages.length > 0) {
                    for (const imgObj of allImages) {
                        if (currentY > pageHeight - 80) { doc.addPage(); currentY = 20; }
                        try {
                            doc.setFontSize(8);
                            doc.setTextColor(220, 38, 38); // Red color for visibility
                            doc.text(`FIGURE FROM: ${imgObj.label}`, 20, currentY);
                            
                            // Smaller Size: 80x60
                            doc.addImage(imgObj.data, "JPEG", 20, currentY + 2, 80, 60); 
                            currentY += 70; // Spacing for next image
                        } catch (err) { console.warn("Image rendering failed", err); }
                    }
                }

                addFooter(pageIdx);
                pageIdx++;
            }
        }

        doc.save(`AXIOM_Audit_${evalReport.created_at.slice(0,10)}.pdf`);
    } catch(e) { alert("PDF Error"); }
    setGeneratingPdf(false);
  };

  return (
    <div className="animate-fade" style={{height:'100%', display:'flex', flexDirection:'column'}}>
      <header className="header" style={{flexShrink:0}}><h1>Layer 4: Evaluation Dashboard</h1></header>
      
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
            {['all', 'SingleDoc', 'Discovery', 'Project', 'UserDoc', 'Root'].map(m => (
                <button key={m} onClick={() => setCurrentMode(m)} className={`btn btn-sub ${currentMode === m ? 'active' : ''}`}>
                    {m === 'Root' ? 'Uncategorized' : m.replace('Doc', ' Doc')}
                </button>
            ))}
      </div>

      <div className="grid-2" style={{flex:1, overflow:'hidden', padding:'0 20px 20px 20px'}}>
           {/* LEFT: SUMMARY */}
           <div style={{display:'flex', flexDirection:'column', gap:'20px', overflowY: 'auto'}}>
                <div className="card" style={{display:'flex', gap:'10px', alignItems:'center', padding:'15px'}}>
                    <PieChart size={20} color="#64748b"/>
                    <select value={selectedEvaluation} onChange={(e) => loadReport(e.target.value)} style={{flex:1, fontSize:'1rem', padding:'8px'}}>
                        <option value="">-- Select Report --</option>
                        {filteredEvaluations.map(item => (
                            <option key={item.relative_path} value={item.relative_path}>
                                {item.filename.replace("Judge_", "").replace(".json", "")}
                            </option>
                        ))}
                    </select>
                </div>

                {evalReport && (
                    <>
                        <div className="card" style={{borderLeft: passed ? '5px solid #16a34a' : '5px solid #dc2626', textAlign:'center', padding:'25px'}}>
                            <div style={{fontSize:'0.85rem', color:'#64748b', fontWeight:'bold', letterSpacing:'1px', marginBottom:'5px'}}>7D COMPOSITE SCORE</div>
                            <div style={{fontSize:'4rem', fontWeight:'900', color: passed ? '#16a34a' : '#dc2626', lineHeight:'1', marginBottom:'10px'}}>
                                {overall}
                                <span style={{fontSize:'1.5rem', color:'#94a3b8', fontWeight:'normal'}}>/10</span>
                            </div>
                            <div style={{fontWeight:'bold', color: passed ? '#16a34a' : '#dc2626', background: passed ? '#dcfce7' : '#fee2e2', display:'inline-block', padding:'6px 16px', borderRadius:'20px', fontSize:'0.9rem'}}>
                                {passed ? "PASSING" : "FAIL"}
                            </div>
                            
                            {/* ✅ FEATURE 2: DOCUMENT METADATA DISPLAY */}
                            {documents.length > 0 && (
                                <div style={{marginTop: '25px', paddingTop: '15px', borderTop: '1px solid #f1f5f9', textAlign: 'left'}}>
                                    <div style={{fontSize:'0.75rem', fontWeight:'bold', color:'#64748b', marginBottom:'10px', display:'flex', alignItems:'center', gap:'5px'}}>
                                        <BookOpen size={12}/> CONTEXT DOCUMENTS ({documents.length})
                                    </div>
                                    <div style={{maxHeight: '150px', overflowY: 'auto', display:'flex', flexDirection:'column', gap:'8px'}}>
                                        {documents.map((doc, idx) => (
                                            <div key={idx} style={{background: '#f8fafc', padding: '8px', borderRadius: '4px', border: '1px solid #e2e8f0'}}>
                                                <div style={{fontWeight:'600', fontSize:'0.8rem', color:'#334155', marginBottom:'2px'}}>
                                                    {doc.title || "Untitled Document"}
                                                </div>
                                                <div style={{fontSize:'0.7rem', color:'#94a3b8', display:'flex', gap:'10px'}}>
                                                    <span style={{display:'flex', alignItems:'center', gap:'3px'}}><Hash size={10}/> {doc.id ? doc.id.substring(0,8) : 'N/A'}</span>
                                                    {doc.version && <span style={{display:'flex', alignItems:'center', gap:'3px'}}><Activity size={10}/> Ver: {doc.version}</span>}
                                                    {doc.created_at && <span style={{display:'flex', alignItems:'center', gap:'3px'}}><Calendar size={10}/> {doc.created_at.slice(0,10)}</span>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* ✅ FEATURE 3: DOMAIN PROFILE DISPLAY */}
                            {domainContext && (
                                <div style={{marginTop: '15px', paddingTop: '15px', borderTop: '1px solid #f1f5f9', textAlign: 'left'}}>
                                    <div style={{fontSize:'0.75rem', fontWeight:'bold', color:'#7c3aed', marginBottom:'8px', display:'flex', alignItems:'center', gap:'5px'}}>
                                        <BrainCircuit size={12}/> DOMAIN PROFILE
                                    </div>
                                    <div style={{background: '#f5f3ff', padding: '10px', borderRadius: '4px', border: '1px solid #ddd6fe'}}>
                                        <div style={{fontWeight:'700', fontSize:'0.8rem', color:'#5b21b6', marginBottom:'4px'}}>
                                            {domainContext.name || "Custom Domain"}
                                        </div>
                                        <div style={{fontSize:'0.75rem', color:'#6d28d9', fontStyle:'italic', lineHeight:'1.3'}}>
                                            "{domainContext.description || "No description provided."}"
                                        </div>
                                    </div>
                                </div>
                            )}

                            <button onClick={handleDownloadPDF} disabled={generatingPdf} style={{marginTop:'20px', width:'100%', padding:'10px', border:'1px solid #e2e8f0', background:'white', borderRadius:'6px', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:'8px', color:'#475569'}}>
                                {generatingPdf ? <Loader2 className="spin" size={16}/> : <Download size={16}/>} {generatingPdf ? "Processing Visual Evidence..." : "Download 7D Audit PDF"}
                            </button>
                        </div>
                    </>
                )}
           </div>

           {/* RIGHT: DETAILS */}
           <div style={{overflowY:'auto'}}>
               {evalReport && evalReport.details ? evalReport.details.map((item, idx) => {
                   const itemScore = safeNumber(item.score);
                   return (
                   <div key={idx} className="card" style={{borderLeft: itemScore >= 7 ? '3px solid #16a34a' : '3px solid #dc2626', marginBottom:'15px'}}>
                       <div style={{display:'flex', justifyContent:'space-between', marginBottom:'10px'}}>
                           <div style={{fontWeight:600, fontSize:'0.9rem', color:'#1e293b'}}>Q{idx+1}: {item.question}</div>
                           <div style={{background: itemScore >= 7 ? '#dcfce7' : '#fee2e2', color: itemScore >= 7 ? '#166534' : '#991b1b', fontWeight:'bold', padding:'4px 8px', borderRadius:'6px', fontSize:'0.8rem'}}>
                               {itemScore}/10
                           </div>
                       </div>
                       
                       <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:'8px', marginBottom:'15px', background:'#f8fafc', padding:'10px', borderRadius:'6px'}}>
                           <MetricBar label="ACCURACY" value={item.metrics?.accuracy} color="#3b82f6" />
                           <MetricBar label="GROUNDING" value={item.metrics?.grounding} color="#8b5cf6" />
                           <MetricBar label="COMPLETE" value={item.metrics?.completeness} color="#eab308" />
                           <MetricBar label="SAFETY" value={item.metrics?.safety} color="#10b981" />
                       </div>

                       <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'10px', fontSize:'0.85rem', marginBottom:'10px'}}>
                            <div style={{background:'#f8fafc', padding:'10px', borderRadius:'6px', border:'1px solid #e2e8f0'}}>
                                <div style={{fontWeight:'bold', color:'#64748b', fontSize:'0.7rem', marginBottom:'4px', display:'flex', alignItems:'center', gap:'4px'}}><FileText size={10}/> STUDENT</div>
                                <ContentWithImages text={item.candidate_answer} type="student" />
                            </div>
                            <div style={{background:'#f0fdf4', padding:'10px', borderRadius:'6px', border:'1px solid #bbf7d0'}}>
                                <div style={{fontWeight:'bold', color:'#166534', fontSize:'0.7rem', marginBottom:'4px', display:'flex', alignItems:'center', gap:'4px'}}><CheckCircle2 size={10}/> TEACHER</div>
                                <ContentWithImages text={item.reference_answer} type="truth" />
                            </div>
                       </div>

                       <div style={{marginTop:'10px', background:'#eff6ff', padding:'10px', borderRadius:'6px', border:'1px solid #bfdbfe', fontSize:'0.8rem'}}>
                           <div style={{color:'#1e40af', fontWeight:'bold', marginBottom:'6px', display:'flex', alignItems:'center', gap:'4px'}}>
                               <Database size={10}/> EVIDENCE SOURCES
                           </div>
                           {item.student_evidence && item.student_evidence.map((g, gi) => (
                               <div key={gi} style={{marginBottom:'10px', paddingBottom:'10px', borderBottom: gi < item.student_evidence.length-1 ? '1px dashed #bfdbfe' : 'none'}}>
                                   <div style={{fontWeight:'bold', color: g.type === "Link" ? '#16a34a' : '#3b82f6', display:'flex', alignItems:'center', gap:'5px'}}>
                                       {g.type === "Link" ? <LinkIcon size={10}/> : <BookOpen size={10}/>}
                                       [{g.doc_id ? g.doc_id.substring(0,6) : 'UNK'}] {g.doc_name}
                                   </div>
                                   <ContentWithImages text={g.text} type="evidence" />
                               </div>
                           ))}
                       </div>

                       <div style={{marginTop:'10px', paddingTop:'8px', borderTop:'1px solid #f1f5f9', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
                           <div style={{fontSize:'0.85rem', color:'#64748b', fontStyle:'italic'}}><strong>Judge:</strong> "{item.judge_verdict}"</div>
                       </div>
                   </div>
                   );
               }) : (
                   <div style={{textAlign:'center', color:'#94a3b8', marginTop:'50px'}}>Select a report to view detailed audit.</div>
               )}
           </div>
      </div>
    </div>
  );
}