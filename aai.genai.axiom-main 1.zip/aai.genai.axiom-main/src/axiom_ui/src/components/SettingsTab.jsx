import { useState, useEffect } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';
import { API_BASE } from '../api';

export default function SettingsTab() {
  const [keys, setKeys] = useState({ openai: "", anthropic: "", gemini: "" });
  const [status, setStatus] = useState({ openai: false, anthropic: false, gemini: false });
  const [loading, setLoading] = useState("");

  useEffect(() => {
    fetch(`${API_BASE}/settings/status`)
      .then(r => r.json())
      .then(setStatus)
      .catch(err => console.error("Settings load error:", err));
  }, []);

  const verifyKey = async (provider) => {
    setLoading(provider);
    try {
      const res = await fetch(`${API_BASE}/settings/key`, {
        method: 'POST', 
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ provider, key: keys[provider] })
      });
      if(res.ok) {
        setStatus(prev => ({...prev, [provider]: true}));
        alert(`✅ ${provider} Connected!`);
      } else throw new Error("Failed");
    } catch { 
      alert("❌ Connection Failed"); 
    } finally { 
      setLoading(""); 
    }
  };

  return (
    <div className="animate-fade">
      <header className="header"><h1>Settings & Connections</h1></header>
      <div className="card" style={{maxWidth:'600px'}}>
        <h3>🔌 AI Provider Keys</h3>
        <p style={{fontSize:'0.9rem', color:'#64748b'}}>Enter API keys to enable cloud brains.</p>
        
        {["openai", "anthropic", "gemini"].map(prov => (
          <div key={prov} style={{marginTop:'20px', padding:'15px', background:'#f8fafc', borderRadius:'8px', border:'1px solid #e2e8f0'}}>
            <div style={{display:'flex', justifyContent:'space-between', marginBottom:'10px'}}>
               <div style={{fontWeight:'bold', textTransform:'capitalize'}}>{prov}</div>
               {status[prov] ? <span style={{color:'#16a34a', fontSize:'0.8rem', display:'flex', gap:'5px'}}><CheckCircle size={14}/> Connected</span> 
                             : <span style={{color:'#94a3b8', fontSize:'0.8rem', display:'flex', gap:'5px'}}><XCircle size={14}/> Not Configured</span>}
            </div>
            <div style={{display:'flex', gap:'10px'}}>
               <input 
                 type="password" 
                 placeholder={`sk-...`} 
                 value={keys[prov]} 
                 onChange={e => setKeys({...keys, [prov]: e.target.value})} 
                 style={{flex:1}} 
               />
               <button className="btn btn-primary" onClick={() => verifyKey(prov)} disabled={loading===prov} style={{width:'auto'}}>
                  {loading===prov ? "Testing..." : "Verify"}
               </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}