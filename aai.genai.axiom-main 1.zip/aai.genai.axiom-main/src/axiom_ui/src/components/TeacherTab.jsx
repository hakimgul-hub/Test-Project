import { useState, useEffect, useRef } from 'react';
import { 
  FileText, Globe, Folder, UploadCloud, Database, RefreshCw, AlertCircle, 
  Loader2, Bug, CheckSquare, Square, X, Cpu, CheckCircle2, AlertTriangle, 
  Calendar, Hash, FileJson, ChevronDown, ChevronRight, Play, Activity,
  Plus, Trash2, Layers, Clock, Eye, Terminal, Eraser 
} from 'lucide-react';
import { API_BASE } from '../api';

// ✅ SIMPLE MEMORY CACHE (Survives tab switching, clears on refresh)
let GLOBAL_TASK_MEMORY = [];

export default function TeacherTab() {
  // --- STATE ---
  const [subMode, setSubMode] = useState('single_doc'); 
  
  // Selection State
  const [strategy, setStrategy] = useState("");
  const [persona, setPersona] = useState("");     
  const [technique, setTechnique] = useState(""); 
  const [examType, setExamType] = useState("static");
  const [density, setDensity] = useState(10);     
  
  // Model Selection
  const [selectedGenModels, setSelectedGenModels] = useState([]);
  const [availableModels, setAvailableModels] = useState([]);
  const [modelStatuses, setModelStatuses] = useState({}); 

  // Context State
  const [contextText, setContextText] = useState(""); 
  const [topic, setTopic] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [libraryResults, setLibraryResults] = useState([]);
  
  // Doc Selection
  const [selectedDocMeta, setSelectedDocMeta] = useState(null); 
  const [projectDocs, setProjectDocs] = useState([]);           
  
  // Results
  const [l1Results, setL1Results] = useState([]); 
  const [groupedResults, setGroupedResults] = useState({}); 
  const [runStats, setRunStats] = useState(null); 
  const [openAccordions, setOpenAccordions] = useState({}); 

  // ✅ LOAD FROM MEMORY
  const [activeTasks, setActiveTasks] = useState(GLOBAL_TASK_MEMORY);
  const [statusMessage, setStatusMessage] = useState("");
  const [expandedTask, setExpandedTask] = useState(null);

  // Config
  const [strategyList, setStrategyList] = useState([]);
  const [personaList, setPersonaList] = useState([]);
  const [modeConfig, setModeConfig] = useState({});
  const [examTypes, setExamTypes] = useState({}); 
  const [densityConfig, setDensityConfig] = useState({});
  const [configLoading, setConfigLoading] = useState(true);

  // 🛡️ CONCURRENCY GUARD
  const activeSessionRef = useRef(0);

  // ✅ SYNC TO MEMORY
  useEffect(() => {
      GLOBAL_TASK_MEMORY = activeTasks;
  }, [activeTasks]);

  // --- 1. FETCH CONFIG ---
  useEffect(() => {
    setConfigLoading(true);
    fetch(`${API_BASE}/config/layer1`)
      .then(r => r.json())
      .then(data => {
         setStrategyList(data.strategies || []);
         setPersonaList(data.personas || []);
         setModeConfig(data.modes || {});
         setExamTypes(data.rest_config?.exam_types || { "static": { "label": "Static" } });
         setDensityConfig(data.rest_config?.density_settings || { "min": 1, "max": 50, "default": 10 });
         
         if(data.strategies?.length > 0) setStrategy(data.strategies[0].id);
         if(data.personas?.length > 0) setPersona(data.personas[0].id);
         if(data.rest_config?.density_settings) setDensity(data.rest_config.density_settings.default);
      })
      .catch(console.error);

    fetch(`${API_BASE}/config/llms`)
      .then(r => r.json())
      .then(data => {
          setAvailableModels(data);
          if(data.length > 0) setSelectedGenModels([data[0].id]);
          setConfigLoading(false);
      })
      .catch(console.error);
  }, []);

  // --- 2. LIVE TIMER EFFECT ---
  useEffect(() => {
    if (activeTasks.length === 0) return;
    const interval = setInterval(() => {
        setActiveTasks(prev => prev.map(task => ({
            ...task,
            duration: Math.floor((Date.now() - task.timestamp) / 1000)
        })));
    }, 1000);
    return () => clearInterval(interval);
  }, [activeTasks.length]);

  // --- 3. STRICT CONTEXT RESET ---
  useEffect(() => {
    activeSessionRef.current += 1; 
    setContextText(""); setTopic(""); setSearchQuery(""); setLibraryResults([]);
    if (subMode !== 'single_doc') setSelectedDocMeta(null);
    if (subMode !== 'project') setProjectDocs([]);
    setL1Results([]); setGroupedResults({}); setRunStats(null); setModelStatuses({});
  }, [subMode]);

  // --- 4. DYNAMIC CONFIG ---
  const getJsonModeKey = () => {
      if (subMode === 'single_doc') return 'single_document';
      if (subMode === 'user_doc') return 'user_document';
      return subMode;
  }
  const availableTechniques = modeConfig[getJsonModeKey()]?.allowed_strategies || ["Standard Generation"];
  useEffect(() => { if (availableTechniques.length > 0) setTechnique(availableTechniques[0]); }, [subMode, modeConfig]);

  // --- HANDLERS ---
  const handleToggleModel = (id) => setSelectedGenModels(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  const handleLibrarySearch = async () => {
    if(!searchQuery) return;
    try {
        const res = await fetch(`${API_BASE}/library/search?q=${searchQuery}`);
        setLibraryResults(await res.json());
    } catch(err) { alert(err.message); }
  };

  const selectSingleDoc = async (doc) => {
    setSelectedDocMeta(doc);
    try {
        const res = await fetch(`${API_BASE}/library/${doc.id}`);
        const data = await res.json();
        setContextText(data.text || data.content || "");
        setSelectedDocMeta(prev => ({ ...prev, ...data })); // Merge full metadata
        setLibraryResults([]); 
    } catch(err) { alert(err.message); }
  };

  const addProjectDoc = (doc) => {
      if (!projectDocs.find(d => d.id === doc.id)) setProjectDocs([...projectDocs, doc]);
      setLibraryResults([]); setSearchQuery("");
  };

  const removeProjectDoc = (id) => setProjectDocs(prev => prev.filter(d => d.id !== id));

  const clearTask = (taskId) => {
      setActiveTasks(prev => prev.filter(t => t.id !== taskId));
  };

  // --- GENERATE LOGIC (RICH METADATA) ---
  const handleGenerate = async () => {
    if(selectedGenModels.length === 0) { alert("Please select a model."); return; }
    
    // --- CONSTRUCT RICH PAYLOAD ---
    let currentContext = contextText;
    let sourceMeta = { 
        source_type: subMode,
        domain_id: strategy,
        technique: technique
    };

    if (subMode === 'discovery') {
        currentContext = topic;
        sourceMeta = { 
            source_type: "Discovery", 
            topic: topic,
            query: topic
        };
    } else if (subMode === 'single_doc') {
        // Send IDs so backend can fetch chunks from DB
        sourceMeta = { 
            source_type: "Single Doc",
            id: selectedDocMeta?.id, 
            document_id: selectedDocMeta?.id,
            document_title: selectedDocMeta?.title,
            document_version: selectedDocMeta?.version,
            document_summary: selectedDocMeta?.summary || "No summary available."
        };
    } else if (subMode === 'project') {
        currentContext = projectDocs.map(d => d.title).join(", "); 
        // Send list of IDs for chunk fetching + metadata for report
        sourceMeta = { 
            source_type: "Project", 
            project_name: "Custom Project Collection",
            id: projectDocs.map(d => d.id), // Backend uses this to get text
            documents: projectDocs.map(d => ({ 
                id: d.id, 
                title: d.title, 
                version: d.version || '1.0' 
            })) 
        };
        // Placeholder so backend knows to ignore 'context' string and use DB chunks
        if (projectDocs.length > 0) currentContext = "Project Content Placeholder"; 
    } else {
        currentContext = contextText;
        sourceMeta = { source_type: "User Upload", filename: "Uploaded File" };
    }

    if ((!currentContext || currentContext.length < 50) && technique === "Strict Context") {
         alert("⚠️ Strict Context requires actual content!"); return;
    }

    // Init Run
    const currentSessionId = activeSessionRef.current;
    const taskId = Date.now();
    const taskName = subMode === 'single_doc' ? 'Single Doc Gen' : subMode === 'project' ? 'Project Gen' : 'Discovery Gen';
    
    const payload = { 
        domain: strategy, 
        persona: persona, 
        technique: technique, 
        context: currentContext, 
        count: parseInt(density), 
        source_metadata: sourceMeta, // ✅ RICH METADATA SENT HERE
        exam_type: examType, 
        models: selectedGenModels 
    };

    setActiveTasks(prev => [...prev, { 
        id: taskId, 
        name: taskName, 
        timestamp: Date.now(), 
        duration: 0,
        payload: payload,
        status: 'running'
    }]);

    setL1Results([]); setGroupedResults({}); setRunStats(null); 
    setStatusMessage("Initializing...");
    
    const initStatus = {};
    selectedGenModels.forEach(m => initStatus[m] = "running");
    setModelStatuses(initStatus); 

    try {
      const response = await fetch(`${API_BASE}/generate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload) 
      });

      const res = await response.json(); 
      if (!response.ok) throw new Error(res.detail || "Server Error");

      if (activeSessionRef.current === currentSessionId) {
          const data = res.data || [];
          setL1Results(data); 
          
          const groups = {};
          const successModels = new Set();
          data.forEach(item => {
              const gens = item.generator_model ? [item.generator_model] : (item.generators || []);
              gens.forEach(gen => {
                  if(!groups[gen]) groups[gen] = [];
                  groups[gen].push(item);
                  successModels.add(gen);
              });
          });
          setGroupedResults(groups);
          setOpenAccordions(Object.keys(groups).reduce((acc, k) => ({...acc, [k]: true}), {}));

          const finalStatus = { ...initStatus };
          let failCount = 0;
          selectedGenModels.forEach(m => {
              if (successModels.has(m)) finalStatus[m] = "success";
              else { finalStatus[m] = "error"; failCount++; }
          });
          setModelStatuses(finalStatus);
          setRunStats({ total: data.length, success: successModels.size, fail: failCount });
          setStatusMessage("Generation Complete!");
      }

    } catch (err) { 
        if (activeSessionRef.current === currentSessionId) {
            alert("Error: " + err.message); 
            setModelStatuses(selectedGenModels.reduce((acc, m) => ({...acc, [m]: "error"}), {}));
        }
    } finally {
        setActiveTasks(prev => prev.filter(t => t.id !== taskId));
    }
  };
  
  const formatDate = (dateStr) => { try { return new Date(dateStr).toLocaleDateString(); } catch (e) { return dateStr; } };
  const formatDuration = (sec) => {
      const m = Math.floor(sec / 60);
      const s = sec % 60;
      return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="animate-fade" style={{
        position:'relative', 
        paddingRight: activeTasks.length > 0 ? '340px' : '0', 
        transition: 'padding-right 0.3s ease-in-out'
    }}>
      
      {/* HEADER */}
      <header className="header" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <h1>Layer 1: Curriculum Generation</h1>
      </header>
      
      {/* TABS */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
        {['single_doc', 'discovery', 'project', 'user_doc'].map(m => (
            <button key={m} onClick={() => setSubMode(m)} className={`btn btn-sub ${subMode === m ? 'active' : ''}`} style={{textTransform:'capitalize'}}>
                {m === 'single_doc' && <FileText size={16}/>}
                {m === 'discovery' && <Globe size={16}/>}
                {m === 'project' && <Folder size={16}/>}
                {m === 'user_doc' && <UploadCloud size={16}/>}
                {m.replace('_', ' ')}
            </button>
        ))}
      </div>

      <div className="grid-2">
        {/* LEFT: CONFIG */}
        <div className="card" style={{ height: 'fit-content' }}>
          <h3>🛠️ Configuration</h3>
          {configLoading ? <div style={{textAlign:'center'}}><Loader2 className="spin"/></div> : (
             <>
               <div className="input-group">
                  <label>Strategy (Domain Profile)</label>
                  <select value={strategy} onChange={(e) => setStrategy(e.target.value)}>
                      {strategyList.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
               </div>
               
               <div className="input-group">
                  <label>Teacher Models ({selectedGenModels.length})</label>
                  <div style={{maxHeight:'150px', overflowY:'auto', border:'1px solid #e2e8f0', borderRadius:'6px', padding:'5px', background:'#f8fafc'}}>
                     {availableModels.map(m => {
                        const ok = m.status === 'available';
                        const unavailable = m.status === 'unavailable';
                        const statusLabel = ok ? 'Online' : (unavailable ? 'Unavailable' : 'Not set up');
                        const statusColor = ok ? '#22c55e' : (unavailable ? '#94a3b8' : '#eab308');
                        return (
                        <div key={m.id} onClick={() => handleToggleModel(m.id)} 
                             style={{display:'flex', gap:'8px', padding:'6px', cursor:'pointer', borderBottom:'1px solid #f1f5f9', alignItems:'center', background: selectedGenModels.includes(m.id) ? '#eff6ff' : 'transparent'}}>
                           {selectedGenModels.includes(m.id) ? <CheckSquare size={16} color="#3b82f6"/> : <Square size={16} color="#94a3b8"/>}
                           <div style={{fontSize:'0.85rem', flex:1}}>{m.name}</div>
                           <span style={{fontSize:'0.7rem', color: statusColor, fontWeight:500}}>{statusLabel}</span>
                        </div>
                     );})}
                  </div>
               </div>

               <div className="input-group">
                  <label>Teacher Persona</label>
                  <select value={persona} onChange={(e) => setPersona(e.target.value)}>
                      {personaList.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
               </div>

               <div className="input-group">
                  <label>Technique</label>
                  <select value={technique} onChange={(e) => setTechnique(e.target.value)}>
                      {availableTechniques.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
               </div>

               <div className="input-group">
                  <label style={{display:'flex', justifyContent:'space-between'}}>
                     <span>{densityConfig.label || "Density"}</span><span style={{fontWeight:'bold', color:'#3b82f6'}}>{density}</span>
                  </label>
                  <input type="range" min={densityConfig.min || 1} max={densityConfig.max || 50} value={density} onChange={(e) => setDensity(e.target.value)} style={{width:'100%'}} />
               </div>

               {selectedGenModels.some(id => availableModels.find(m => m.id === id)?.status !== 'available') && (
                  <div style={{fontSize:'0.75rem', color:'#eab308', marginBottom:'8px', display:'flex', alignItems:'center', gap:'6px'}}>
                      <AlertTriangle size={14}/> One or more selected models are not set up. Pull the model in Ollama or add API keys in Settings.
                  </div>
               )}
               <button 
                  className="btn btn-primary" 
                  onClick={handleGenerate} 
                  disabled={activeTasks.length > 3 || selectedGenModels.length === 0 || selectedGenModels.some(id => availableModels.find(m => m.id === id)?.status !== 'available')}
                  style={selectedGenModels.some(id => availableModels.find(m => m.id === id)?.status !== 'available') ? {opacity: 0.7, cursor: 'not-allowed'} : {}}
               >
                  {activeTasks.length > 0 ? "🚀 Start Another Run" : "🚀 Start Generation"}
               </button>
             </>
          )}
        </div>

        {/* RIGHT: CONTENT & RESULTS */}
        <div className="card">
           {/* SINGLE DOC */}
           {subMode === 'single_doc' && (
             <>
                <div style={{display:'flex', gap:'10px', marginBottom:'10px'}}>
                     <input type="text" placeholder="Enter CELEX ID or Title..." value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} style={{flex:1}}/>
                     <button onClick={handleLibrarySearch} style={{padding:'0 15px', borderRadius:'6px', border:'1px solid #cbd5e1', cursor:'pointer'}}><Database size={16}/></button>
                </div>
                {libraryResults.length > 0 && (
                  <div style={{marginBottom:'15px', border:'1px solid #e2e8f0', maxHeight:'150px', overflowY:'auto', borderRadius:'6px', background:'white'}}>
                      {libraryResults.map(doc => (
                          <div key={doc.id} onClick={() => selectSingleDoc(doc)} 
                              style={{padding:'8px', borderBottom:'1px solid #f1f5f9', cursor:'pointer', fontSize:'0.9rem', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                              <div style={{fontWeight:500}}>{doc.title}</div>
                              <div style={{fontSize:'0.75rem', color:'#64748b'}}>{doc.id}</div>
                          </div>
                      ))}
                  </div>
                )}
                {selectedDocMeta && (
                   <div style={{background:'#f0fdf4', padding:'15px', borderRadius:'8px', border:'1px solid #bbf7d0', marginBottom:'15px', fontSize:'0.85rem', position:'relative'}}>
                        <div style={{fontWeight:'bold', color:'#166534', marginBottom:'10px', display:'flex', alignItems:'center', gap:'8px', borderBottom:'1px solid #bbf7d0', paddingBottom:'8px'}}>
                            <FileText size={16}/> {selectedDocMeta.title || "Untitled Document"}
                        </div>
                        <button onClick={() => {setSelectedDocMeta(null); setContextText("");}} style={{position:'absolute', top:'12px', right:'12px', border:'none', background:'none', cursor:'pointer', color:'#15803d'}}><X size={18}/></button>
                        <div style={{display:'grid', gridTemplateColumns:'auto 1fr', gap:'8px 20px', alignItems:'baseline'}}>
                            <span style={{color:'#15803d', fontWeight:600}}><Hash size={10} style={{display:'inline'}}/> UUID:</span> <span style={{fontFamily:'monospace'}}>{selectedDocMeta.id}</span>
                            <span style={{color:'#15803d', fontWeight:600}}><Calendar size={10} style={{display:'inline'}}/> Date:</span> <span>{formatDate(selectedDocMeta.created_at || selectedDocMeta.date)}</span>
                            <span style={{color:'#15803d', fontWeight:600}}><RefreshCw size={10} style={{display:'inline'}}/> Ver:</span> <span>{selectedDocMeta.version || '1.0'}</span>
                        </div>
                   </div>
                )}
                <textarea value={contextText} onChange={(e)=>setContextText(e.target.value)} placeholder="Content Preview..." style={{width:'100%', height: '150px', marginBottom:'20px', fontFamily:'monospace', fontSize:'0.85rem', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '10px'}}/>
             </>
           )}

           {/* PROJECT */}
           {subMode === 'project' && (
             <div>
                 <div style={{display:'flex', gap:'10px', marginBottom:'10px'}}>
                     <input type="text" placeholder="Add Document to Project (Search)..." value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} style={{flex:1}}/>
                     <button onClick={handleLibrarySearch} style={{padding:'0 15px', borderRadius:'6px', border:'1px solid #cbd5e1', cursor:'pointer'}}><Plus size={16}/></button>
                 </div>
                 {libraryResults.length > 0 && (
                  <div style={{marginBottom:'15px', border:'1px solid #e2e8f0', maxHeight:'150px', overflowY:'auto', borderRadius:'6px', background:'white'}}>
                      {libraryResults.map(doc => (
                          <div key={doc.id} onClick={() => addProjectDoc(doc)} style={{padding:'8px', cursor:'pointer', display:'flex', justifyContent:'space-between'}}><div style={{fontWeight:500}}>{doc.title}</div><Plus size={14}/></div>
                      ))}
                  </div>
                )}
                <div style={{border:'1px dashed #cbd5e1', borderRadius:'8px', padding:'15px', background:'#f8fafc', minHeight:'100px', marginBottom:'15px'}}>
                    {projectDocs.length === 0 ? <div style={{color:'#94a3b8', textAlign:'center', fontSize:'0.9rem'}}>No documents added.</div> : (
                        <div style={{display:'flex', flexDirection:'column', gap:'8px'}}>
                            {projectDocs.map((doc, i) => (
                                <div key={i} style={{background:'white', border:'1px solid #e2e8f0', borderRadius:'6px', padding:'8px', display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:'0.9rem'}}>
                                    <div style={{display:'flex', alignItems:'center', gap:'8px'}}>
                                        <FileText size={14} color="#64748b"/>
                                        <span style={{fontWeight:500}}>{doc.title}</span>
                                        <span style={{fontSize:'0.7rem', background:'#e2e8f0', padding:'2px 6px', borderRadius:'4px', color:'#475569'}}>{doc.id}</span>
                                    </div>
                                    <Trash2 size={14} color="#ef4444" style={{cursor:'pointer'}} onClick={() => removeProjectDoc(doc.id)}/>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                <div style={{fontSize:'0.8rem', color:'#64748b'}}><Layers size={12} style={{display:'inline', marginRight:'4px'}}/> {projectDocs.length} documents selected.</div>
             </div>
           )}

           {/* DISCOVERY */}
           {subMode === 'discovery' && (
             <div style={{marginBottom: '20px'}}>
                 <label style={{display:'block', marginBottom:'5px', fontWeight:'bold', color:'#475569'}}>Topic / Research Query</label>
                 <textarea value={topic} onChange={(e)=>setTopic(e.target.value)} placeholder="e.g., 'Impact of GDPR on Automotive Software updates'..." style={{width:'100%', height: '100px', fontFamily:'sans-serif', fontSize:'1rem', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '15px'}}/>
             </div>
           )}

           {/* USER DOC */}
           {subMode === 'user_doc' && (
               <div style={{marginBottom:'20px'}}>
                  <div style={{border:'2px dashed #cbd5e1', borderRadius:'8px', padding:'30px', textAlign:'center', cursor:'pointer', background:'#f8fafc'}}
                       onClick={() => document.getElementById('file-upload').click()}>
                      <UploadCloud size={32} style={{margin:'0 auto 10px', color:'#64748b'}}/>
                      <div style={{fontWeight:'bold', color:'#334155'}}>Click to Upload PDF</div>
                  </div>
                  <input id="file-upload" type="file" accept=".pdf,.txt" style={{display:'none'}} onChange={(e) => {
                      const file = e.target.files[0];
                      if(file) {
                          const fd = new FormData(); fd.append("file", file);
                          fetch(`${API_BASE}/upload`, {method:'POST', body:fd}).then(r=>r.json()).then(d=>setContextText(d.text));
                      }
                  }}/>
                  {contextText && <div style={{marginTop:'15px'}}><textarea value={contextText} readOnly style={{width:'100%', height:'150px', fontFamily:'monospace', fontSize:'0.75rem', border:'1px solid #cbd5e1', borderRadius:'6px', padding:'10px', background:'#f1f5f9'}}/></div>}
               </div>
           )}

           {/* RESULTS */}
           {runStats && (
               <div style={{background:'#f8fafc', padding:'15px', borderRadius:'8px', border:'1px solid #e2e8f0', marginBottom:'15px', marginTop:'20px'}}>
                   <div style={{fontWeight:'bold', fontSize:'0.9rem', color:'#334155'}}>Result Summary</div>
                   <div style={{fontSize:'0.8rem', color:'#64748b'}}>Total Questions: {runStats.total} | Models Used: {runStats.success}</div>
               </div>
           )}
           {Object.entries(groupedResults).map(([model, questions]) => (
               <div key={model} style={{marginBottom:'10px', border:'1px solid #e2e8f0', borderRadius:'6px', overflow:'hidden'}}>
                   <div onClick={() => setOpenAccordions(p => ({...p, [model]: !p[model]}))} style={{padding:'10px', background:'#f1f5f9', cursor:'pointer', fontWeight:500, fontSize:'0.9rem'}}>
                       {model} ({questions.length})
                   </div>
                   {openAccordions[model] && (
                       <div style={{padding:'10px'}}>
                           {questions.map((q, i) => (
                               <div key={i} style={{marginBottom:'8px', fontSize:'0.85rem', paddingBottom:'8px', borderBottom:'1px dashed #e2e8f0'}}>
                                   <div style={{fontWeight:'bold', color:'#334155'}}>Q: {q.question}</div>
                                   <div style={{color:'#64748b', marginTop:'2px', fontStyle:'italic'}}>Ans: {q.expected_answer.substring(0, 100)}...</div>
                               </div>
                           ))}
                       </div>
                   )}
               </div>
           ))}
        </div>
      </div>

      {/* ACTIVITY MONITOR */}
      {activeTasks.length > 0 && (
        <div style={{position: 'fixed', right: 0, top: 0, bottom: 0, width: '320px', background: 'white', boxShadow: '-5px 0 15px rgba(0,0,0,0.1)', zIndex: 1000, padding: '20px', borderLeft:'3px solid #3b82f6', display:'flex', flexDirection:'column'}}>
            <div style={{fontWeight:'bold', fontSize:'1.1rem', marginBottom:'20px', display:'flex', alignItems:'center', gap:'10px', color:'#1e3a8a'}}>
                <Activity className="spin" color="#3b82f6"/> Activity Monitor
            </div>
            <div style={{flex:1, overflowY:'auto', display:'flex', flexDirection:'column', gap:'10px'}}>
                {activeTasks.map((t) => (
                    <div key={t.id} style={{padding:'12px', background:'#eff6ff', border:'1px solid #dbeafe', borderRadius:'8px', fontSize:'0.9rem'}}>
                        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'6px'}}>
                            <div style={{fontWeight:600, color:'#1e40af'}}>{t.name}</div>
                            <button onClick={() => clearTask(t.id)} style={{border:'none', background:'none', cursor:'pointer', color:'#94a3b8'}}><Eraser size={12}/></button>
                        </div>
                        <div style={{fontSize:'0.75rem', color:'#60a5fa', display:'flex', alignItems:'center', gap:'15px'}}>
                            <span style={{display:'flex', alignItems:'center', gap:'4px'}}><Clock size={12}/> {formatDuration(t.duration)}</span>
                            <span style={{display:'flex', alignItems:'center', gap:'4px', cursor:'pointer', textDecoration:'underline'}} onClick={() => setExpandedTask(expandedTask === t.id ? null : t.id)}>
                                <Eye size={12}/> {expandedTask === t.id ? 'Hide' : 'Inspect'}
                            </span>
                        </div>
                        
                        <div style={{width:'100%', height:'4px', background:'#bfdbfe', borderRadius:'2px', marginTop:'8px', overflow:'hidden'}}>
                             <div style={{width: '30%', height:'100%', background:'#3b82f6', animation:'progress 2s infinite linear'}}></div>
                        </div>

                        {expandedTask === t.id && (
                            <div style={{marginTop:'10px', background:'#1e293b', color:'#a5f3fc', padding:'8px', borderRadius:'4px', fontSize:'0.7rem', fontFamily:'monospace', overflowX:'hidden'}}>
                                <div style={{marginBottom:'4px'}}><strong>Source:</strong> {t.payload.source_metadata?.source_type}</div>
                                <div><strong>Docs:</strong> {t.payload.source_metadata?.documents?.length || (t.payload.source_metadata?.document_id ? 1 : 0)}</div>
                                <div><strong>Models:</strong> {t.payload.models.join(", ")}</div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
      )}
    </div>
  );
}