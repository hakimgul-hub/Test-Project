import { useState, useEffect, useRef } from 'react';
import { 
  Gavel, FileText, Globe, Folder, UploadCloud, RefreshCw, FileJson, 
  ChevronDown, ChevronRight, Scale, CheckCircle2, AlertTriangle, 
  Activity, Clock, Eye, Terminal, Eraser, Microscope, BrainCircuit, ArrowUpRight,
  Link as LinkIcon, Lock, Search
} from 'lucide-react';

import { API_BASE } from '../api';

// Global Memory
let GLOBAL_JUDGE_MEMORY = [];

// --- HELPER FUNCTIONS ---

const getScoreColor = (score) => {
    if (score === null || score === undefined) return '#94a3b8';
    const num = parseFloat(score);
    if (num >= 8.0) return '#22c55e'; // Green
    if (num >= 5.0) return '#eab308'; // Yellow
    return '#ef4444'; // Red
};

const formatDuration = (sec) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
};

// Extractor for finding IDs in filenames
const extractHexIds = (filename) => {
    if (!filename) return [];
    // Match standard hex IDs (6+ chars) or UUID parts
    const matches = filename.match(/[a-f0-9]{6,}/gi);
    return matches ? matches.map(m => m.toLowerCase()) : [];
};

export default function JudgeTab() {
  const [subMode, setSubMode] = useState('single_doc'); 
  
  // Data State
  const [candidates, setCandidates] = useState([]); // Student
  const [references, setReferences] = useState([]); // Teacher
  
  // Selection State
  const [selectedCandidate, setSelectedCandidate] = useState("");
  const [selectedReference, setSelectedReference] = useState("");
  
  // Matching State
  const [autoMatched, setAutoMatched] = useState(false); 
  const [isMatching, setIsMatching] = useState(false);
  const [deepMatch, setDeepMatch] = useState(null); // The EXACT file found via deep inspection
  const [matchDebug, setMatchDebug] = useState(""); // Debug text to show user what ID we found

  const [models, setModels] = useState([]);
  const [selectedJudge, setSelectedJudge] = useState(localStorage.getItem("axiom_judge_model") || ""); 
  
  const [activeTasks, setActiveTasks] = useState(GLOBAL_JUDGE_MEMORY);
  const [reportsList, setReportsList] = useState([]);
  
  useEffect(() => { GLOBAL_JUDGE_MEMORY = activeTasks; }, [activeTasks]);

  const handleJudgeChange = (e) => {
      const val = e.target.value;
      setSelectedJudge(val);
      localStorage.setItem("axiom_judge_model", val);
  };

  // Timer for active tasks
  useEffect(() => {
    if (activeTasks.length === 0) return;
    const interval = setInterval(() => {
        setActiveTasks(prev => prev.map(task => ({
            ...task,
            duration: Math.floor((Date.now() - task.timestamp) / 1000)
        })));
    }, 1000);
    return () => clearInterval(interval);
  }, [activeTasks.length]);

  const loadData = () => {
    const params = new URLSearchParams();
    if (subMode) params.set("mode", subMode);
    const qs = params.toString() ? `?${params.toString()}` : "";
    fetch(`${API_BASE}/judge/artifacts${qs}`)
      .then(r => r.json())
      .then(data => {
          setCandidates(data.candidates || []);
          setReferences(data.references || []);
      })
      .catch(console.error);
    fetch(`${API_BASE}/judge/results${qs}`)
        .then(r => r.json())
        .then(setReportsList)
        .catch(console.error);
  };

  useEffect(() => {
    fetch(`${API_BASE}/config/llms`)
      .then(r => r.json())
      .then(data => {
          setModels(data);
          if(!localStorage.getItem("axiom_judge_model") && data.length > 0) {
             const preferred = data.find(m => m.id.includes("gpt4")) || data[0];
             setSelectedJudge(preferred.id);
          }
      })
      .catch(console.error);
  }, []);

  // Load artifacts and results for current mode (dropdown shows relevant files only); re-run when mode changes
  useEffect(() => { loadData(); }, [subMode]);

  // --- ⚡️ DEEP AUTO-MATCHING LOGIC ---
  useEffect(() => {
      // Reset logic when selection changes
      setDeepMatch(null); 
      setAutoMatched(false);
      setMatchDebug("");
      
      if (!selectedCandidate) {
          setIsMatching(false);
          // If clearing candidate, also clear reference to reset view
          setSelectedReference("");
          return;
      }

      const matchFiles = async () => {
          setIsMatching(true);
          const candObj = candidates.find(c => c.relative_path === selectedCandidate);
          if (!candObj) { setIsMatching(false); return; }

          let match = null;
          let foundId = "None";

          // STRATEGY 1: DEEP INSPECTION (Fetch file content)
          try {
              const res = await fetch(`${API_BASE}/judge/artifact_content?path=${encodeURIComponent(selectedCandidate)}`);
              if (res.ok) {
                  const json = await res.json();
                  // Look for ID in various fields
                  // 1. "teacher_run_id" (Best match if present)
                  // 2. "run_id" (Often shared)
                  // 3. "id" (Generic)
                  const rawId = json.teacher_run_id || json.run_id || json.id || "";
                  
                  if (rawId && rawId.length > 5) {
                      foundId = rawId;
                      // Try to find this ID inside any reference filename
                      // We take the first 8 chars to be safe against different suffix formats
                      const searchToken = rawId.substring(0, 8).toLowerCase();
                      setMatchDebug(`ID found: ${searchToken}...`);

                      match = references.find(r => r.filename.toLowerCase().includes(searchToken));
                  }
              }
          } catch (e) {
              console.warn("Deep check failed:", e);
          }

          // STRATEGY 2: FILENAME MATCHING (Fallback)
          if (!match) {
              const candClean = candObj.filename.toLowerCase()
                  .replace(/^cora_/i, "")
                  .replace(/^viva_/i, "")
                  .replace("batch_", "")
                  .replace(/\.json$/i, "");
              
              const candIds = extractHexIds(candObj.filename);

              match = references.find(r => {
                  const refClean = r.filename.toLowerCase().replace(/\.json$/i, "");
                  
                  // A. Exact Substring Match
                  if (candClean.includes(refClean) || refClean.includes(candClean)) return true;

                  // B. Shared Hex ID Match
                  const refIds = extractHexIds(r.filename);
                  if (candIds.some(cid => refIds.includes(cid))) return true;

                  return false;
              });
          }

          // APPLY RESULT
          if (match) {
              setDeepMatch(match); 
              setSelectedReference(match.relative_path);
              setAutoMatched(true);
          } else {
              // Explicitly clear reference if no match found
              setSelectedReference(""); 
              if (!matchDebug) setMatchDebug("No ID found in file.");
          }
          setIsMatching(false);
      };

      matchFiles();

  }, [selectedCandidate, candidates, references]); 

  // API returns mode-filtered lists; candidates/references are already relevant to current subMode
  const filteredCandidates = candidates;

  // --- FILTER REFERENCES (Teacher): deep-match and partial-match logic ---
  const getFilteredReferences = () => {
      // 1. Strict Match Mode: If deep match found, show ONLY that file
      if (deepMatch) return [deepMatch];

      // 2. Base list: API already filtered by mode (folder)
      const baseList = references;

      // 3. If a candidate is selected but NO deep match was found...
      // We perform a looser filter to at least narrow it down, 
      // BUT we do NOT fallback to "Show All" to avoid confusion.
      if (selectedCandidate) {
         const candObj = candidates.find(c => c.relative_path === selectedCandidate);
         if (candObj) {
             const candIds = extractHexIds(candObj.filename);
             // Show files that share ANY ID chunk
             const partialMatches = baseList.filter(r => {
                 const refIds = extractHexIds(r.filename);
                 return candIds.some(cid => refIds.some(rid => rid.includes(cid) || cid.includes(rid)));
             });
             if (partialMatches.length > 0) return partialMatches;
         }
         // If absolutely no correlation found, return empty list to force user to look manually
         // or verify files. Returning everything is confusing.
         return [];
      }

      return baseList;
  };

  const filteredReferences = getFilteredReferences();

  const clearTask = (taskId) => {
      setActiveTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const handleRunJudge = async () => {
      if(!selectedCandidate || !selectedReference || !selectedJudge) return alert("Please select Candidate, Reference, and Judge.");
      
      const taskId = Date.now();
      const candObj = candidates.find(c => c.relative_path === selectedCandidate);
      
      const newTask = {
          id: taskId,
          name: `Evaluating: ${candObj ? candObj.filename.substring(0, 20) : 'Artifact'}...`,
          timestamp: Date.now(),
          duration: 0,
          status: 'running',
          payload: { candidate: selectedCandidate, reference: selectedReference }
      };

      setActiveTasks(prev => [...prev, newTask]);
      
      try {
          const res = await fetch(`${API_BASE}/judge/run`, {
              method: 'POST',
              headers: {'Content-Type':'application/json'},
              body: JSON.stringify({
                  candidate_file: selectedCandidate,
                  teacher_file: selectedReference,
                  model_name: selectedJudge
              })
          });
          
          const data = await res.json();
          if (res.status !== 200) throw new Error(data.detail || "Judge Failed");

          setTimeout(loadData, 2000); 

      } catch(err) {
          alert("Judge Launch Error: " + err.message);
      } finally {
          setTimeout(() => setActiveTasks(prev => prev.filter(t => t.id !== taskId)), 3000);
      }
  };

  return (
    <div className="animate-fade" style={{
        position:'relative', 
        paddingRight: activeTasks.length > 0 ? '340px' : '0', 
        transition: 'padding-right 0.3s ease-in-out'
    }}>
      <header className="header"><h1>Layer 3: The Judge (Evaluation)</h1></header>

      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
        {['single_doc', 'discovery', 'project', 'user_doc'].map(m => (
             <button key={m} onClick={() => { setSubMode(m); setSelectedCandidate(""); setSelectedReference(""); setDeepMatch(null); }} className={`btn btn-sub ${subMode === m ? 'active' : ''}`} style={{textTransform:'capitalize'}}>
                {m === 'single_doc' && <FileText size={16}/>}
                {m === 'discovery' && <Globe size={16}/>}
                {m === 'project' && <Folder size={16}/>}
                {m === 'user_doc' && <UploadCloud size={16}/>}
                {m.replace('_', ' ')}
            </button>
        ))}
      </div>

      <div className="grid-2">
        {/* LEFT COLUMN: SETUP */}
        <div className="card" style={{height:'fit-content'}}>
            <h3>⚖️ Court Session Setup</h3>
            
            {/* 1. STUDENT SELECTION */}
            <div className="input-group">
                <label style={{display:'flex', justifyContent:'space-between', alignItems:'center', color:'#ea580c'}}>
                    1. Select Candidate (Student) ({filteredCandidates.length})
                    <button onClick={loadData} style={{border:'none', background:'none', cursor:'pointer', color:'#3b82f6', display:'flex', alignItems:'center', gap:'4px', fontSize:'0.75rem'}}><RefreshCw size={12}/> Refresh</button>
                </label>
                <select value={selectedCandidate} onChange={e => setSelectedCandidate(e.target.value)} style={{fontFamily:'monospace', fontSize:'0.85rem'}}>
                    <option value="">-- Choose Exam/Viva Output --</option>
                    {filteredCandidates.map(a => (
                        <option key={a.relative_path} value={a.relative_path}>
                            [{a.type}] {a.filename.substring(0,40)}...
                        </option>
                    ))}
                </select>
            </div>

            {/* 2. TEACHER SELECTION (AUTO-MATCHED) */}
            <div className="input-group">
                <label style={{display:'flex', justifyContent:'space-between', color:'#166534'}}>
                    <div style={{display:'flex', alignItems:'center', gap:'8px'}}>
                        <span>2. Select Reference (Teacher)</span>
                        {isMatching && <span style={{fontSize:'0.7rem', color:'#f59e0b', display:'flex', alignItems:'center', gap:'3px'}}><Search className="spin" size={10}/> Analyzing...</span>}
                    </div>
                    {autoMatched && <span className="animate-fade" style={{color:'#166534', fontSize:'0.7rem', display:'flex', alignItems:'center', gap:'4px'}}><LinkIcon size={10}/> STRICT MATCH</span>}
                </label>
                
                <select 
                    value={selectedReference} 
                    onChange={e => setSelectedReference(e.target.value)} 
                    style={{fontFamily:'monospace', fontSize:'0.85rem', borderColor: autoMatched ? '#22c55e' : '#e2e8f0', borderWidth: autoMatched ? '2px' : '1px', background: autoMatched ? '#f0fdf4' : 'white'}}
                    disabled={false}
                >
                    {filteredReferences.length === 0 ? (
                        <option value="">-- No Matching Teacher File Found --</option>
                    ) : (
                        <>
                           <option value="">-- Choose Source Truth --</option>
                           {filteredReferences.map(r => (
                               <option key={r.relative_path} value={r.relative_path}>
                                   {r.filename} ({r.size_kb} KB)
                               </option>
                           ))}
                        </>
                    )}
                </select>
                
                {/* Debug Info: Show user why match failed or what it found */}
                {selectedCandidate && !isMatching && (
                    <div style={{marginTop:'5px', fontSize:'0.7rem', color: filteredReferences.length === 0 ? '#ef4444' : '#64748b', fontStyle:'italic'}}>
                        {filteredReferences.length === 0 
                            ? "❌ No teacher file found with matching Run ID. Ensure Teacher file exists."
                            : autoMatched 
                                ? `✅ Matched via internal ID: ${matchDebug}`
                                : "⚠️ Please verify selection manually."
                        }
                    </div>
                )}
            </div>

            {/* 3. JUDGE SELECTION */}
            <div className="input-group" style={{marginTop:'20px', borderTop:'1px solid #e2e8f0', paddingTop:'15px'}}>
                <label style={{color:'#7c3aed', display:'flex', alignItems:'center', gap:'6px'}}>
                    <Gavel size={14}/> 3. Presiding Judge (Model)
                </label>
                <select value={selectedJudge} onChange={handleJudgeChange} style={{border:'2px solid #ddd6fe', fontWeight:'bold'}}>
                    <option value="">-- Select Model --</option>
                    {models.map(m => {
                        const statusLabel = m.status === 'available' ? '' : (m.status === 'unavailable' ? ' — Unavailable' : ' — Not set up');
                        return <option key={m.id} value={m.id}>{m.name} ({m.provider}){statusLabel}</option>;
                    })}
                </select>
                {selectedJudge && (() => {
                    const m = models.find(x => x.id === selectedJudge);
                    if (!m || m.status === 'available') return null;
                    return (
                        <div style={{fontSize:'0.75rem', marginTop:'6px', color: m.status === 'unavailable' ? '#94a3b8' : '#eab308'}}>
                            {m.status === 'unavailable' ? 'Ollama may be offline or model not pulled.' : 'Set up the model (pull in Ollama or add API key in Settings).'}
                        </div>
                    );
                })()}
            </div>

            {selectedJudge && models.find(m => m.id === selectedJudge)?.status !== 'available' && (
                <div style={{fontSize:'0.75rem', color:'#eab308', marginTop:'6px', marginBottom:'8px'}}>
                    Judge model not available. Set up in Ollama or add API key in Settings.
                </div>
            )}
            <button 
                className="btn btn-primary" 
                onClick={handleRunJudge} 
                disabled={activeTasks.some(t => t.status === 'running') || !selectedCandidate || !selectedReference || !selectedJudge || (selectedJudge && models.find(m => m.id === selectedJudge)?.status !== 'available')} 
                style={{background: (activeTasks.some(t => t.status === 'running') || (selectedJudge && models.find(m => m.id === selectedJudge)?.status !== 'available')) ? '#94a3b8' : '#7c3aed', cursor: (selectedJudge && models.find(m => m.id === selectedJudge)?.status !== 'available') ? 'not-allowed' : 'pointer'}}
            >
                {activeTasks.some(t => t.status === 'running') ? "👨‍⚖️ Deliberating..." : "🚀 Run Evaluation"}
            </button>
        </div>

        {/* RIGHT COLUMN: REPORTS */}
        <div className="card">
            <h3>📜 Verification Reports</h3>
            {reportsList.length === 0 ? (
                <div style={{textAlign:'center', padding:'40px', color:'#94a3b8'}}>
                    <Scale size={48} style={{opacity:0.5, marginBottom:'10px'}}/>
                    <div>No reports generated yet. Run a session to see results.</div>
                </div>
            ) : (
                <div style={{display:'flex', flexDirection:'column', gap:'10px', maxHeight:'600px', overflowY:'auto'}}>
                    {reportsList.map((rep) => (
                        <div key={rep.relative_path} onClick={() => { /* ... same popup logic ... */ }} 
                        style={{padding:'12px', border:'1px solid #e2e8f0', borderRadius:'6px', cursor:'pointer', background:'white', transition:'all 0.2s', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                            <div>
                                <div style={{fontWeight:600, color:'#334155', fontSize:'0.9rem'}}>{rep.filename.replace('.json', '')}</div>
                                <div style={{fontSize:'0.75rem', color:'#94a3b8'}}>{rep.created_at.replace('T', ' ')}</div>
                            </div>
                            <div style={{textAlign:'right'}}>
                                <div style={{fontWeight:'bold', color: getScoreColor(rep.average_score)}}>{rep.average_score}</div>
                                <ArrowUpRight size={14} color="#cbd5e1"/>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
      </div>
      
      {/* Sidebar Task Monitor */}
      {activeTasks.length > 0 && (
        <div style={{position: 'fixed', right: 0, top: 0, bottom: 0, width: '320px', background: 'white', boxShadow: '-5px 0 15px rgba(0,0,0,0.1)', zIndex: 1000, padding: '20px', borderLeft:'3px solid #7c3aed', display:'flex', flexDirection:'column'}}>
            <div style={{fontWeight:'bold', fontSize:'1.1rem', marginBottom:'20px', display:'flex', alignItems:'center', gap:'10px', color:'#5b21b6'}}><Activity className="spin" color="#7c3aed"/> Court Monitor</div>
            <div style={{flex:1, overflowY:'auto', display:'flex', flexDirection:'column', gap:'10px'}}>
                {activeTasks.map((t) => (
                    <div key={t.id} style={{padding:'12px', background:'#f5f3ff', border:'1px solid #ddd6fe', borderRadius:'8px', fontSize:'0.9rem'}}>
                        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'6px'}}>
                            <div style={{fontWeight:600, color:'#5b21b6', fontSize:'0.85rem'}}>{t.name}</div>
                            <button onClick={() => clearTask(t.id)} style={{border:'none', background:'none', cursor:'pointer', color:'#94a3b8'}}><Eraser size={12}/></button>
                        </div>
                        <div style={{fontSize:'0.75rem', color:'#8b5cf6', display:'flex', alignItems:'center', gap:'15px'}}>
                            <span style={{display:'flex', alignItems:'center', gap:'4px'}}><Clock size={12}/> {formatDuration(t.duration)}</span>
                        </div>
                        <div style={{width:'100%', height:'4px', background:'#ddd6fe', borderRadius:'2px', marginTop:'8px', overflow:'hidden'}}><div style={{width:'50%', height:'100%', background:'#8b5cf6', animation:'loading 2s infinite'}}></div></div>
                    </div>
                ))}
            </div>
        </div>
      )}
    </div>
  );
}