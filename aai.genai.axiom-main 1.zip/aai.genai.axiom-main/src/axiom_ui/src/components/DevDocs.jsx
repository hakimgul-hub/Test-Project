import React from 'react';
import { Code, Box, Server, GitBranch, FileText } from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";

export default function DevDocs() {
  return (
    <div className="animate-fade" style={{ padding: '40px', maxWidth: '1000px', margin: '0 auto', overflowY: 'auto', height: '100%' }}>

      {/* HEADER */}
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '2rem', color: '#1e293b', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <Code size={32} className="text-primary" /> Developer Documentation
        </h1>
        <p style={{ fontSize: '1rem', color: '#64748b' }}>
          Backend architecture, API reference, and where to find full docs in the repository.
        </p>
      </div>

      {/* REPO DOCS REFERENCE */}
      <div className="card" style={{ marginBottom: '32px', borderLeft: '4px solid #3b82f6', background: '#f8fafc' }}>
        <h3 style={{ marginTop: 0, display: 'flex', alignItems: 'center', gap: '10px' }}>
          <FileText size={20} /> Documentation in the repository
        </h3>
        <p style={{ color: '#475569', fontSize: '0.9rem', marginBottom: '12px' }}>
          Full technical and data-flow docs live in the <code style={{ background: '#e2e8f0', padding: '2px 6px', borderRadius: '4px' }}>docs/</code> folder. Open the repo and read:
        </p>
        <ul style={{ fontSize: '0.9rem', color: '#475569', paddingLeft: '20px', lineHeight: '1.8' }}>
          <li><strong>README.md</strong> – Quick start, run commands, configuration, troubleshooting.</li>
          <li><strong>docs/DATA_FLOW_AND_ARTIFACTS.md</strong> – File layouts, filename conventions, API endpoint list, JSON artifact structures, Evaluation tab.</li>
          <li><strong>docs/AXIOM_TECHNICAL_OVERVIEW.md</strong> – Platform concept, Teacher/Examiner/Judge modules and code flow, MongoDB, LLMs, Interrogator, key files.</li>
          <li><strong>docs/LLM_PROFILES_README.md</strong> – LLM setup (Ollama, cloud API keys, profile editing).</li>
        </ul>
      </div>

      {/* ARCHITECTURE OVERVIEW */}
      <div className="card" style={{ marginBottom: '40px' }}>
        <h3 style={{ marginTop: 0, display: 'flex', alignItems: 'center', gap: '10px' }}>
          <GitBranch size={20} /> Architecture overview
        </h3>
        <p style={{ color: '#475569', fontSize: '0.9rem', marginBottom: '16px' }}>
          Single backend: <code>src/axiom_core/api/main.py</code>. Routers validate requests and delegate to <strong>services</strong>; services use <strong>layer</strong> code and write JSON under <code>data/</code>. File-based handoff: Teacher → Examiner → Judge pass artifacts by filename or relative path.
        </p>
        <div style={{ background: '#1e293b', padding: '20px', borderRadius: '8px', overflowX: 'auto', fontFamily: 'monospace', fontSize: '0.8rem', color: '#e2e8f0' }}>
          <pre>{`API (main.py)
  ├── routers: teacher, examiner, interrogator, judge, system, projects_examiner
  └── delegates to → Services (services/)
        ├── TeacherService   → layer1_teacher (generator, brains, strategies)
        ├── ExaminerService → layer2_harness/cora_sdk (auth, runner/modes, results)
        └── JudgeService    → axiom_core.llm (LLMCaller), reads Examiner + Teacher JSON

Shared: dependencies.py (paths, config, MongoHelper), llm/ (generate, LLMCaller)`}</pre>
        </div>
      </div>

      {/* API REFERENCE */}
      <h2 style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px' }}>API reference</h2>
      <div className="card" style={{ marginBottom: '24px' }}>
        <h3 style={{ marginTop: 0, display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Server size={20} /> Base URL
        </h3>
        <p style={{ color: '#475569', fontSize: '0.9rem', marginBottom: '8px' }}>
          This UI calls the backend at: <strong style={{ fontFamily: 'monospace', color: '#1d4ed8' }}>{API_BASE}</strong>
        </p>
        <p style={{ fontSize: '0.8rem', color: '#64748b' }}>
          Override with <code>VITE_API_URL</code> in <code>.env</code> (e.g. <code>VITE_API_URL=http://localhost:8000</code>). OpenAPI docs: <a href={`${API_BASE}/docs`} target="_blank" rel="noopener noreferrer" style={{ color: '#2563eb' }}>{API_BASE}/docs</a>.
        </p>
      </div>
      <div className="card" style={{ marginBottom: '40px' }}>
        <h3 style={{ marginTop: 0, color: '#334155' }}>Key endpoints</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
          <thead style={{ background: '#f1f5f9' }}>
            <tr>
              <th style={{ padding: '10px', textAlign: 'left', color: '#475569' }}>Method</th>
              <th style={{ padding: '10px', textAlign: 'left', color: '#475569' }}>Endpoint</th>
              <th style={{ padding: '10px', textAlign: 'left', color: '#475569' }}>Role</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>POST</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/generate</td><td style={{ padding: '10px', color: '#475569' }}>Teacher: generate question set</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>GET</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/examiner/artifacts</td><td style={{ padding: '10px', color: '#475569' }}>List Teacher files</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>GET</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/examiner/results</td><td style={{ padding: '10px', color: '#475569' }}>List Examiner (candidate) files</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>POST</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/examiner/run_batch</td><td style={{ padding: '10px', color: '#475569' }}>Run Examiner with Teacher file</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>GET</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/judge/artifacts</td><td style={{ padding: '10px', color: '#475569' }}>List candidates + references</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>GET</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/judge/results</td><td style={{ padding: '10px', color: '#475569' }}>List Judge reports</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>GET</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/judge/report?path=</td><td style={{ padding: '10px', color: '#475569' }}>Get one report JSON</td></tr>
            <tr style={{ borderBottom: '1px solid #e2e8f0' }}><td style={{ padding: '10px' }}>POST</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/judge/run</td><td style={{ padding: '10px', color: '#475569' }}>Run Judge (candidate + teacher file)</td></tr>
            <tr><td style={{ padding: '10px' }}>GET</td><td style={{ padding: '10px', fontFamily: 'monospace' }}>/config/llms</td><td style={{ padding: '10px', color: '#475569' }}>LLM profiles for dropdowns</td></tr>
          </tbody>
        </table>
        <p style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '12px' }}>Full list and request/response details: <strong>docs/DATA_FLOW_AND_ARTIFACTS.md</strong> §8.</p>
      </div>

      {/* CORE MODULES */}
      <h2 style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '10px', marginBottom: '20px' }}>Core modules (backend)</h2>
      <div style={{ display: 'grid', gap: '20px' }}>

        <div className="card" style={{ borderLeft: '4px solid #3b82f6' }}>
          <h3 style={{ marginTop: 0, fontFamily: 'monospace', color: '#1d4ed8' }}>api/main.py, dependencies.py</h3>
          <p style={{ color: '#475569', fontSize: '0.9rem' }}>
            <strong>Role:</strong> Entry point and shared config.<br />
            <strong>Description:</strong> <code>main.py</code> mounts routers (Teacher, Examiner, Interrogator, Judge, System, Projects). <code>dependencies.py</code> loads <code>.env</code>, defines <code>DATA_DIR</code>, <code>TEACHER_DIR</code>, <code>EXAMINER_DIR</code>, <code>JUDGE_DIR</code>, loads configs (LLM, domain, layer1, mongo, secrets) and exposes <code>MongoHelper</code> for document fetch.
          </p>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #8b5cf6' }}>
          <h3 style={{ marginTop: 0, fontFamily: 'monospace', color: '#6d28d9' }}>services/teacher_service.py, layer1_teacher/</h3>
          <p style={{ color: '#475569', fontSize: '0.9rem' }}>
            <strong>Role:</strong> Question set generation (Layer 1).<br />
            <strong>Description:</strong> <code>TeacherService.run_generation</code> resolves docs from MongoDB or uses context, chunks text, picks a domain strategy (<code>strategies.py</code>), runs <code>GoldenDatasetGenerator</code> (<code>generator.py</code>) with a brain from <code>brains.py</code> (Ollama or OpenAI/Anthropic). Writes JSON to <code>data/Teacher/&lt;mode&gt;/</code>.
          </p>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #10b981' }}>
          <h3 style={{ marginTop: 0, fontFamily: 'monospace', color: '#047857' }}>services/examiner_service.py, layer2_harness/cora_sdk/</h3>
          <p style={{ color: '#475569', fontSize: '0.9rem' }}>
            <strong>Role:</strong> Run questions against CORA (Layer 2).<br />
            <strong>Description:</strong> <code>ExaminerService.run_batch</code> finds the Teacher file, injects CORA credentials from secrets, authenticates, fetches OpenAPI, iterates run units (discovery / pct / document / user_document). Uses <code>runner/modes.py</code> and <code>runner/results.py</code> to call CORA and write transcripts to <code>data/Examiner/&lt;mode&gt;/</code>. Optional hydration fills missing grounding text.
          </p>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #f59e0b' }}>
          <h3 style={{ marginTop: 0, fontFamily: 'monospace', color: '#b45309' }}>services/judge_service.py, llm/</h3>
          <p style={{ color: '#475569', fontSize: '0.9rem' }}>
            <strong>Role:</strong> Grade candidate vs reference (Layer 3).<br />
            <strong>Description:</strong> <code>JudgeService.run_evaluation</code> loads candidate and Teacher JSON by relative path, aligns turns, builds a prompt per turn (question, reference answer, student answer, evidence), calls <code>LLMCaller</code> from <code>axiom_core.llm</code>, parses JSON verdict (score, metrics, failure_category), aggregates and writes report to <code>data/Judge/&lt;mode&gt;/</code>.
          </p>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #6366f1' }}>
          <h3 style={{ marginTop: 0, fontFamily: 'monospace', color: '#4f46e5' }}>llm/__init__.py, llm/profile_client.py</h3>
          <p style={{ color: '#475569', fontSize: '0.9rem' }}>
            <strong>Role:</strong> Shared LLM client for Teacher, Judge, Interrogator.<br />
            <strong>Description:</strong> <code>generate()</code> and <code>LLMCaller</code> support Ollama (local), OpenAI, Anthropic. Profile-based config from <code>llm_profiles.json</code>; API keys from <code>secrets.json</code> or env. Used by Teacher brains and Judge per-turn grading.
          </p>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #ec4899' }}>
          <h3 style={{ marginTop: 0, fontFamily: 'monospace', color: '#be185d' }}>dependencies.MongoHelper, mongo_loader.py</h3>
          <p style={{ color: '#475569', fontSize: '0.9rem' }}>
            <strong>Role:</strong> Document library (MongoDB).<br />
            <strong>Description:</strong> <code>MongoHelper</code> in dependencies is used by the Teacher to fetch document content by ID (<code>get_doc</code>, <code>_scavenge_text</code>). <code>mongo_loader.py</code> exposes <code>fetch_document_library_index</code>, <code>get_document_content</code>, <code>is_mongo_available</code> for UI/library flows. Both use <code>mongo_config.json</code> and <code>MONGO_URI</code>.
          </p>
        </div>
      </div>

      {/* DATA FLOW REMINDER */}
      <div className="card" style={{ marginTop: '32px', background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
        <h3 style={{ marginTop: 0, color: '#166534', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Box size={18} /> Data flow (handoff)
        </h3>
        <p style={{ color: '#334155', fontSize: '0.9rem', margin: 0 }}>
          Teacher writes a <strong>filename</strong> → Examiner is triggered with that filename and writes <strong>candidate files</strong> → Judge is given <strong>candidate_file</strong> + <strong>teacher_file</strong> (relative paths) and writes reports. No database links; the filesystem and paths in the Judge report are the only durable links. See <strong>docs/DATA_FLOW_AND_ARTIFACTS.md</strong> and <strong>docs/AXIOM_TECHNICAL_OVERVIEW.md</strong> for full detail.
        </p>
      </div>
    </div>
  );
}
