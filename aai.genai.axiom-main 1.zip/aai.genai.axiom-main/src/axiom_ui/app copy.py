import os
import sys
import json
import uuid
import time
import datetime
import streamlit as st
import pypdf
import pandas as pd
import plotly.express as px

# --- 1. PATH SETUP (Critical Fix) ---
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.dirname(os.path.dirname(current_dir)) 
if src_dir not in sys.path:
    sys.path.append(src_dir)

# --- IMPORTS ---
from axiom_core.persistence import save_run, list_runs, load_run, load_history_from_disk
try:
    from axiom_core.layer1_teacher.brains import OpenSourceTeacher, PremiumTeacher
    from axiom_core.layer2_harness.adapters import CoraHarness
    from axiom_core.layer1_teacher.strategies import CoraAdasStrategy
    try:
        from axiom_core.layer1_teacher.generator import GoldenDatasetGenerator
    except ImportError:
        from axiom_core.layer1_teacher.generator import QuestionGenerator as GoldenDatasetGenerator
except ImportError as e:
    st.error(f"⚠️ Import Error: {e}")
    st.stop()
    
# --- 2. PAGE CONFIGURATION ---
st.set_page_config(page_title="AXIOM | Verification Platform", page_icon="🛡️", layout="wide", initial_sidebar_state="expanded")

# --- 4. CUSTOM CSS ---
st.markdown("""
<style>
    .block-container { padding-top: 1.5rem; padding-bottom: 3rem; }
    .main-header { font-size: 2.2rem; color: #000000; font-weight: 800; margin-bottom: 0px; line-height: 1.2; }
    .sub-text { font-size: 1.0rem; color: #333333; margin-bottom: 25px; }
    div.stButton > button { background-color: #003ab5; color: white; border: none; border-radius: 6px; height: 50px; font-weight: 600; }
    div.stButton > button:hover { background-color: #002a85; color: white; }
    div.stTabs [data-baseweb="tab"] { background-color: #e5fdff; border-radius: 6px 6px 0px 0px; color: #000000; font-weight: 600; }
    div.stTabs [aria-selected="true"] { background-color: #003ab5; color: white; }
</style>
""", unsafe_allow_html=True)

# --- 5. SESSION STATE INITIALIZATION ---
if 'history' not in st.session_state:
    st.session_state['history'] = load_history_from_disk()

# --- AUTO-LOAD LOGIC ---
if st.session_state['history'] and not st.session_state.get('audit_data'):
    most_recent = st.session_state['history'][0]
    content = most_recent.get('content', {})
    if isinstance(content, dict):
        st.session_state['audit_data'] = content.get('audit_questions', [])
        st.session_state['interview_data'] = content.get('interview_turns', [])
        st.session_state['adversarial_data'] = content.get('adversarial_questions', [])
        st.session_state['cognitive_data'] = content.get('cognitive_threads', [])
        st.session_state['current_thread_id'] = most_recent['id']
    st.session_state['current_files_data'] = most_recent.get('source_data', [])

if 'current_thread_id' not in st.session_state:
    st.session_state['current_thread_id'] = str(uuid.uuid4())

# Initialize buckets
for key in ['audit_data', 'interview_data', 'adversarial_data', 'cognitive_data', 'current_files_data']:
    if key not in st.session_state: st.session_state[key] = []

# Defaults
defaults = {
    'show_config': False,
    'llm_config': {'provider': 'ollama', 'base_url': "http://localhost:11434", 'model_name': "llama3"},
    'cora_config': {'base_url': "https://corax-dev.automotive-ai.com", 'username': "", 'password': "", 'cora_document_id': "", 'cora_version_name': ""}
}
for key, val in defaults.items():
    if key not in st.session_state: st.session_state[key] = val

# --- 6. HISTORY HELPERS ---
def load_thread(thread_id):
    t = next((t for t in st.session_state['history'] if t['id'] == thread_id), None)
    if t:
        content = t.get('content', {})
        st.session_state['audit_data'] = content.get('audit_questions', [])
        st.session_state['interview_data'] = content.get('interview_turns', [])
        st.session_state['adversarial_data'] = content.get('adversarial_questions', [])
        st.session_state['cognitive_data'] = content.get('cognitive_threads', [])
        if t.get('source_data'): st.session_state['current_files_data'] = t['source_data']
        st.session_state['current_thread_id'] = thread_id
        st.success(f"Loaded: {t['name']}")
        time.sleep(0.5)
        st.rerun()

def new_thread():
    st.session_state['current_thread_id'] = str(uuid.uuid4())
    for k in ['audit_data', 'interview_data', 'adversarial_data', 'cognitive_data', 'current_files_data']:
        st.session_state[k] = []
    st.rerun()

# --- 7. SIDEBAR ---
with st.sidebar:  
    st.subheader("🧵 Session History")
    if st.button("➕ New Thread", use_container_width=True):
        new_thread()
    
    with st.container(height=300):
        if st.session_state['history']:
            sorted_hist = sorted(st.session_state['history'], key=lambda x: x['last_updated'], reverse=True)
            for t in sorted_hist:
                label = f"{t['name']} ({t['last_updated'].strftime('%H:%M')})"
                unique_btn_key = t.get('filename') or str(uuid.uuid4())
                if st.button(label, key=unique_btn_key, use_container_width=True):
                    load_thread(t['id'])
    
    st.markdown("---")
    if st.button("⚙️ Open Configuration", use_container_width=True):
        st.session_state['show_config'] = True
        st.rerun()

# --- 8. MAIN HEADER ---
st.markdown('<div class="main-header">AXIOM Verification Platform</div>', unsafe_allow_html=True)
curr_id = st.session_state.get('current_thread_id')
curr_thread = next((t for t in st.session_state.get('history', []) if t['id'] == curr_id), None)
curr_name = curr_thread['name'] if curr_thread else "New Session (Unsaved)"
st.info(f"📂 **Active Thread:** {curr_name}")
st.markdown("---")

# === CONFIGURATION VIEW ===
if st.session_state['show_config']:
    st.info("🛠️ Configuration Mode Active.")
    t1, t2 = st.tabs(["🧠 LLM Settings", "🔌 CORA SUT Settings"])
    with t1:
        prov = st.selectbox("Provider", ["ollama", "openai", "gemini"])
        key = st.text_input("API Key", type="password") if prov != "ollama" else ""
        model = st.text_input("Model Name", value="gpt-4-turbo" if prov=="openai" else "llama3")
        st.session_state['llm_config'] = {'provider': prov, 'api_key': key, 'model_name': model}
        if prov == "ollama": st.session_state['llm_config']['base_url'] = st.text_input("Base URL", "http://localhost:11434")
    with t2:
        c = st.session_state['cora_config']
        c['base_url'] = st.text_input("Base URL", value=c['base_url'])
        c['username'] = st.text_input("Username", value=c['username'])
        c['password'] = st.text_input("Password", value=c['password'], type="password")
        c['cora_document_id'] = st.text_input("Document ID", value=c['cora_document_id'])
        c['cora_version_name'] = st.text_input("Version Name", value=c['cora_version_name'])
        if st.button("Test Connection"):
            try:
                h = CoraHarness(c['base_url'], c['username'], c['password'])
                if h.connect(): st.success("✅ Connected!")
                else: st.error("❌ Failed.")
            except Exception as e: st.error(f"Error: {e}")
    if st.button("💾 Save & Close", type="primary"):
        st.session_state['show_config'] = False
        st.rerun()

# === WORKSPACE VIEW ===
else:
    tab1, tab2, tab3 = st.tabs(["Layer 1: Generator", "Layer 2: Connectors", "Layer 3: Results"])
    
    # --- TAB 1: GENERATOR ---
    with tab1:
        st.subheader("📥 Source Injection")
        sub_t1, sub_t2 = st.tabs(["Paste Text", "Upload File"])
        
        with sub_t1:
            raw = st.text_area("Paste Context", height=150)
            if raw: st.session_state['current_files_data'] = [{'name': 'Pasted', 'text': raw}]
            
        with sub_t2:
            up_files = st.file_uploader("Upload PDF(s)", type=["pdf"], accept_multiple_files=True)
            if up_files:
                current_data = []
                for up_file in up_files:
                    try:
                        reader = pypdf.PdfReader(up_file)
                        text = "".join([p.extract_text() for p in reader.pages])
                        current_data.append({'name': up_file.name, 'text': text})
                    except: pass
                if current_data:
                    st.session_state['current_files_data'] = current_data
                    st.success(f"✅ Loaded {len(current_data)} files.")

        st.markdown("---")
        st.subheader("🧠 Generation Settings")

        # 1. SELECT PERSONA
        generation_mode = st.radio(
            "Select Persona / Mode:",
            [
                "👷 Auditor (Single/Multi-Doc Fact Check)",
                "👩‍💼 Consultant (Cognitive Interview / Scenario)",
                "🦹 Adversarial Tester (Red Team / Security)"
            ],
            index=0,
            key="generation_mode"
        )

        # 2. MULTI-DOCUMENT HANDLING
        combined_text = ""
        if st.session_state['current_files_data']:
            files = st.session_state['current_files_data']
            combined_text = "\n\n--- NEXT DOCUMENT ---\n\n".join([f['text'] for f in files])
            if len(files) > 1:
                st.info(f"📚 Analysis will combine **{len(files)} documents**.")

        # --- MODE A: AUDITOR ---
        if generation_mode.startswith("👷 Auditor"):
            q_count = st.slider("Questions to Generate", 10, 200, 20, step=10, help="Batched generation.")
            difficulty = st.select_slider("Difficulty", options=["Easy", "Medium", "Hard"], value="Medium")
            diff_map = {"Easy": 3, "Medium": 5, "Hard": 8}
            
            if st.button("🧠 RUN AUDITOR", type="primary", use_container_width=True):
                if not combined_text: st.error("No data loaded!"); st.stop()
                
                with st.status("🚀 Auditor Working...", expanded=True) as status:
                    llm_conf = st.session_state['llm_config']
                    try:
                        if llm_conf['provider'] == 'ollama': brain = OpenSourceTeacher(model_name=llm_conf['model_name'])
                        else: brain = PremiumTeacher(api_key=llm_conf.get('api_key'), model_name=llm_conf['model_name'])
                        
                        gen = GoldenDatasetGenerator(brain, CoraAdasStrategy())
                        gen.inject_source_material(combined_text)
                        
                        exam_result = gen.create_exam(num_questions=q_count, difficulty=diff_map[difficulty], mission_mode="Audit")
                        
                        new_qs = exam_result.get('questions', [])
                        st.session_state['audit_data'].extend(new_qs)
                        
                        active_id = st.session_state.get('current_thread_id')
                        doc_name = f"Multi-Doc ({len(st.session_state['current_files_data'])} files)" if len(st.session_state['current_files_data']) > 1 else st.session_state['current_files_data'][0]['name']
                        
                        save_run({
                            "audit_questions": st.session_state['audit_data'],
                            "interview_turns": st.session_state['interview_data'],
                            "adversarial_questions": st.session_state['adversarial_data'],
                            "cognitive_threads": st.session_state['cognitive_data'],
                            "source_data": st.session_state['current_files_data']
                        }, prefix="L1_exam", run_name=f"Audit: {doc_name}", run_id=active_id)
                        
                        st.session_state['current_l1_id'] = active_id
                        st.session_state['history'] = load_history_from_disk()
                        status.update(label=f"✅ Generated {len(new_qs)} questions!", state="complete")
                        time.sleep(1)
                        st.rerun()
                    except Exception as e: st.error(f"Error: {e}")

        # --- MODE B: CONSULTANT ---
        elif generation_mode.startswith("👩‍💼 Consultant"):
            st.info("🎤 Consultant Mode: Cognitive Interview.")
            turn_count = st.slider("Topics", 1, 5, 2)
            focus = st.text_input("Focus", placeholder="e.g. Safety")
            
            if st.button("🎤 RUN CONSULTANT", type="primary", use_container_width=True):
                if not combined_text: st.error("No data loaded!"); st.stop()
                
                with st.status("🚀 Consultant Working...", expanded=True) as status:
                    llm_conf = st.session_state['llm_config']
                    try:
                        if llm_conf['provider'] == 'ollama': brain = OpenSourceTeacher(model_name=llm_conf['model_name'])
                        else: brain = PremiumTeacher(api_key=llm_conf.get('api_key'), model_name=llm_conf['model_name'])
                        
                        gen = GoldenDatasetGenerator(brain, CoraAdasStrategy())
                        gen.inject_source_material(combined_text)
                        
                        result = gen.create_exam(num_threads=turn_count, mission_mode="Interview", interview_focus=focus)
                        st.session_state['cognitive_data'].extend(result.get('cognitive_threads', []))
                        
                        active_id = st.session_state.get('current_thread_id')
                        doc_name = st.session_state['current_files_data'][0]['name']
                        
                        save_run({
                            "audit_questions": st.session_state['audit_data'],
                            "interview_turns": st.session_state['interview_data'],
                            "adversarial_questions": st.session_state['adversarial_data'],
                            "cognitive_threads": st.session_state['cognitive_data'],
                            "source_data": st.session_state['current_files_data']
                        }, prefix="L1_cog", run_name=f"Cognitive: {doc_name}", run_id=active_id)
                        
                        st.session_state['current_l1_id'] = active_id
                        st.session_state['history'] = load_history_from_disk()
                        status.update(label="✅ Complete!", state="complete")
                        time.sleep(1)
                        st.rerun()
                    except Exception as e: st.error(f"Error: {e}")

        # --- MODE C: ADVERSARIAL ---
        elif generation_mode.startswith("🦹 Adversarial"):
            st.error("🛡️ Red Team Mode: Safety Testing.")
            count = st.slider("Attacks", 5, 50, 10)
            atype = st.selectbox("Strategy", ["Jailbreak", "Hallucination Injection", "PII Leakage"])
            
            if st.button("🧨 RUN RED TEAM", type="primary", use_container_width=True):
                if not combined_text: st.error("No data loaded!"); st.stop()
                
                with st.status("🚀 Injecting Attacks...", expanded=True) as status:
                    llm_conf = st.session_state['llm_config']
                    try:
                        if llm_conf['provider'] == 'ollama': brain = OpenSourceTeacher(model_name=llm_conf['model_name'])
                        else: brain = PremiumTeacher(api_key=llm_conf.get('api_key'), model_name=llm_conf['model_name'])
                        
                        gen = GoldenDatasetGenerator(brain, CoraAdasStrategy())
                        gen.inject_source_material(combined_text)
                        
                        res = gen.create_exam(num_questions=count, mission_mode="Adversarial", interview_focus=atype)
                        st.session_state['adversarial_data'].extend(res.get('questions', []))
                        
                        active_id = st.session_state.get('current_thread_id')
                        doc_name = st.session_state['current_files_data'][0]['name']
                        
                        save_run({
                            "audit_questions": st.session_state['audit_data'],
                            "interview_turns": st.session_state['interview_data'],
                            "adversarial_questions": st.session_state['adversarial_data'],
                            "cognitive_threads": st.session_state['cognitive_data'],
                            "source_data": st.session_state['current_files_data']
                        }, prefix="L1_sec", run_name=f"Security: {atype}", run_id=active_id)
                        
                        st.session_state['current_l1_id'] = active_id
                        st.session_state['history'] = load_history_from_disk()
                        status.update(label="✅ Exploits Generated!", state="complete")
                        time.sleep(1)
                        st.rerun()
                    except Exception as e: st.error(f"Error: {e}")

        # DISPLAY RESULTS
        if any([st.session_state['audit_data'], st.session_state['cognitive_data'], st.session_state['adversarial_data']]):
            st.divider()
            
            if st.session_state['audit_data']:
                st.subheader("📝 Audit Questions")
                st.data_editor(pd.DataFrame(st.session_state['audit_data']), num_rows="dynamic", key="edit_audit")
            
            if st.session_state['cognitive_data']:
                st.subheader("🧠 Cognitive Threads")
                for t in st.session_state['cognitive_data']:
                    with st.expander(f"Topic: {t.get('topic', 'General')}"):
                        st.dataframe(pd.DataFrame(t.get('questions', [])))
            
            if st.session_state['adversarial_data']:
                st.subheader("🧨 Adversarial Attacks")
                st.data_editor(pd.DataFrame(st.session_state['adversarial_data']), num_rows="dynamic", key="edit_adv")

    # --- TAB 2: CONNECTORS ---
    with tab2:
        st.subheader("🚀 Run Verification")
        q_list = []
        q_list.extend(st.session_state['audit_data'])
        
        # Flatten Cognitive
        for t in st.session_state['cognitive_data']:
            for q in t.get('questions', []):
                q['topic'] = t.get('topic')
                q['is_contextual'] = True
                q_list.append(q)
        
        # Add Adversarial
        for q in st.session_state['adversarial_data']:
            q['type'] = 'Adversarial'
            q['topic'] = 'Security'
            q_list.append(q)
            
        if not q_list:
            st.warning("No questions generated.")
        else:
            st.write(f"Ready to verify **{len(q_list)} items**.")
            
            # Prepare Payload
            payload = []
            for item in q_list:
                payload.append({
                    "question": item.get('question') or item.get('content'),
                    "expected_answer": item.get('answer') or item.get('expected_answer', 'N/A'),
                    "type": item.get('type', 'Standard'),
                    "topic": item.get('topic', 'General')
                })
            
            with st.expander("Preview Payload"):
                st.dataframe(pd.DataFrame(payload))
                
            if st.button("▶️ START RUN", type="primary"):
                c = st.session_state['cora_config'] # Access the cora_config from session state
                if not c['username']: st.error("Check Config"); st.stop()
                
                h = CoraHarness(c['base_url'], c['username'], c['password'])
                if h.connect():
                    with st.spinner("Verifying..."):
                        results = h.run_axiom_batch(
                            axiom_json={"questions": payload},
                            document_id=c['cora_document_id'],
                            version_name=c['cora_version_name'] # Pass version_name from config
                        )
                    
                    pid = st.session_state.get('current_l1_id')
                    save_run(results, prefix="L2_Verify", run_name="L2 Verification", parent_id=pid)
                    st.session_state['history'] = load_history_from_disk()
                    st.success("Done!")
                    st.rerun()
                else: st.error("Login Failed")

    # --- TAB 3: HOMOLOGATION DASHBOARD ---
    with tab3:
        st.subheader("🏆 Homologation-Grade Verification")
        history = load_history_from_disk()
        l2_runs = [h for h in history if h.get('type') == 'L2_Verify']

        if not l2_runs:
            st.info("Run verification first.")
        else:
            opts = {f"{h['name']} ({h['last_updated'].strftime('%H:%M')})": h for h in l2_runs}
            sel = st.selectbox("Select Run", list(opts.keys()))
            data = opts[sel]['content']

            # Handle list vs dict structure
            results_list = data.get("results_questions", data) if isinstance(data, dict) else data
            df = pd.DataFrame(results_list)

            if st.button("⚖️ Run Grading", type="primary"):
                grades = []
                progress_bar = st.progress(0)

                for i, row in df.iterrows():
                    # Sets
                    gold = set(str(row.get('expected_answer', '')).lower().split()) - {'the','a','is'}
                    act = set(str(row.get('actual_answer', '')).lower().split()) - {'the','a','is'}
                    if not gold: gold = {'empty'}
                    if not act: act = {'empty'}

                    TP = len(gold.intersection(act))
                    FP = len(act - gold)

                    prec = TP / (TP + FP) if (TP+FP) > 0 else 0
                    rec = TP / len(gold) if len(gold) > 0 else 0

                    # Traffic Light Levels
                    level = "Level 4 (Fail)"
                    if prec >= 0.95 and rec >= 0.95: level = "Level 1 (Homologation)"
                    elif prec >= 0.90 and rec >= 0.80: level = "Level 2 (Correct)"
                    elif prec >= 0.75: level = "Level 3 (Partial)"

                    grades.append({"precision": prec, "recall": rec, "level": level})
                    progress_bar.progress((i+1)/len(df))

                res_df = pd.concat([df, pd.DataFrame(grades)], axis=1)
                st.session_state['graded_df'] = res_df

            if 'graded_df' in st.session_state:
                res_df = st.session_state['graded_df']

                # --- ✅ CRITICAL FIX: Data Sanitization ---
                # If 'type' was lost during verification, default it to 'Standard'
                if 'type' not in res_df.columns:
                    res_df['type'] = "Standard Audit"
                # If 'latency' is missing, default to 0
                if 'latency' not in res_df.columns:
                    res_df['latency'] = 0
                # ------------------------------------------

                # KPIs
                k1, k2, k3 = st.columns(3)
                pass_rate = (res_df['level'].isin(["Level 1 (Homologation)", "Level 2 (Correct)"]).sum() / len(res_df)) * 100
                k1.metric("Homologation Readiness", f"{pass_rate:.1f}%")
                k2.metric("Avg Precision", f"{res_df['precision'].mean()*100:.1f}%")
                k3.metric("Avg Recall", f"{res_df['recall'].mean()*100:.1f}%")

                # Charts
                st.divider()
                c1, c2 = st.columns(2)

                with c1:
                    # Stacked Bar Chart: Quality by Type
                    # Grouping ensures the bar chart renders correctly even with mixed data
                    chart_data = res_df.groupby(['type', 'level']).size().reset_index(name='count')
                    fig = px.bar(
                        chart_data,
                        x="type",
                        y="count",
                        color="level",
                        title="Quality Levels per Category",
                        color_discrete_map={
                            "Level 1 (Homologation)": "#2ecc71", # Green
                            "Level 2 (Correct)": "#f1c40f",      # Orange
                            "Level 3 (Partial)": "#e67e22",      # Dark Orange
                            "Level 4 (Fail)": "#e74c3c"          # Red
                        }
                    )
                    st.plotly_chart(fig, use_container_width=True)

                with c2:
                    # Scatter Plot: Precision vs Recall
                    fig2 = px.scatter(
                        res_df,
                        x="recall",
                        y="precision",
                        color="level",
                        hover_data=["question"],
                        title="Precision vs Recall Map",
                        color_discrete_map={
                            "Level 1 (Homologation)": "#2ecc71",
                            "Level 2 (Correct)": "#f1c40f",
                            "Level 3 (Partial)": "#e67e22",
                            "Level 4 (Fail)": "#e74c3c"
                        }
                    )
                    # Add Homologation Success Zone (Top Right Corner)
                    fig2.add_shape(type="rect", x0=0.95, y0=0.95, x1=1.05, y1=1.05,
                                    line=dict(color="Green"), fillcolor="Green", opacity=0.1)
                    st.plotly_chart(fig2, use_container_width=True)

                # Detailed Table
                st.subheader("📝 Detailed Report")

                # Style function
                def highlight_level(val):
                    color = 'red'
                    if "Level 1" in str(val): color = 'green'
                    elif "Level 2" in str(val): color = 'orange'
                    elif "Level 3" in str(val): color = 'yellow'
                    return f'color: {color}; font-weight: bold'

                # Only show columns that actually exist
                target_cols = ['question', 'type', 'expected_answer', 'actual_answer', 'precision', 'recall', 'level']
                available_cols = [c for c in target_cols if c in res_df.columns]

                st.dataframe(
                    res_df[available_cols].style.map(highlight_level, subset=['level']),
                    use_container_width=True
                )