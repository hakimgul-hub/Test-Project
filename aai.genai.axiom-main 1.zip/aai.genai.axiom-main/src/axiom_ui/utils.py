import os
import re
import datetime
import pypdf
import streamlit as st

# --- 1. THE MISSING FUNCTION (Fixes the Crash) ---
def get_status_icon(artifact_type):
    """Returns a visual icon/label for the artifact type."""
    icons = {
        "L1_GENERATION": "🏗️ Design",
        "L2_RESULT": "⚡ Verification",
        "L2A_VIVA": "🔄 Interrogation",
        "L3_REPORT": "⚖️ Grading"
    }
    return icons.get(artifact_type, "📄 File")

# --- 2. YOUR SMART PDF PARSER (Preserves Metadata Logic) ---
def smart_parse_pdf(uploaded_file):
    """
    Extracts text AND attempts to find metadata (Date, Version, Title) from a PDF.
    """
    try:
        # pypdf expects a file-like object
        reader = pypdf.PdfReader(uploaded_file)
        text = "".join([p.extract_text() for p in reader.pages])
        
        # 1. Heuristic Extraction (First Page Analysis)
        first_page = reader.pages[0].extract_text() if reader.pages else ""
        
        # Search for Date (ISO, US, EU formats)
        date_match = re.search(r'(\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4}|\d{2}\.\d{2}\.\d{4})', first_page)
        detected_date = date_match.group(1) if date_match else datetime.date.today().strftime("%Y-%m-%d")
        
        # Search for Version (v1.0, Ver 2.3, Release 5)
        ver_match = re.search(r'(v\d+\.\d+|Version\s+\d+|Rel\s+\d+)', first_page, re.IGNORECASE)
        detected_version = ver_match.group(1) if ver_match else "1.0"
        
        # Guess Title (First non-empty line)
        lines = [l.strip() for l in first_page.split('\n') if l.strip()]
        detected_title = lines[0] if lines else uploaded_file.name
        
        # Reset file pointer for other tools
        uploaded_file.seek(0)
        
        return {
            "filename": uploaded_file.name,
            "title": detected_title,
            "version": detected_version,
            "date": detected_date,
            "type": "Requirement Spec", # Default
            "text": text
        }
    except Exception as e:
        print(f"❌ PDF Parse Error: {e}")
        return {
            "filename": uploaded_file.name, 
            "title": "Error Parsing", 
            "version": "N/A", 
            "date": "N/A", 
            "type": "Error",
            "text": "", 
            "error": str(e)
        }