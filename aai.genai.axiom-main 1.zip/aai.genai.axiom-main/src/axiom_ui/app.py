import os
import sys
import uuid
import json
import streamlit as st
from dotenv import load_dotenv

# Load Environment Variables
load_dotenv()

# -------------------------------------------------------------------------
# 1. ROBUST PATH SETUP
# -------------------------------------------------------------------------
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.dirname(current_dir)
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

# -------------------------------------------------------------------------
# 2. IMPORTS
# -------------------------------------------------------------------------
try:
    from axiom_ui.styles import load_css
    # Standard Layers
    from axiom_ui.layer1 import render_layer_1
    from axiom_ui.layer2 import render_layer_2
    from axiom_ui.layer3 import render_layer_3
    
    # Dynamic Layers (Wrap in try block in case files don't exist yet)
    try:
        from axiom_ui.layer2a import render_layer_2a
    except ImportError:
        render_layer_2a = None
        
    try:
        from axiom_ui.layer3a import render_layer_3a
    except ImportError:
        render_layer_3a = None
    
    # Adapters & Loaders
    from axiom_core.layer2_harness.adapters import CoraHarness
    from axiom_core.mongo_loader import get_mongo_client

except ImportError as e:
    st.error(f"🚨 CRITICAL STARTUP ERROR: {e}")
    st.stop()

# -------------------------------------------------------------------------
# 3. APP CONFIGURATION & STATE
# -------------------------------------------------------------------------
st.set_page_config(
    page_title="AXIOM | Verification Platform", 
    page_icon="🛡️", 
    layout="wide", 
    initial_sidebar_state="expanded"
)
load_css()

# Initialize Session State
if 'current_thread_id' not in st.session_state: st.session_state['current_thread_id'] = str(uuid.uuid4())
if 'l1_selected_docs' not in st.session_state: st.session_state['l1_selected_docs'] = []
if 'l1_search_res' not in st.session_state: st.session_state['l1_search_res'] = []

# Default CORA Config (Using Logical Env Keys)
if 'cora_config' not in st.session_state:
    st.session_state['cora_config'] = {
        'base_url': os.getenv("CORA_BASE_URL", "https://corax-dev.automotive-ai.com"), 
        'username': os.getenv("CORA_USERNAME", ""), 
        'password': os.getenv("CORA_PASSWORD", ""), 
    }

# -------------------------------------------------------------------------
# 4. SIDEBAR (The Control Center)
# -------------------------------------------------------------------------
def render_sidebar():
    with st.sidebar:
        st.title("AXIOM 🛡️")
        st.caption("v3.0 | Robust V-Model Edition")
        
        # --- BRAIN SETTINGS ---
        st.markdown("### 🧠 Brain (LLM) Settings")
        brain_profile = st.selectbox("Select Profile", ["Local (Ollama)", "OpenAI GPT-4", "Azure OpenAI"])
        
        model_name = "llama3:latest" # Default
        api_key = ""
        
        if "Local" in brain_profile:
            model_name = st.text_input("Model Name", value="llama3:latest")
            st.caption(f"Active: **{model_name}**")
        elif "OpenAI" in brain_profile:
            api_key = st.text_input("API Key", type="password")
            model_name = "gpt-4-turbo"
            
        # SAVE TO SESSION STATE
        st.session_state['brain_config'] = {
            "profile": brain_profile,
            "model": model_name,
            "key": api_key
        }

        # --- CORA SUT SETTINGS ---
        with st.expander("🔌 SUT (CORA) Connection", expanded=False):
            c = st.session_state['cora_config']
            
            new_base = st.text_input("Base URL", value=c.get('base_url', ''))
            new_user = st.text_input("Username", value=c.get('username', ''))
            new_pwd = st.text_input("Password", value=c.get('password', ''), type="password")
            
            if st.button("Save & Test Connection"):
                # 1. Update State
                st.session_state['cora_config'] = {
                    "base_url": new_base, "username": new_user, "password": new_pwd
                }
                
                # 2. Test CORA
                try:
                    h = CoraHarness(new_base, new_user, new_pwd)
                    if h.connect(): st.success("✅ CORA: Connected")
                    else: st.error("❌ CORA: Auth Failed")
                except: st.error("❌ CORA: Error")

                # 3. Test Mongo
                try:
                    from axiom_core.mongo_loader import is_mongo_available
                    mongo_ok, mongo_msg = is_mongo_available()
                    if mongo_ok:
                        st.success("✅ MongoDB: Connected")
                    else:
                        st.error(f"❌ MongoDB: {mongo_msg}")
                except Exception as e:
                    st.error(f"❌ MongoDB: {e}")

        st.divider()
        st.info("📂 **Artifacts:** `/data`")

# -------------------------------------------------------------------------
# 5. MAIN APPLICATION
# -------------------------------------------------------------------------
def main():
    render_sidebar()

    st.markdown('<div class="main-header">AXIOM Verification Platform</div>', unsafe_allow_html=True)
    st.markdown("---")

    # Define Tabs
    # Only show extra tabs if the modules were imported successfully
    tabs_list = ["1️⃣ The Teacher", "2️⃣ The Examiner"]
    if render_layer_2a: tabs_list.append("2️⃣🅰️ The Interrogator")
    tabs_list.append("3️⃣ The Auditor")
    if render_layer_3a: tabs_list.append("3️⃣🅰️ The Profiler")
    
    tabs = st.tabs(tabs_list)
    
    # Render Content
    with tabs[0]: render_layer_1()
    with tabs[1]: render_layer_2()
    
    # Dynamic Tab Handling
    current_tab_idx = 2
    if render_layer_2a:
        with tabs[current_tab_idx]: render_layer_2a()
        current_tab_idx += 1
        
    with tabs[current_tab_idx]: render_layer_3()
    current_tab_idx += 1
    
    if render_layer_3a:
        with tabs[current_tab_idx]: render_layer_3a()

if __name__ == "__main__":
    main()