import logging
import sys

def setup_logger(name="AXIOM"):
    """
    Configures a logger that prints DEBUG info to the console.
    Format: [TIME] [LEVEL] Message
    """
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        logger.setLevel(logging.DEBUG) # Capture everything
        
        # Create console handler
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG)
        
        # Create formatter
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - [%(filename)s] - %(message)s', datefmt='%H:%M:%S')
        ch.setFormatter(formatter)
        
        logger.addHandler(ch)
        
    return logger

# Create a shared instance
log = setup_logger()