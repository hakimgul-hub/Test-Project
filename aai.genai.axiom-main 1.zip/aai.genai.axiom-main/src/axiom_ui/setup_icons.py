import os

# Config
ICON_DIR = "src/axiom_ui/assets/icons"

# SVG Definitions (Professional Vectors)
# We use simple geometric shapes to simulate the logos for now.
SVGS = {
    "aai_logo.svg": """
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 60">
      <rect width="200" height="60" fill="#1E3A8A" rx="10"/>
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-weight="bold" font-size="24" fill="white">AAI | AUTOMOTIVE</text>
    </svg>
    """,
    "axiom_logo.svg": """
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
      <circle cx="50" cy="50" r="45" fill="#2563EB" opacity="0.1"/>
      <path d="M50 20 L80 80 L20 80 Z" fill="#1E3A8A" stroke="white" stroke-width="2"/>
      <circle cx="50" cy="55" r="10" fill="white"/>
    </svg>
    """,
    "icon_shield.svg": """
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1E3A8A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    </svg>
    """,
    "icon_brain.svg": """
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1E3A8A" stroke-width="2">
      <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.55 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3A2.5 2.5 0 0 1 9.5 2Z"/>
      <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.55 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3A2.5 2.5 0 0 0 14.5 2Z"/>
    </svg>
    """,
    "icon_chart.svg": """
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#1E3A8A" stroke-width="2">
      <line x1="18" y1="20" x2="18" y2="10"></line>
      <line x1="12" y1="20" x2="12" y2="4"></line>
      <line x1="6" y1="20" x2="6" y2="14"></line>
    </svg>
    """
}

def setup_icons():
    if not os.path.exists(ICON_DIR):
        os.makedirs(ICON_DIR)
        print(f"✅ Created folder: {ICON_DIR}")

    for name, content in SVGS.items():
        with open(f"{ICON_DIR}/{name}", "w") as f:
            f.write(content.strip())
        print(f"✅ Generated: {name}")

if __name__ == "__main__":
    setup_icons()