import { test, expect } from '@playwright/test';

test('AXIOM Full Certification Workflow', async ({ page }) => {
  // 1. Go to Home (Ensure App is running on port 5173)
  await page.goto('http://localhost:5173');

  // 2. Verify Sidebar is present
  await expect(page.getByText('The Teacher')).toBeVisible();

  // 3. Navigate to Evaluation Dashboard
  await page.getByText('Evaluation').click();
  
  // 4. Enter Judge Station Mode (Click the purple button)
  await page.getByRole('button', { name: 'Judge Station' }).click();
  
  // 5. Verify Judge Station loaded
  await expect(page.getByText('Manual Grading Console')).toBeVisible();
  
  // 6. Test Documentation Switch (Click "User Guide" in sidebar)
  await page.getByText('User Guide').click();
  
  // 7. Verify User Guide content
  await expect(page.getByText('The V-Model Methodology')).toBeVisible();
  
  // 8. Verify Scientific KPIs table (MATCHING THE ACTUAL TEXT)
  // ✅ FIX: Changed from 'Scientific Evaluation Metrics' to 'Scientific KPIs & Methodology'
  await expect(page.getByText('Scientific KPIs & Methodology')).toBeVisible();
});