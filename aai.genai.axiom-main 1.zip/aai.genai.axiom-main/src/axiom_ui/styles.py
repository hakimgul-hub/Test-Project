import streamlit as st

def load_css():
    """
    Injects custom CSS into the Streamlit app.
    Call this once at the start of app.py.
    """
    css = """
    <style>
        /* Global Container Spacing */
        .block-container { padding-top: 1.5rem; padding-bottom: 3rem; }
        
        /* Header Styling */
        .main-header { font-size: 2.2rem; color: #00a3b5; font-weight: 800; margin-bottom: 0px; line-height: 1.2; }
        .sub-text { font-size: 1.0rem; color: #333333; margin-bottom: 25px; }
        
        /* Button Styling */
        div.stButton > button { 
            background-color: #003ab5; 
            color: white; 
            border: none; 
            border-radius: 6px; 
            height: 50px; 
            font-weight: 600; 
        }
        div.stButton > button:hover { background-color: #003ab5; color: white; }
        
        /* Tab Styling */
        div.stTabs [data-baseweb="tab"] { 
            background-color: #e5fdff; 
            border-radius: 3px 3px 0px 0px; 
            color: #003ab5; 
            font-weight: 600; 
        }
        div.stTabs [aria-selected="true"] { background-color: #003ab5; color: white; }
        
        /* Metric Cards */
        .metric-card { 
            background-color: #003ab5; 
            padding: 15px; 
            border-radius: 8px; 
            border-left: 5px solid #003ab5; 
        }
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)