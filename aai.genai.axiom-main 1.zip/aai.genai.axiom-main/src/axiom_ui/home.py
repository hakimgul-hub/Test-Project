import sys
import os

# --- PATH FIX: Add 'src' to Python's search path ---
# Finds the current folder (axiom_ui) and goes up one level to (src)
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.dirname(current_dir)
sys.path.append(src_dir)
# ---------------------------------------------------

import streamlit as st
# Now the import will work:

from axiom_core.persistence import list_runs, load_run

import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
from src.axiom_core.persistence import list_runs, load_run

st.set_page_config(
    page_title="AXIOM Dashboard",
    page_icon="🧠",
    layout="wide"
)

st.title("🧠 AXIOM: Automotive AI Audit Platform")
st.markdown("---")

# 1. WELCOME & METRICS
st.subheader("📊 Project History")

# Load data
df = list_runs()

if not df.empty:
    # Top-level metrics
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Runs", len(df))
    col2.metric("Latest Run Date", df.iloc[0]["Date"].split(" ")[0])
    col3.metric("Total Questions Tested", df["Questions"].sum())

    st.markdown("### 📜 Recent Runs")
    
    # Interactive Table
    event = st.dataframe(
        df,
        use_container_width=True,
        hide_index=True,
        selection_mode="single-row",
        on_select="rerun" # Allows us to capture clicks
    )
    
    # 2. SELECTION LOGIC
    # (Streamlit 1.35+ selection logic)
    if len(event.selection["rows"]) > 0:
        selected_index = event.selection["rows"][0]
        selected_file = df.iloc[selected_index]["Filename"]
        
        st.info(f"👉 Selected Run: **{selected_file}**")
        
        col_a, col_b = st.columns(2)
        with col_a:
            if st.button("📈 Load into Layer 3 (KPIs)", type="primary"):
                # Save to session state so Layer 3 can pick it up
                run_data = load_run(selected_file)
                st.session_state["kpi_run_data"] = run_data
                st.session_state["active_run_filename"] = selected_file
                st.success("Loaded! Go to 'Layer 3' page to analyze.")
        
        with col_b:
            with st.expander("🔍 Quick JSON Preview"):
                st.json(load_run(selected_file))

else:
    st.info("👋 Welcome! No runs found yet. Go to 'Layer 1' or 'Layer 2' to start.")

st.markdown("---")
st.caption("v0.3.0 | Local Persistence Enabled")