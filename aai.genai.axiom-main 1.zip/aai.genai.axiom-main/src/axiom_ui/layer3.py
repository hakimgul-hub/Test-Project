import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from scipy import stats
import os
import sys
import re

sys.path.insert(0, os.path.abspath("src"))
from axiom_core.persistence import list_artifacts, load_artifact

# ==========================================
# 🧪 SCIENTIFIC FORMULAS
# ==========================================

def calc_system_health(df):
    """Cluster 1: System Engineering (SLA Focus)"""
    latencies = df["latency"].dropna()
    return {
        "mean_latency": latencies.mean(),
        "jitter": latencies.std(),
        "p99": latencies.quantile(0.99),
        "error_rate": (len(df[df["actual"].str.contains("Error", na=False)]) / len(df)) * 100
    }

def calc_cognitive_dynamics(df):
    """Cluster 2: Cognitive Decay (Lost in the Middle / Fatigue)"""
    threads = df[df["is_thread"] == True]
    if threads.empty: return {}
    
    # Linear Regression for Drift
    try:
        slope, _, _, _, _ = stats.linregress(threads["turn_index"], threads["latency"])
    except: slope = 0.0
    
    # "Lost in the Middle" Proxy:
    # Compare Pass Rate of First Turn vs Middle Turns vs Last Turn
    mid_point = threads["turn_index"].max() // 2
    
    early_acc = threads[threads["turn_index"] == 1]["verdict_binary"].mean()
    mid_acc = threads[threads["turn_index"] == mid_point]["verdict_binary"].mean() if mid_point > 1 else early_acc
    late_acc = threads[threads["turn_index"] == threads["turn_index"].max()]["verdict_binary"].mean()
    
    # U-Curve Score: High score means it forgets the middle (bad)
    u_curve_severity = ((early_acc + late_acc)/2) - mid_acc 
    
    return {
        "latency_drift": slope,
        "fatigue_delta": (early_acc - late_acc) * 100,
        "middle_loss_score": u_curve_severity * 100
    }

def calc_ragas_lite(df):
    """Cluster 3: Truth & Grounding (RAGAS-Inspired)"""
    # 1. Faithfulness Proxy: % of answers that contain at least one Citation [x]
    def has_citation(text): return bool(re.search(r"\[.*?\]", str(text)))
    faithfulness = df["actual"].apply(has_citation).mean() * 100
    
    # 2. Answer Relevance Proxy: Jaccard Similarity between Question & Answer
    # (Do they share words? If 0, the AI likely ignored the topic)
    def jaccard(row):
        q_tokens = set(re.findall(r"\w+", str(row["question"]).lower()))
        a_tokens = set(re.findall(r"\w+", str(row["actual"]).lower()))
        if not q_tokens or not a_tokens: return 0.0
        return len(q_tokens.intersection(a_tokens)) / len(q_tokens.union(a_tokens))
    
    relevance = df.apply(jaccard, axis=1).mean() * 100
    
    return {
        "faithfulness_score": faithfulness, # % with citations
        "relevance_score": relevance # Topic overlap %
    }

def calc_linguistics(df):
    """Cluster 4: Linguistic Complexity (Persona Fidelity)"""
    # Type-Token Ratio (TTR): Measure of vocabulary richness
    # High TTR = Consultant (Varied); Low TTR = Auditor (Repetitive/Standardized)
    def calc_ttr(text):
        tokens = re.findall(r"\w+", str(text).lower())
        if not tokens: return 0.0
        return len(set(tokens)) / len(tokens)
    
    ttr = df["actual"].apply(calc_ttr).mean()
    
    # Verbosity
    chars = df["actual"].astype(str).apply(len).mean()
    
    return {
        "lexical_diversity_ttr": ttr,
        "verbosity_mean": chars
    }

# ==========================================
# 🖥️ RENDERER
# ==========================================

def render_layer_3():
    st.subheader("3️⃣ The Auditor: Scientific KPI Matrix")
    st.markdown("Evaluation based on **RAGAS (2023)** and **Context Theory**.")

    artifacts = list_artifacts("L2_BENCHMARK")
    if not artifacts:
        st.info("No Benchmarks found.")
        return

    sel_files = st.multiselect("📂 Select Benchmarks", artifacts, default=artifacts[:1])
    if not sel_files: st.stop()

    # --- DATA LOADING ---
    all_records = []
    for fname in sel_files:
        data = load_artifact(fname, "L2_BENCHMARK")
        if not data: continue
        run_name = fname.replace("L2_", "").replace(".json", "")
        results = data.get("results", [])
        
        for r in results:
            items = r.get("turns", []) if "turns" in r else [r]
            for idx, item in enumerate(items):
                all_records.append({
                    "run_id": run_name,
                    "verdict_binary": 1 if item.get("verdict", "PASS") == "PASS" else 0,
                    "latency": item.get("latency", 0.0),
                    "actual": item.get("answer", "") or item.get("actual", ""),
                    "question": item.get("question", ""),
                    "turn_index": idx + 1,
                    "is_thread": "turns" in r
                })

    df = pd.DataFrame(all_records)
    if df.empty: return

    # --- CALC METRICS ---
    kpi_sys = calc_system_health(df)
    kpi_cog = calc_cognitive_dynamics(df)
    kpi_rag = calc_ragas_lite(df)
    kpi_ling = calc_linguistics(df)

    # ==========================================
    # 📊 SCIENTIFIC DASHBOARD
    # ==========================================

    t1, t2, t3, t4 = st.tabs(["⚙️ System", "🔍 Truth (RAGAS)", "🧠 Cognitive", "🗣️ Linguistics"])

    # 1. SYSTEM
    with t1:
        c1, c2, c3 = st.columns(3)
        c1.metric("Mean Latency", f"{kpi_sys['mean_latency']:.2f}s")
        c2.metric("Jitter (σ)", f"±{kpi_sys['jitter']:.2f}s")
        c3.metric("Error Rate", f"{kpi_sys['error_rate']:.1f}%", delta_color="inverse")
        
        fig = px.histogram(df, x="latency", nbins=20, title="Latency Distribution (Gaussian Check)")
        st.plotly_chart(fig, use_container_width=True)

    # 2. RAGAS (TRUTH)
    with t2:
        st.caption("Based on RAGAS Framework (Es et al., 2023)")
        c1, c2 = st.columns(2)
        c1.metric("Faithfulness (Citation %)", f"{kpi_rag['faithfulness_score']:.1f}%", 
                  help="Percentage of answers containing evidence links [x].")
        c2.metric("Relevance (Semantic Overlap)", f"{kpi_rag['relevance_score']:.1f}%",
                  help="Jaccard Similarity between Question and Answer topics.")
        
        # Scatter of Relevance vs Latency
        df["relevance"] = df.apply(lambda r: kpi_rag['relevance_score'], axis=1) # simplified for viz
        fig_rag = px.scatter(df, x="latency", y="turn_index", color="verdict_binary", title="Performance vs. Depth")
        st.plotly_chart(fig_rag, use_container_width=True)

    # 3. COGNITIVE (LOST IN MIDDLE)
    with t3:
        st.caption("Based on 'Lost in the Middle' (Liu et al., 2023)")
        c1, c2 = st.columns(2)
        drift = kpi_cog.get('latency_drift', 0)
        c1.metric("Fatigue Drift ($m$)", f"{drift:.3f}", 
                  delta="-Stable" if drift < 0.1 else "+Fatigued", delta_color="inverse")
        
        mid_loss = kpi_cog.get('middle_loss_score', 0)
        c2.metric("Mid-Context Loss", f"{mid_loss:.1f}", 
                  help="Positive score means AI is forgetting the middle of the conversation.", delta_color="inverse")

        if df["is_thread"].any():
            fig_drift = px.line(df[df["is_thread"]==True].groupby("turn_index")["latency"].mean().reset_index(), 
                                x="turn_index", y="latency", markers=True, title="Fatigue Curve")
            st.plotly_chart(fig_drift, use_container_width=True)
        else:
            st.info("Run a Threaded/Consultant test to see Cognitive metrics.")

    # 4. LINGUISTICS (PERSONA)
    with t4:
        st.caption("Based on Lexical Diversity Theory (McCarthy, 2010)")
        c1, c2 = st.columns(2)
        c1.metric("Lexical Diversity (TTR)", f"{kpi_ling['lexical_diversity_ttr']:.2f}", 
                  help="Type-Token Ratio. Higher = Richer vocabulary (Consultant). Lower = Robotic (Auditor).")
        c2.metric("Verbosity", f"{int(kpi_ling['verbosity_mean'])} chars")
        
        # Radar Chart for Personality Fingerprint
        categories = ['Faithfulness', 'Relevance', 'Lexical Diversity', 'Speed (Inv)', 'Consistency']
        vals = [
            kpi_rag['faithfulness_score']/100, 
            kpi_rag['relevance_score']/100, 
            kpi_ling['lexical_diversity_ttr'], 
            1.0 - min(kpi_sys['mean_latency']/5, 1.0),
            1.0 - min(kpi_sys['jitter']/2, 1.0)
        ]
        
        fig_radar = go.Figure(go.Scatterpolar(r=vals, theta=categories, fill='toself'))
        fig_radar.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0, 1])), title="Scientific Persona Fingerprint")
        st.plotly_chart(fig_radar, use_container_width=True)