import streamlit as st
import sys
import os

# --- PATH FIX: Tell Python where 'axiom_core' is ---
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
# ---------------------------------------------------

import json
from axiom_core.persistence import save_run
import uuid
from datetime import datetime
from axiom_core.layer2_harness.adapters import CoraHarness
st.set_page_config(page_title="Layer 2: Verification", page_icon="🔌", layout="wide")
# ==========================================
# 0. PERSISTENCE LOGIC (Save/Load Settings)
# ==========================================
CONFIG_FILE = "session_config.json"

def load_config():
    """Load saved settings from local file if it exists."""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {}

def save_config(config_data):
    """Save current settings to local file."""
    with open(CONFIG_FILE, "w") as f:
        json.dump(config_data, f, indent=2)
    st.sidebar.success("✅ Settings Saved! They will auto-load next time.")

# Load defaults on startup
defaults = load_config()

# ==========================================
# 1. SIDEBAR CONFIGURATION
# ==========================================
with st.sidebar:
    st.header("🔌 Connection Config")

    # PRE-FILL INPUTS FROM DEFAULTS
    base_url = st.text_input(
        "Base URL", 
        value=defaults.get("base_url", "https://corax-dev.automotive-ai.com/cora/api/v1")
    )
    
    username = st.text_input(
        "Username", 
        value=defaults.get("username", "")
    )
    
    password = st.text_input(
        "Password", 
        type="password", 
        value=defaults.get("password", "")
    )
    
    st.markdown("---")
    st.subheader("📄 Target Context")
    
    # Critical Fields for your test
    doc_id = st.text_input(
        "Document ID (UUID)", 
        value=defaults.get("doc_id", "91bd2a5b-13cc-46de-a68d-3e4b7926554d"),
        help="The ID of the document on the server."
    )
    
    version_name = st.text_input(
        "Version Name", 
        value=defaults.get("version_name", "Legal act"),
        help="Must match exactly (e.g. 'Legal act')"
    )

    st.markdown("---")
    
    # SAVE BUTTON
    if st.button("💾 Save Settings for Next Time"):
        current_config = {
            "base_url": base_url,
            "username": username,
            "password": password,
            "doc_id": doc_id,
            "version_name": version_name
        }
        save_config(current_config)

# ==========================================
# 2. MAIN INTERFACE
# ==========================================
st.title("🔌 Layer 2: Verification Runner")
st.markdown(f"**Target System:** `{base_url}`")

# Step 1: Upload Dataset
st.subheader("1. Load Golden Dataset")
uploaded_file = st.file_uploader("Upload 'golden_dataset.json' from Layer 1", type=["json"])

dataset = None
if uploaded_file:
    dataset = json.load(uploaded_file)
    st.info(f"✅ Loaded {len(dataset)} test cases.")

    # Show preview
    with st.expander("Preview Dataset"):
        st.json(dataset[:1])

# Step 2: Run Verification
st.subheader("2. Run Verification")

if st.button("🚀 Start Verification Run", type="primary", disabled=(dataset is None)):
    if not (username and password and doc_id):
        st.error("❌ Missing Credentials or Document ID! Check the sidebar.")
    else:
        # Initialize Harness
        harness = CoraHarness(base_url, username, password)
        
        results = []
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # Create a Container for live logs
        log_container = st.container()
        
        try:
            # Login Check
            status_text.text("🔐 Logging in...")
            if not harness.login():
                st.error("Login Failed. Check credentials.")
                st.stop()
                
            # Create Thread
            status_text.text("🧵 Creating Test Thread...")
            thread_context = harness.create_thread(
                document_id=doc_id,
                version_name=version_name,
                thread_name="AXIOM_VERIFICATION_RUN"
            )
            st.success(f"Thread Created: {thread_context['thread_id']}")
            
            # Loop through questions
            total = len(dataset)
            for i, item in enumerate(dataset):
                question = item.get("question")
                status_text.text(f"Running Q{i+1}/{total}: {question[:40]}...")
                
                # Send to CORA
                response_data = harness.ask_cora_stream( # Changed from send_message to ask_cora_stream
                    thread_context=thread_context,
                    question=question
                )
                
                # Store Result
                result_record = {
                    "id": i,
                    "question": question,
                    "golden_answer": item.get("answer"), # Expected
                    "actual_answer": response_data.get("answer"), # Actual
                    "latency": response_data.get("latency"),
                    "cora_trace": response_data.get("trace")
                }
                results.append(result_record)
                
                # Live Update in UI
                with log_container:
                    with st.expander(f"Q{i+1}: {question}", expanded=False):
                        st.markdown(f"**Cora:** {result_record['actual_answer']}")
                        st.caption(f"⏱️ {result_record['latency']:.2f}s")
                
                # Update Progress
                progress_bar.progress((i + 1) / total)
                
            status_text.text("✅ Verification Complete!")

            # --- AUTO-SAVE BLOCK START ---
            # Construct the final JSON object (Standard AXIOM Schema)
            final_output = {
                "meta": {
                    "run_id": str(uuid.uuid4()).replace("-", ""),
                    "timestamp": datetime.now().isoformat(),
                    "cora_target": base_url,
                    "doc_id": doc_id,
                    "version": version_name
                },
                "results_questions": results,  # The list of results you just generated
                "results_threads": []          # Placeholder for thread-based results if any
            }
            
            # Save to disk
            saved_path = save_run(final_output)
            st.toast(f"💾 Run saved to history: {os.path.basename(saved_path)}")
            # Store in session for immediate analysis
            st.session_state["kpi_run_data"] = final_output
            
            # Save Results for Layer 3
            st.session_state["verification_results"] = results
            
            # Offer Download
            res_json = json.dumps(results, indent=2)
            st.download_button(
                "📥 Download Results (results.json)", 
                data=res_json, 
                file_name="results.json", 
                mime="application/json"
            )
            # --- AUTO-SAVE BLOCK END ---
            st.success("🎉 Run Finished & Saved! Go to 'Home' to see history or 'Layer 3' to visualize these results.")

        except Exception as e:
            st.error(f"Run Error: {str(e)}")