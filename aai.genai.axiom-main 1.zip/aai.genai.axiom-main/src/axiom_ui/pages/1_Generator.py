import streamlit as st
import json
import pandas as pd
import sys
import os
from io import StringIO
import pymongo # New dependency

# Import your core logic
from axiom_core.layer1_generator.generator import QuestionGenerator
from axiom_core.layer1_generator.utils import estimate_cost

# --- PATH FIX: Tell Python where 'axiom_core' is ---
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
# ---------------------------------------------------
st.set_page_config(page_title="Layer 1: Generator", page_icon="⚡", layout="wide")

st.title("⚡ Layer 1: Golden Dataset Generator")
st.markdown("---")

# Initialize Session State
if "generated_questions" not in st.session_state:
    st.session_state["generated_questions"] = []
if "source_text" not in st.session_state:
    st.session_state["source_text"] = ""

# ==========================================
# 1. SIDEBAR CONFIGURATION
# ==========================================
with st.sidebar:
    st.header("⚙️ Generator Config")
    
    model_name = st.selectbox("Model", ["gpt-4-turbo", "gpt-4o", "gpt-3.5-turbo"], index=0)
    
    q_count = st.slider("Questions per Chunk", 1, 10, 3)
    
    difficulty = st.select_slider(
        "Difficulty", 
        options=["Easy (Fact Retrieval)", "Medium (Inference)", "Hard (Multi-hop Reasoning)"],
        value="Medium (Inference)"
    )
    
    focus_area = st.text_input("Focus Area (Optional)", placeholder="e.g., 'Safety Requirements'")
    
    api_key = st.text_input("OpenAI API Key", type="password")
    
    if st.button("Reset Generator"):
        st.session_state["generated_questions"] = []
        st.session_state["source_text"] = ""
        st.rerun()

# ==========================================
# 2. SOURCE DATA SELECTION
# ==========================================
st.subheader("📂 Step 1: Input Source Data")

# ✅ NEW: Added "Import from MongoDB" tab
tab1, tab2, tab3 = st.tabs(["📝 Paste Text", "📄 Upload Document", "🍃 Import from MongoDB"])

# --- TAB 1: PASTE TEXT ---
with tab1:
    text_input = st.text_area("Paste context here:", height=300, key="text_tab_input")
    if st.button("Use Pasted Text", key="btn_paste"):
        st.session_state["source_text"] = text_input
        st.success("Text loaded!")

# --- TAB 2: UPLOAD FILE ---
with tab2:
    uploaded_file = st.file_uploader("Upload PDF / TXT / JSON", type=["pdf", "txt", "json"])
    if uploaded_file:
        # Simple handler for now (expand if needed)
        if uploaded_file.type == "application/json":
            data = json.load(uploaded_file)
            # Handle list of chunks or simple dict
            if isinstance(data, list):
                st.session_state["source_text"] = "\n\n".join([f"[{d.get('section','Chunk')}] {d.get('text','')}" for d in data])
            else:
                st.session_state["source_text"] = str(data)
            st.success(f"Loaded JSON: {uploaded_file.name}")
        else:
            # Placeholder for PDF handling (assumes you have pdf logic)
            # For now, just reading as text/bytes for simplicity
            try:
                stringio = StringIO(uploaded_file.getvalue().decode("utf-8"))
                st.session_state["source_text"] = stringio.read()
                st.success(f"Loaded File: {uploaded_file.name}")
            except:
                st.warning("Could not read file as plain text. Ensure PDF parsing logic is active.")

# --- TAB 3: MONGODB IMPORT (NEW FEATURE) ---
with tab3:
    st.markdown("#### 🔌 Connect to CORA Database")
    st.caption("Use your MongoDB connection string (e.g. Atlas: `mongodb+srv://user:pass@cluster.mongodb.net`). If connection fails, check SSL/certificates and network.")

    col1, col2 = st.columns(2)
    with col1:
        mongo_uri = st.text_input("Connection String", value="mongodb://localhost:27017/", type="password")
        db_name = st.text_input("Database Name", value="cora")
    with col2:
        collection_name = st.text_input("Collection", value="chunks")
        doc_id_filter = st.text_input("Filter by Document ID", placeholder="e.g. 91bd2a5b...")

    if st.button("🍃 Fetch from MongoDB"):
        if not mongo_uri or not mongo_uri.strip():
            st.error("Please provide a Connection String.")
        else:
            try:
                with st.spinner("Connecting to MongoDB..."):
                    try:
                        import certifi
                        tls_kw = {"tlsCAFile": certifi.where()}
                    except ImportError:
                        tls_kw = {}
                    client = pymongo.MongoClient(mongo_uri, serverSelectionTimeoutMS=5000, **tls_kw)
                    client.server_info()  # Trigger connection check
                    db = client[db_name]
                    col = db[collection_name]

                    # Build Query
                    query = {}
                    if doc_id_filter:
                        query = {"$or": [{"document_id": doc_id_filter}, {"doc_id": doc_id_filter}]}

                    cursor = col.find(query).limit(500)
                    docs = list(cursor)

                    if not docs:
                        st.warning("Connection successful, but no documents found matching your filter.")
                    else:
                        # Extract text
                        extracted_texts = []
                        for d in docs:
                            content = d.get('text') or d.get('content') or d.get('page_content')
                            if content:
                                extracted_texts.append(content)
                        
                        full_content = "\n\n".join(extracted_texts)
                        st.session_state["source_text"] = full_content
                        st.success(f"✅ Successfully loaded {len(docs)} chunks from MongoDB!")
                        with st.expander("View Preview"):
                            st.write(full_content[:1000] + "...")
                            
            except Exception as e:
                err = str(e)
                st.error(f"❌ Connection failed: {err}")
                if "CERTIFICATE_VERIFY_FAILED" in err or "SSL" in err:
                    st.info("💡 For Atlas/cloud MongoDB, ensure `certifi` is installed (`pip install certifi`).")

# ==========================================
# 3. GENERATION TRIGGER
# ==========================================
st.markdown("---")
st.subheader("🚀 Step 2: Generate Questions")

current_text_len = len(st.session_state["source_text"])
if current_text_len > 0:
    st.info(f"Ready to generate from source ({current_text_len} characters).")
    
    est_cost = estimate_cost(current_text_len, model_name)
    st.caption(f"💰 Estimated Cost: ${est_cost:.4f}")

    if st.button("Generate Golden Dataset"):
        if not api_key:
            st.error("Please enter your OpenAI API Key in the sidebar.")
        else:
            gen = QuestionGenerator(api_key=api_key, model=model_name)
            
            with st.spinner("🧠 Analyzing text and dreaming up questions..."):
                # Run the generation
                result = gen.generate(
                    text=st.session_state["source_text"], 
                    count=q_count, 
                    difficulty=difficulty
                )
                
                st.session_state["generated_questions"] = result
                st.success(f"Generated {len(result)} questions!")

else:
    st.warning("👈 Please load data using one of the tabs above.")

# ==========================================
# 4. RESULTS & EXPORT
# ==========================================
questions = st.session_state["generated_questions"]

if questions:
    st.markdown("### 📊 Generated Questions")
    
    # Display as DataFrame for easy viewing
    df = pd.DataFrame(questions)
    st.dataframe(df, use_container_width=True)
    
    # Download Button
    json_str = json.dumps(questions, indent=2)
    st.download_button(
        label="📥 Download Golden Dataset (JSON)",
        data=json_str,
        file_name="golden_dataset.json",
        mime="application/json"
    )