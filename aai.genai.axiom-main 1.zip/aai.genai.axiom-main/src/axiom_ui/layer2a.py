import streamlit as st
import pandas as pd
import time
import uuid
import sys
import os
import json
from datetime import datetime

sys.path.insert(0, os.path.abspath("src"))
from axiom_core.persistence import save_artifact
from axiom_ui.logger import log
from axiom_core.mongo_loader import find_document_hierarchy, fetch_document_library_index, get_detailed_document_info, is_mongo_available

try:
    from axiom_core.layer2_harness.adapters import CoraHarness
    from axiom_core.layer1_teacher.brains import OpenSourceTeacher, PremiumTeacher
except ImportError:
    pass

def load_layer_config(layer_name="layer2a"):
    base_path = os.path.abspath("src/config") 
    file_path = os.path.join(base_path, f"{layer_name}_config.json")
    default_conf = {
        "defaults": {"objective": "Verify compliance...", "max_turns": 5},
        "judge": {
            "strict_prompt_template": "You are an Auditor. Objective: {objective}. History: {history}. Ask next question.",
            "shadow_verification_prompt": "Verify: {question} vs {answer}. PASS/FAIL."
        }
    }
    if not os.path.exists(file_path): return default_conf
    try:
        with open(file_path, "r", encoding="utf-8") as f: return json.load(f)
    except: return default_conf

def run_session(mode, objective, execution_params, harness, llm_conf, judge_conf, max_turns):
    status = st.status(f"🚀 Initializing {mode}...", expanded=True)
    brain = None
    try:
        if llm_conf.get('provider') == 'ollama': brain = OpenSourceTeacher(model_name=llm_conf.get('model_name'))
        else: brain = PremiumTeacher(api_key=llm_conf.get('api_key'))
        status.write(f"🧠 Judge Connected: {llm_conf.get('model_name')}")
    except Exception as e:
        status.update(label="❌ Brain Error", state="error")
        st.error(f"Brain connection failed: {e}")
        return

    turns_data = []
    progress = st.progress(0)
    
    final_anchor_id = "N/A"
    thread_info = {}

    for turn_i in range(max_turns):
        status.write(f"**Turn {turn_i+1}/{max_turns}:** Judge is thinking...")
        
        hist = "\n".join([f"Q: {t['q']}\nA: {t['a'][:100]}..." for t in turns_data[-3:]])
        
        # 1. GENERATE NEXT QUESTION
        prompt_template = judge_conf.get("strict_prompt_template", "")
        # CAPTURE AUDIT: The prompt used to generate the question
        gen_prompt = prompt_template.format(objective=objective, history=hist)
        
        q_text = ""
        if brain:
            try:
                if hasattr(brain, 'ask'): q_text = brain.ask(gen_prompt)
                elif hasattr(brain, 'generate'): q_text = brain.generate(gen_prompt)
                if q_text: q_text = q_text.replace("DONE", "").strip()
            except: pass
        
        if not q_text: q_text = f"Verify requirement: {objective}"

        if "DONE" in q_text:
            status.write("✅ Objective Met.")
            break

        status.write(f"🗣️ Asking CORA: {q_text[:50]}...")
        start_t = time.time()
        
        # 2. ASK CORA
        res_dict = {}
        if mode == "Discovery":
            res_dict = harness.execute_discovery(q_text)
        elif mode == "Project":
            res_dict = harness.execute_project(q_text, execution_params.get('project_id'))
        elif mode == "Single Document":
            res_dict = harness.execute_document(q_text, execution_params.get('doc_id'))
        
        lat = time.time() - start_t
        
        ans = res_dict.get('answer', 'Error')
        refs = res_dict.get('citations', [])
        grounding = res_dict.get('grounding_sources', [])
        links = res_dict.get('links', [])
        sys_meta = res_dict.get('system_metadata', {})
        images_meta = res_dict.get('images_meta', [])
        
        if res_dict.get('used_anchor_id'): final_anchor_id = res_dict['used_anchor_id']
        if res_dict.get('meta'): thread_info = res_dict['meta']

        # 3. SHADOW JUDGE VERIFICATION
        status.write("👻 Shadow Judge is verifying...")
        shadow_reply = "Verification Skipped"
        verify_prompt_snapshot = "" # Audit field
        
        if brain:
            try:
                shadow_template = judge_conf.get("shadow_verification_prompt", "")
                # CAPTURE AUDIT: The prompt used to grade the answer
                verify_prompt_snapshot = shadow_template.format(question=q_text, answer=ans)
                
                if hasattr(brain, 'ask'): shadow_reply = brain.ask(verify_prompt_snapshot)
                elif hasattr(brain, 'generate'): shadow_reply = brain.generate(verify_prompt_snapshot)
            except Exception as e: shadow_reply = f"Shadow Error: {e}"

        turns_data.append({
            "turn_id": turn_i+1, 
            "q": q_text, 
            "a": ans, 
            "shadow": shadow_reply, 
            "citations": refs, 
            "grounding_sources": grounding,
            "links": links, 
            "system_metadata": sys_meta, 
            "images_meta": images_meta,
            "latency": lat,
            # ✅ AUDIT TRAIL PER TURN
            "audit": {
                "question_gen_prompt": gen_prompt,
                "verification_prompt": verify_prompt_snapshot
            }
        })
        progress.progress((turn_i+1)/max_turns)
    
    # ✅ FULL AUDIT METADATA
    full_meta = {
        "mode": mode, 
        "objective": objective,
        "timestamp": datetime.now().isoformat(),
        "target_id": execution_params.get('doc_id') or execution_params.get('project_id') or "Global",
        "used_anchor_id": final_anchor_id,
        "thread_info": thread_info,
        "judge_config_used": "layer2a_config.json",
        "judge_llm_snapshot": {
            "model": llm_conf.get("model_name"),
            "provider": llm_conf.get("provider"),
            "temperature": llm_conf.get("temperature", "Unknown")
        }
    }
    
    if "doc_meta" in execution_params: full_meta["enriched_doc_info"] = execution_params["doc_meta"]
    
    if "project_meta" in execution_params:
        full_meta["project_info"] = execution_params["project_meta"]
        if "enriched_project_docs" in execution_params:
            full_meta["project_documents_detailed"] = execution_params["enriched_project_docs"]

    final_payload = []
    for t in turns_data:
        final_payload.append({
            "turn_id": t['turn_id'], 
            "question": t['q'], 
            "cora_answer": t['a'],
            "shadow_answer": t['shadow'], 
            "citations": t['citations'],
            "grounding_sources": t['grounding_sources'],
            "links": t['links'], 
            "system_metadata": t['system_metadata'], 
            "images_meta": t['images_meta'],
            "latency": t['latency'],
            "audit_trace": t['audit'] # ✅ Saving the prompts
        })

    payload = {
        "id": str(uuid.uuid4()), "type": "L2A_VIVA",
        "metadata": full_meta, "payload": final_payload
    }
    fname = save_artifact("L2A_VIVA", payload, f"Viva_{mode}")
    status.update(label=f"✅ Saved: {fname}", state="complete", expanded=False)


def render_layer_2a():
    CONFIG = load_layer_config("layer2a")
    DEFAULTS = CONFIG.get("defaults", {})
    JUDGE_CONF = CONFIG.get("judge", {})
    
    st.subheader("2️⃣🅰️ The Interrogator: Dynamic Viva Mode")
    
    cora_conf = st.session_state.get('cora_config', {})
    llm = st.session_state.get('llm_config', {})
    
    harness = None
    if cora_conf.get('base_url'):
        harness = CoraHarness(cora_conf['base_url'], cora_conf['username'], cora_conf['password'])

    c1, c2 = st.columns([1, 3])
    with c1:
        default_turns = DEFAULTS.get("max_turns", 5)
        max_turns = st.slider("Max Turns", 3, 20, default_turns, key="l2a_turns")
    with c2:
        st.caption(f"🧠 Judge: {llm.get('provider', 'ollama').upper()} ({llm.get('model_name')})")

    tab_disc, tab_proj, tab_doc, tab_user = st.tabs([
        "🌍 1. Discovery", "📂 2. Project", "📄 3. Single Document", "👤 4. User Document"
    ])
    
    def_objective = DEFAULTS.get("objective", "Verify compliance requirements regarding system safety.")

    # === MODE 1: DISCOVERY ===
    with tab_disc:
        st.caption("Global interrogation across CORA knowledge base.")
        obj_disc = st.text_area("Objective", value=def_objective, height=100, key="obj_disc")
        if st.button("🔥 Start Discovery", type="primary", key="btn_disc", disabled=(not harness)):
            run_session("Discovery", obj_disc, {}, harness, llm, JUDGE_CONF, max_turns)

    # === MODE 2: PROJECT (Deep Enrichment) ===
    with tab_proj:
        st.caption("Interrogate documents linked to a Project.")
        if harness:
            if st.button("🔄 Refresh Projects", key="btn_refresh_proj"): pass
            projects = harness.get_all_projects()
            if projects:
                proj_map = {p['project_name']: p['project_id'] for p in projects}
                sel_proj_name = st.selectbox("Select Project", list(proj_map.keys()), key="l2a_proj_select")
                sel_proj_id = proj_map[sel_proj_name]
                
                params_proj = {"project_id": sel_proj_id}
                
                if sel_proj_id:
                    details = harness.get_project_details(sel_proj_id)
                    params_proj["project_meta"] = {"name": sel_proj_name, "id": sel_proj_id}
                    
                    if details and details.get('attached_documents'):
                        doc_list = details['attached_documents']
                        st.success(f"✅ {len(doc_list)} docs linked.")
                        
                        enriched_docs = []
                        with st.spinner("Analyzing Hierarchy & Metadata..."):
                            for d in doc_list:
                                cora_id = d.get('document_id')
                                doc_entry = {
                                    "cora_id": cora_id,
                                    "cora_name": d.get('document_name'),
                                    "version": d.get('version_name')
                                }
                                
                                hierarchy_info = find_document_hierarchy(cora_id)
                                
                                if hierarchy_info:
                                    meta = hierarchy_info["metadata"]
                                    doc_entry["mongo_status"] = "✅ Found"
                                    doc_entry["mongo_title"] = meta.get('title')
                                    doc_entry["mongo_date"] = meta.get('date_document')
                                    doc_entry["mongo_celex"] = meta.get('celex_id')
                                    doc_entry["relation"] = hierarchy_info.get("hierarchy_type", "Root")
                                    if hierarchy_info.get("parent_id"):
                                        doc_entry["parent_id"] = hierarchy_info["parent_id"]
                                        doc_entry["parent_title"] = hierarchy_info.get("parent_title", "Unknown Parent")
                                else:
                                    doc_entry["mongo_status"] = "⚠️ Not Found (User Upload?)"
                                
                                enriched_docs.append(doc_entry)
                        
                        params_proj["enriched_project_docs"] = enriched_docs
                        
                        preview_df = pd.DataFrame(enriched_docs)
                        cols = [c for c in ["cora_name", "mongo_status", "relation", "parent_title"] if c in preview_df.columns]
                        st.dataframe(preview_df[cols], use_container_width=True, hide_index=True)

                    else: st.warning("⚠️ No documents.")

                obj_proj = st.text_area("Objective", value=def_objective, height=100, key="obj_proj")
                if st.button("🔥 Start Project Audit", type="primary", key="btn_run_proj"):
                     run_session("Project", obj_proj, params_proj, harness, llm, JUDGE_CONF, max_turns)
            else: st.warning("No Projects found.")
        else: st.error("Connect to CORA first.")

    # === MODE 3: SINGLE DOCUMENT ===
    with tab_doc:
        st.caption("Search and deep dive into a specific document.")
        mongo_ok, mongo_msg = is_mongo_available()
        if not mongo_ok:
            st.warning(f"⚠️ Document library unavailable: {mongo_msg} Search will be disabled.")
        c1, c2 = st.columns([3, 1])
        search_q = c1.text_input("🔍 Search Library", placeholder="e.g. ISO 26262", key="l2a_doc_search_in", disabled=not mongo_ok)
        if c2.button("Search", key="l2a_doc_search_btn", disabled=not mongo_ok):
            st.session_state['doc_search_results'] = fetch_document_library_index(search_q)
            if not st.session_state.get('doc_search_results') and mongo_ok:
                st.info("No documents matched your search.")
        results = st.session_state.get('doc_search_results', [])
        doc_id = None
        if results:
            options = {f"{r['full_title']} ({r['id'][:8]}...)": r['id'] for r in results}
            selected_label = st.selectbox("Select Document:", list(options.keys()), key="l2a_doc_select")
            if selected_label: doc_id = options[selected_label]
        
        if not doc_id:
            def_id = st.session_state.get('l1_selected_docs', [""])[0] if st.session_state.get('l1_selected_docs') else ""
            doc_id = st.text_input("Or Paste UUID", value=def_id, key="l2a_paste_id")

        params_doc = {}
        if doc_id:
            if not mongo_ok:
                st.warning("Document library is unavailable; audit can run but document metadata may be missing.")
            meta_info = get_detailed_document_info(doc_id) if mongo_ok else None
            if meta_info:
                st.success(f"Target: {meta_info.get('title')}")
                params_doc["doc_meta"] = meta_info
            params_doc["doc_id"] = doc_id

        obj_doc = st.text_area("Objective", value=def_objective, height=100, key="obj_doc")
        if st.button("🔥 Start Document Audit", type="primary", disabled=(not doc_id), key="btn_run_doc"):
             run_session("Single Document", obj_doc, params_doc, harness, llm, JUDGE_CONF, max_turns)

    with tab_user: st.info("🚧 Future Feature")