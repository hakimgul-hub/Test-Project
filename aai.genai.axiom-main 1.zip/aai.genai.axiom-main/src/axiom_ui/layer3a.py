import streamlit as st
import pandas as pd
import plotly.express as px
import sys
import os

sys.path.insert(0, os.path.abspath("src"))
from axiom_core.persistence import list_artifacts, load_artifact

def calculate_similarity(text1, text2):
    t1 = set(str(text1).lower().split())
    t2 = set(str(text2).lower().split())
    if not t1 or not t2: return 0.0
    return len(t1.intersection(t2)) / len(t1.union(t2))

def render_layer_3a():
    st.subheader("3️⃣🅰️ The Profiler: Behavioral Analysis")
    
    viva_files = list_artifacts("L2A_VIVA")
    if not viva_files:
        st.info("No Viva Sessions found. Run Layer 2a first.")
        return

    selected_file = st.selectbox("📂 Select Viva Session", viva_files)
    
    if selected_file:
        data = load_artifact(selected_file, "L2A_VIVA")
        if data is None:
            st.error(f"❌ Error: Could not load '{selected_file}'. File is missing or empty.")
            return

        turns = data.get('payload', [])
        meta = data.get('metadata', {})
        
        with st.expander("ℹ️ Session Metadata", expanded=False):
            st.json(meta)
            
        st.info(f"**Objective:** {meta.get('objective', 'No Objective Found')}")
        
        if not turns:
            st.warning("Empty Session Data.")
            return

        df = pd.DataFrame(turns)
        
        # 🛡️ Safety Block
        if 'turn_id' not in df.columns:
            df['turn_id'] = range(1, len(df) + 1)
        if 'latency' not in df.columns:
            df['latency'] = 0.0
        if 'shadow_answer' not in df.columns:
            df['shadow_answer'] = ""

        df['alignment'] = df.apply(lambda x: calculate_similarity(x.get('cora_answer', ''), x.get('shadow_answer', '')), axis=1)

        k1, k2, k3 = st.columns(3)
        k1.metric("Turns", len(df))
        k2.metric("Avg Latency", f"{df['latency'].mean():.2f}s")
        k3.metric("Brain Alignment", f"{df['alignment'].mean()*100:.1f}%")

        st.divider()
        
        c1, c2 = st.columns(2)
        with c1:
            if not df['latency'].isnull().all():
                fig1 = px.line(df, x="turn_id", y="latency", title="Latency over Time", markers=True)
                st.plotly_chart(fig1)
        with c2:
            fig2 = px.bar(df, x="turn_id", y="alignment", title="Shadow Agreement Score", range_y=[0,1])
            st.plotly_chart(fig2)

        st.subheader("📜 Transcript")
        for i, row in df.iterrows():
            q_raw = row.get('question', '')
            q_preview = q_raw[:50] + "..." if len(q_raw) > 50 else q_raw
            
            t_id = row.get('turn_id', i+1)
            
            with st.expander(f"Turn {t_id}: {q_preview}", expanded=False):
                st.markdown("**🗣️ Full Question:**")
                st.write(q_raw or 'N/A')  
                
                c1, c2 = st.columns(2)
                with c1:
                    st.info(f"**CORA:**\n\n{row.get('cora_answer', 'N/A')}")
                with c2:
                    st.success(f"**Shadow:**\n\n{row.get('shadow_answer', 'N/A')}")
                
                if row.get('citations'):
                    st.caption(f"📚 Citations found: {len(row['citations'])}")
                    st.json(row['citations'], expanded=False)

                if row.get('grounding_sources'):
                    st.caption(f"🔍 Grounding Sources: {len(row['grounding_sources'])}")
                    st.json(row['grounding_sources'], expanded=False)