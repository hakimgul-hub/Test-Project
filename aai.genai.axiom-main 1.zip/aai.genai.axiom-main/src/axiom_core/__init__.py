"""
AXIOM core: backend for the Teacher → Examiner → Judge verification pipeline.
Subpackages: api, layer1_teacher, layer2_harness, layer3_judge, llm, services.
"""
