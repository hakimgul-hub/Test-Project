from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import json
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging
import requests

# --- SDK IMPORTS ---
from src.axiom_core.layer2_harness.cora_sdk.config import Config
from src.axiom_core.layer2_harness.cora_sdk.auth import login
from src.axiom_core.layer2_harness.cora_sdk.api.threads import create_thread, make_thread_name
from src.axiom_core.layer2_harness.cora_sdk.api.llm import ask_llm_stream
from src.axiom_core.layer2_harness.cora_sdk.api.grounding import extract_ids_by_type, resolve_grounding_sources_cached
from src.axiom_core.layer2_harness.cora_sdk.api.projects import create_project, ensure_project_documents_attached

from src.axiom_core.llm import LLMCaller

# ✅ FIX: Use Relative Import for Dependencies (Matches other files)
# We try multiple levels to ensure it finds dependencies.py wherever it is.
from src.axiom_core.api.dependencies import mongo, LLM_PROFILES, load_api_keys, DATA_DIR, TEACHER_DIR, EXAMINER_DIR, get_secrets_path

try:
    from bson import Binary, ObjectId
except ImportError:
    Binary = bytes
    ObjectId = str

# Define HAS_MONGO based on import success
HAS_MONGO = 'mongo' in globals()

router = APIRouter()
logger = logging.getLogger("AxiomCore.Interrogator")


# --- MODELS ---
class SessionStartRequest(BaseModel):
    mode: str = "discovery" 
    doc_id: Optional[str] = None
    doc_ids: Optional[List[str]] = []
    model_id: Optional[str] = None
    topic_text: Optional[str] = None 

class ChatRequest(BaseModel):
    session_context: Dict[str, Any]
    question: str
    model_id: Optional[str] = None

class NextQuestionRequest(BaseModel):
    chat_history: List[Dict[str, Any]] 
    model_id: str
    doc_title: Optional[str] = "the document"

# --- HELPERS ---

def _inject_secrets_into_config(cfg: Config):
    path = get_secrets_path()
    creds = {}
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                raw = json.load(f)
                if "cora_dev" in raw: raw = raw["cora_dev"]
                elif "cora" in raw: raw = raw["cora"]
                creds = {
                    "username": raw.get("username") or raw.get("cora_user"),
                    "password": raw.get("password") or raw.get("cora_pass"),
                    "base_url": raw.get("base_url") or raw.get("cora_base_url"),
                }
        except Exception:
            pass

    if creds.get("username"): cfg.username = creds["username"]
    if creds.get("password"): cfg.password = creds["password"]
    
    base = creds.get("base_url", "")
    if base:
        base = base.rstrip("/")
        if base.endswith("/cora"): base = base[:-5]
        cfg.base_url = base

def _create_unique_run_project(sess, token, cfg, run_id, mode):
    date_str = datetime.now().strftime("%Y%m%d")
    app_name = "Inter"
    mode_map = {
        "document": "SingleDoc", "single_doc": "SingleDoc",
        "user_document": "UserDoc", "user_doc": "UserDoc",
        "discovery": "Discovery",
        "pct": "PCT", "project": "PCT"
    }
    mode_str = mode_map.get(mode.lower(), "PCT")
    rid_short = run_id[:4]
    
    unique_name = f"{date_str}_{app_name}_{mode_str}_{rid_short}"
    logger.info("Creating project: %s", unique_name)
    try:
        new_proj = create_project(sess, token, cfg, unique_name, f"Interrogation Session {run_id}")
        data = new_proj.get("data", new_proj)
        pid = data.get("project_id") or data.get("id")
        return pid
    except Exception as e:
        logger.warning("Failed to create unique project: %s", e)
        return None

def get_save_path(mode, run_id):
    folder_map = {
        "single_doc": "SingleDoc", "document": "SingleDoc",
        "project": "Project", "pct": "Project",
        "discovery": "Discovery",
        "user_doc": "UserDoc", "user_document": "UserDoc"
    }
    folder_name = folder_map.get(mode, "Discovery")
    
    base_dir = os.path.join(EXAMINER_DIR, folder_name)
    os.makedirs(base_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%Hh%M_%S")
    return os.path.join(base_dir, f"Viva_{folder_name}_{ts}_{run_id}.json")

def save_chat_turn(filepath, data):
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        mode = "w" if not os.path.exists(filepath) else "r+"
        with open(filepath, mode) as f:
            content = {"turns": []}
            if mode == "r+":
                content = json.load(f)
                if not content.get("turns"): content["turns"] = []
                f.seek(0)
            
            # Append new turn
            content["turns"].append(data)
            json.dump(content, f, indent=2)
    except Exception as e:
        logger.exception("Error saving chat turn: %s", e)

def clean_mongo_id(raw_id: Any) -> str:
    if raw_id is None: return ""
    if isinstance(raw_id, Binary):
        try: return str(uuid.UUID(bytes=raw_id))
        except: pass 
    if isinstance(raw_id, bytes):
        try: return str(uuid.UUID(bytes=raw_id))
        except: pass
    s_id = str(raw_id)
    if s_id.startswith("b'") or s_id.startswith('b"'): s_id = s_id[2:-1]
    try:
        uuid.UUID(s_id)
        return s_id
    except:
        if "\\x" in s_id: return "" 
        return s_id

# --- ROUTERS ---

@router.post("/start")
def start_interrogation_session(req: SessionStartRequest):
    logger.info("Starting Interrogator session [%s]", req.mode)
    run_id = uuid.uuid4().hex
    
    try:
        # 1. Init SDK
        cfg = Config()
        _inject_secrets_into_config(cfg)
        sess = requests.Session()
        token = login(sess, cfg)
        if not token: raise Exception("Login failed")

        full_path = get_save_path(req.mode, run_id)
        # Init file
        save_chat_turn(full_path, {
            "event": "session_start", 
            "mode": req.mode,
            "created_at": datetime.now().isoformat(),
            "examiner_configuration": { "mode": req.mode } # Helps Judge identify mode
        })

        # 2. Resolve Context
        project_id = None
        target_doc_id = None
        
        if req.mode in ["project", "pct"]:
            if not req.doc_ids: raise HTTPException(400, "Project requires doc_ids")
            project_id = _create_unique_run_project(sess, token, cfg, run_id, "pct")
            if not project_id: raise Exception("Failed to create project context")
            
            attachments = []
            for d in req.doc_ids:
                clean_id = clean_mongo_id(d)
                if clean_id and clean_id != cfg.project_context_thread_doc_id:
                    attachments.append({
                        "document_id": clean_id,
                        "document_type": "library", 
                        "version_name": "Legal act",
                        "language": "EN"
                    })
            if attachments: ensure_project_documents_attached(sess, token, cfg, project_id, attachments)
            target_doc_id = cfg.project_context_thread_doc_id 

        elif req.mode in ["single_doc", "document", "user_doc", "user_document"]:
             if not req.doc_id: raise HTTPException(400, "Doc ID required")
             target_doc_id = clean_mongo_id(req.doc_id)
             if not target_doc_id: raise HTTPException(400, "Invalid Document ID format")

        else:
            target_doc_id = cfg.discovery_thread_doc_id

        # 3. Create Thread
        t_name = make_thread_name(f"Viva_{req.mode}")
        if not target_doc_id: raise Exception(f"Invalid Configuration: Missing Target Document ID for mode {req.mode}")

        thread_ids = create_thread(
            sess=sess, token=token, cfg=cfg,
            document_id=target_doc_id,
            version_name="Legal act",
            thread_name=t_name,
            project_id=project_id,
            language="EN"
        )
        
        ctx = {
            "mode": req.mode,
            "thread_ids": thread_ids,
            "document_id": target_doc_id,
            "project_id": project_id,
            "_log_filepath": full_path
        }
        return {"status": "Ready", "session_context": ctx}

    except Exception as e:
        logger.exception("Start error: %s", e)
        raise HTTPException(500, f"Start Failed: {str(e)}")

@router.post("/chat")
def chat_interrogation(req: ChatRequest):
    ctx = req.session_context
    try:
        # 1. Re-Auth
        cfg = Config()
        _inject_secrets_into_config(cfg)
        sess = requests.Session()
        token = login(sess, cfg)
        
        # 2. Ask SDK
        resp = ask_llm_stream(
            sess=sess, token=token, cfg=cfg,
            ids=ctx["thread_ids"],
            document_id=ctx["document_id"],
            version_name="Legal act",
            question=req.question,
            document_part=cfg.document_part,
            language="EN"
        )
        
        answer_text = resp.get("answer_text") or "No textual answer."
        
        # 3. Resolve Grounding (Real-Time Hydration)
        clean_grounding = []
        raw_grounding = resp.get("grounding_sources", [])
        raw_links = resp.get("links", []) or resp.get("references", [])
        
        ids_by_type = extract_ids_by_type(raw_grounding)
        fetched_details_map = {}
        
        if ids_by_type:
            try:
                details_list = resolve_grounding_sources_cached(sess, token, cfg, ids_by_type)
                for d in details_list:
                    cid = d.get("chunk_id") or d.get("id")
                    if cid: fetched_details_map[cid] = d
            except Exception as e:
                logger.warning("Failed to fetch grounding details: %s", e)

        # (A) Process Chunks
        for source in raw_grounding:
            cid = source.get("chunk_id") or source.get("id")
            rich_info = fetched_details_map.get(cid, source)
            
            clean_grounding.append({
                "type": "Chunk",
                "doc_id": cid,
                "doc_name": rich_info.get("document_title") or rich_info.get("title") or rich_info.get("document_name") or "Unknown Doc",
                "text": rich_info.get("text_content") or rich_info.get("text") or rich_info.get("content") or "[TEXT MISSING]",
                "score": source.get("score", 0)
            })

        # (B) Process Links
        for link in raw_links:
            clean_grounding.append({
                "type": "Link",
                "doc_id": link.get("document_id") or "LINK",
                "doc_name": link.get("title") or link.get("document_name") or "Reference Link",
                "text": link.get("document_url") or link.get("url") or "No URL",
                "score": 1.0
            })

        # 4. Log to File
        if ctx.get("_log_filepath"):
            save_chat_turn(ctx["_log_filepath"], {
                "question": req.question,
                "answer_text": answer_text, 
                "student_answer": answer_text, 
                "timestamp": datetime.now().isoformat(),
                "grounding_sources_details": clean_grounding, 
                "links": raw_links 
            })

        return {
            "answer_text": answer_text,
            "clean_grounding": clean_grounding, 
            "links": raw_links
        }

    except Exception as e:
        logger.exception("Chat error: %s", e)
        return {"answer_text": f"Error: {str(e)}"}

@router.post("/generate_question")
def generate_next_question(req: NextQuestionRequest):
    try:
        # ------------------------------------------------------------------
        # ✅ FIX: Initialize Brain based on Profile (Cloud vs Local)
        # ------------------------------------------------------------------
        api_keys = load_api_keys()
        
        # Look up profile or use defaults
        model_key = req.model_id
        model_conf = LLM_PROFILES.get("profiles", {}).get(model_key, {})
        
        provider = model_conf.get("provider", "local")
        # Strip local_ prefix if present for clean lookup
        clean_name = model_conf.get("model_name", "llama3")
        
        api_key = None
        base_url = model_conf.get("base_url")
        if provider in ["openai", "anthropic", "azure", "google", "gemini"]:
            secret_key_name = model_conf.get("api_key_env", provider)
            api_key = api_keys.get(secret_key_name) or api_keys.get(provider) or os.getenv(secret_key_name)
            if not api_key:
                logger.warning("Examiner: missing API key for '%s'; using fallback local", provider)
                provider, clean_name = "ollama", "llama3"
                base_url = None  # don't use cloud endpoint for ollama
            else:
                logger.info("Using cloud Examiner: %s (%s)", clean_name, provider)
        else:
            logger.info("Using local Examiner: %s", clean_name)
        brain = LLMCaller(
            provider=provider,
            model=clean_name,
            temperature=0.7,
            base_url=base_url,
            api_key=api_key,
        )
        # ------------------------------------------------------------------

        # Build Context
        hist = "\n".join([f"{m.get('role', 'unknown').upper()}: {m.get('content', '')}" for m in req.chat_history[-6:]])
        
        # Prompt
        prompt = f"""You are a strict and skeptical Automotive Compliance Auditor.
You are interviewing an AI assistant (the Candidate) about: "{req.doc_title}".

HISTORY:
{hist}

TASK:
Based on the Candidate's last answer, ask the next logical, probing follow-up question. 
Dig deeper into specific details, safety margins, or evidence.
If the answer was vague, demand clarification.

OUTPUT FORMAT:
REASONING: <brief thought process>
QUESTION: <your question here>
"""
        
        res = brain.generate(prompt)
        
        reason, quest = "Follow-up", res
        if "QUESTION:" in res:
            parts = res.split("QUESTION:")
            reason = parts[0].replace("REASONING:", "").strip()
            quest = parts[1].strip()
            
        return {"question": quest, "reasoning": reason}
        
    except Exception as e:
        logger.exception("Examiner error: %s", e)
        return {"question": "Can you elaborate on the safety requirements mentioned in the document?", "reasoning": "Fallback due to generation error."}

@router.get("/library/search")
def search_lib(q: str = ""):
    res = []
    # 1. Mongo Search (only when MongoDB is available)
    if HAS_MONGO and getattr(mongo, "enabled", False):
        try:
            for col in ['library', 'documents', 'fs.files']:
                if mongo.db and col in mongo.db.list_collection_names():
                    cur = mongo.db[col].find({"$or": [{"title": {"$regex": q, "$options": "i"}}, {"filename": {"$regex": q, "$options": "i"}}]}).limit(10)
                    for d in cur: 
                        raw_id = d.get("id") or d.get("_id")
                        clean_id = clean_mongo_id(raw_id)
                        res.append({"id": clean_id, "title": d.get("title") or d.get("filename"), "type": "Database"})
        except Exception as e: 
            logger.exception("Mongo search error: %s", e)
    
    # 2. File Search (Fallback)
    try:
        if os.path.exists(TEACHER_DIR):
            for r, _, f in os.walk(TEACHER_DIR):
                for file in f:
                    if q.lower() in file.lower(): 
                        full_path = os.path.join(r, file)
                        res.append({"id": full_path, "title": file, "type": "File"})
    except: pass
    
    return res

@router.get("/artifacts")
def list_artifacts():
    try:
        res = []
        if os.path.exists(EXAMINER_DIR):
            for r, _, f in os.walk(EXAMINER_DIR):
                for file in f:
                    if file.startswith("Viva_"):
                        ts = os.path.getmtime(os.path.join(r, file))
                        res.append({"filename": file, "created_at": datetime.fromtimestamp(ts).isoformat()})
    except: pass
    return sorted(res, key=lambda x: x.get('created_at',''), reverse=True)