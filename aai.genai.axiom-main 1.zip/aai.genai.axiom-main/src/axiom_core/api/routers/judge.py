from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from pydantic import BaseModel
import os
from typing import Optional, Set
import json
import uuid
import datetime
import base64
import mimetypes
from typing import Dict, Optional, List, Any
import logging

from src.axiom_core.api.dependencies import (
    TEACHER_DIR,
    EXAMINER_DIR,
    JUDGE_DIR,
    CONFIG_ASSETS_DIR,
)
from src.axiom_core.services.judge_service import JudgeService

router = APIRouter()
logger = logging.getLogger("AxiomCore.Judge")

def _resolve_image(img_obj: Dict) -> Optional[str]:
    b64 = img_obj.get("image_base64") or img_obj.get("base64")
    if b64: 
        if not b64.startswith("data:image"): return f"data:image/png;base64,{b64}"
        return b64
    path = img_obj.get("image_path")
    if path and os.path.exists(path):
        try:
            mime_type, _ = mimetypes.guess_type(path)
            if not mime_type: mime_type = "image/png"
            with open(path, "rb") as f:
                encoded = base64.b64encode(f.read()).decode('utf-8')
                return f"data:{mime_type};base64,{encoded}"
        except: return None
    return None

def _load_asset_as_base64(filename: str) -> Optional[str]:
    path = os.path.join(CONFIG_ASSETS_DIR, filename)
    if os.path.exists(path):
        try:
            with open(path, "rb") as f:
                encoded = base64.b64encode(f.read()).decode("utf-8")
                mime_type, _ = mimetypes.guess_type(path)
                return f"data:{mime_type or 'image/png'};base64,{encoded}"
        except Exception as e:
            logger.warning("Error loading asset %s: %s", filename, e)
    return None


# --- MODELS ---
class JudgeRunRequest(BaseModel):
    candidate_file: str  
    teacher_file: str    
    model_name: str = "gpt-4o" 

# --- FILE SCANNER ---
# For Judge: UI mode -> (candidate folders under Examiner, reference folders under Teacher)
JUDGE_CANDIDATE_FOLDERS = {"single_doc": {"Document"}, "discovery": {"Discovery"}, "project": {"PCT"}, "user_doc": {"UserDoc"}}
JUDGE_REFERENCE_FOLDERS = {"single_doc": {"SingleDoc"}, "discovery": {"Discovery"}, "project": {"Project"}, "user_doc": {"UserDoc"}}
# Judge results: mode -> set of folder names under data/Judge/. Root = fallback for unknown/unrecognized mode (still used).
JUDGE_RESULT_FOLDERS = {"single_doc": {"SingleDoc"}, "discovery": {"Discovery"}, "project": {"Project"}, "user_doc": {"UserDoc"}, "root": {"Root"}, "all": None}


def _scan_files_recursive(base_path: str, allowed_folders: Optional[Set[str]] = None):
    results = []
    if not os.path.exists(base_path): return results
    for root, _, files in os.walk(base_path):
        folder = os.path.basename(root)
        if folder == "Examiner": folder = "Root"
        if allowed_folders is not None and folder not in allowed_folders:
            continue
        for f in files:
            if f.endswith(".json"):
                full_path = os.path.join(root, f)
                rel_path = os.path.relpath(full_path, base_path)
                f_type = "Unknown"
                if "cora_" in f or "Batch" in f: f_type = "Examiner (Student)"
                elif "Viva_" in f: f_type = "Viva (Interview)"
                elif "Teacher" in f: f_type = "Teacher (Ref)"
                elif "Judge" in f: f_type = "Judge (Result)"
                try:
                    size_kb = round(os.path.getsize(full_path) / 1024, 1)
                except Exception:
                    size_kb = 0
                results.append({
                    "filename": f, "relative_path": rel_path, "type": f_type, "folder": folder,
                    "created_at": datetime.datetime.fromtimestamp(os.path.getmtime(full_path)).isoformat(),
                    "size_kb": size_kb,
                })
    return sorted(results, key=lambda x: x["created_at"], reverse=True)

def _load_json_file(base_dir, rel_path):
    path = os.path.join(base_dir, rel_path)
    if not os.path.exists(path): raise FileNotFoundError(f"File not found: {path}")
    with open(path, 'r', encoding='utf-8') as f: return json.load(f)

# --- WORKER (delegates to JudgeService) ---
def _run_judge_task(run_id: str, req: JudgeRunRequest) -> None:
    try:
        JudgeService.run_evaluation(
            run_id=run_id,
            candidate_file=req.candidate_file,
            teacher_file=req.teacher_file,
            model_name=req.model_name,
        )
    except Exception as e:
        logger.exception("Judge run failed: %s", e)

# --- ROUTES ---
@router.get("/assets/logos")
def get_logos():
    return {
        "axiom_logo": _load_asset_as_base64("axiom_logo.png"),
        "company_logo": _load_asset_as_base64("company_logo.png")
    }

@router.get("/artifacts")
def list_available_files(mode: Optional[str] = Query(None, description="Filter by use case: single_doc, discovery, project, user_doc")):
    mode_key = (mode or "").strip().lower() if mode else None
    cand_folders = JUDGE_CANDIDATE_FOLDERS.get(mode_key) if mode_key else None
    ref_folders = JUDGE_REFERENCE_FOLDERS.get(mode_key) if mode_key else None
    candidates = _scan_files_recursive(EXAMINER_DIR, cand_folders)
    references = _scan_files_recursive(TEACHER_DIR, ref_folders)
    return {"candidates": candidates, "references": references}

@router.get("/results")
def list_results(mode: Optional[str] = Query(None, description="Filter by use case: single_doc, discovery, project, user_doc, root (uncategorized), or all")):
    mode_key = (mode or "").strip().lower() if mode else None
    folders = JUDGE_RESULT_FOLDERS.get(mode_key) if mode_key else None
    return _scan_files_recursive(JUDGE_DIR, folders)

@router.get("/report")
def get_report(path: str = Query(...)):
    return _load_json_file(JUDGE_DIR, path.replace("..", ""))

# ✅ FIX: Required Endpoint for Frontend Auto-Matching
@router.get("/artifact_content")
def get_artifact_content(path: str):
    """
    Retrieves the content of a candidate/student file so the frontend 
    can extract the run_id for deep auto-matching.
    """
    examiner_root = EXAMINER_DIR
    target_path = os.path.join(examiner_root, path)
    
    if not os.path.abspath(target_path).startswith(os.path.abspath(examiner_root)):
        raise HTTPException(status_code=400, detail="Invalid path security check")

    if not os.path.exists(target_path):
        filename = os.path.basename(path)
        found_path = None
        for root, _, files in os.walk(examiner_root):
            if filename in files:
                found_path = os.path.join(root, filename)
                break
        if found_path: target_path = found_path
        else: raise HTTPException(status_code=404, detail="File not found")

    try:
        with open(target_path, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/run")
def run_judge(req: JudgeRunRequest, bg_tasks: BackgroundTasks):
    run_id = str(uuid.uuid4())
    bg_tasks.add_task(_run_judge_task, run_id, req)
    return {"status": "Started", "run_id": run_id}