from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import logging
import datetime
import os
import json
import requests  # ✅ NEW: Required for fetching project lists

# Import your modules
from src.axiom_core.mongo_loader import get_mongo_client, MONGO_CONF, is_mongo_available
from src.axiom_core.layer2_harness.adapters import CoraHarness

router = APIRouter(prefix="/projects", tags=["Projects"])
logger = logging.getLogger(__name__)

# --- CONFIGURATION ---
# We force the path to src/config/secrets.json relative to the project root
SECRETS_PATH = "src/config/secrets.json"

# --- Pydantic Models ---
class ProjectInitRequest(BaseModel):
    name: str
    description: Optional[str] = "Created via Axiom API"
    celex_ids: List[str]

class ProjectInitResponse(BaseModel):
    project_id: str
    project_name: str
    linked_documents: int
    missing_celex: List[str]

# --- Helper to Load Secrets ---
def load_secrets():
    # 1. Try path relative to execution root
    if os.path.exists(SECRETS_PATH):
        logger.info(f"📂 Loading secrets from: {os.path.abspath(SECRETS_PATH)}")
        with open(SECRETS_PATH, 'r') as f: 
            return json.load(f)
            
    # 2. Try absolute path relative to this file (fallback)
    current_file = os.path.abspath(__file__) # src/axiom_core/api/routers/projects_examiner.py
    # Go up 4 levels: routers -> api -> axiom_core -> src -> (config)
    alt_path = os.path.join(os.path.dirname(current_file), "../../../../src/config/secrets.json")
    alt_path = os.path.abspath(alt_path)
    
    if os.path.exists(alt_path):
        logger.info(f"📂 Loading secrets from fallback: {alt_path}")
        with open(alt_path, 'r') as f: 
            return json.load(f)

    logger.error(f"❌ secrets.json not found at {SECRETS_PATH} or {alt_path}")
    return {}

# --- Helper to Resolve IDs ---
def resolve_celex(celex_ids: List[str]):
    try:
        client = get_mongo_client()
        if not client:
            logger.error("❌ Failed to create Mongo Client")
            return [], celex_ids

        db = client[MONGO_CONF["db"]]
        col_name = MONGO_CONF.get("col", "documents")
        
        # Robust collection selection
        if "library" in db.list_collection_names():
            col = db["library"]
        else:
            col = db[col_name]
        
        resolved = []
        missing = []
        
        for celex in celex_ids:
            doc = col.find_one({"celex_id": celex})
            if not doc:
                doc = col.find_one({"id": celex})

            if doc:
                cora_id = doc.get("cora_id") or doc.get("id") or doc.get("_id")
                if cora_id:
                    resolved.append({
                        "document_id": str(cora_id),
                        "document_type": "library",
                        "version_name": doc.get("version", "Legal act"),
                        "language": "EN"
                    })
                else:
                    missing.append(celex)
            else:
                missing.append(celex)
                
        return resolved, missing

    except Exception as e:
        logger.error(f"Mongo Resolution Failed: {e}")
        return [], celex_ids

# --- New Endpoint: List Projects (For Frontend Dropdown) ---
@router.get("/")
def list_projects():
    """
    Fetches the list of active projects from CORA to populate the frontend dropdown.
    """
    try:
        secrets = load_secrets()
        
        # Check standard credential paths
        cora_auth = secrets.get("cora_dev")
        if not cora_auth: cora_auth = secrets.get("cora_prod")
        if not cora_auth: cora_auth = secrets.get("cora")
        
        if not cora_auth:
            return []

        # Login and Fetch
        token_url = f"{cora_auth['base_url'].rstrip('/')}/cora/api/v1/auth/login"
        proj_url = f"{cora_auth['base_url'].rstrip('/')}/cora/api/v1/projects/"
        
        sess = requests.Session()
        
        # Try JSON login first (standard)
        try:
            r = sess.post(token_url, json={"username": cora_auth["username"], "password": cora_auth["password"]})
            # Fallback to Form Data if JSON fails (OAuth style)
            if r.status_code >= 400:
                r = sess.post(token_url, data={"username": cora_auth["username"], "password": cora_auth["password"]})
            r.raise_for_status()
            token = r.json().get("access_token")
        except Exception:
            return []

        # Fetch Projects
        r_proj = sess.get(proj_url, headers={"Authorization": f"Bearer {token}"})
        if r_proj.status_code == 200:
            data = r_proj.json()
            # Handle standard CORA pagination wrapper { data: [...], total: ... }
            items = data.get("data", []) if isinstance(data.get("data"), list) else data
            
            # Return simplified list for Frontend
            return [
                {"id": p.get("id") or p.get("project_id"), "name": p.get("project_name") or p.get("name")} 
                for p in items
            ]
        return []
    except Exception as e:
        logger.error(f"List Projects Failed: {e}")
        return []


# --- Existing Endpoint: Initialize Project ---
@router.post("/init", response_model=ProjectInitResponse)
def initialize_project(req: ProjectInitRequest):
    logger.info(f"🚀 Initializing Project: {req.name} with {len(req.celex_ids)} CELEX IDs")

    # 1. Resolve Documents
    mongo_ok, mongo_msg = is_mongo_available()
    if not mongo_ok:
        raise HTTPException(status_code=503, detail=f"MongoDB is not available: {mongo_msg}")
    docs, missing = resolve_celex(req.celex_ids)
    if not docs:
        raise HTTPException(status_code=404, detail=f"No valid documents found in Mongo. Missing: {missing}")

    # 2. Load Secrets & Find Credentials
    secrets = load_secrets()
    if not secrets:
        raise HTTPException(status_code=500, detail="secrets.json file not found.")

    logger.info(f"   🔑 Secrets keys found: {list(secrets.keys())}")

    # Priority 1: Check for 'cora_dev' object (Standard format)
    cora_auth = secrets.get("cora_dev")
    if not cora_auth:
        cora_auth = secrets.get("cora_prod") # Fallback to prod
    if not cora_auth:
        cora_auth = secrets.get("cora")      # Fallback to generic

    base_url = None
    username = None
    password = None

    if cora_auth and isinstance(cora_auth, dict):
        base_url = cora_auth.get("base_url")
        username = cora_auth.get("username")
        password = cora_auth.get("password")
    else:
        # Priority 2: Check for flat keys (Legacy format)
        base_url = secrets.get("cora_base_url")
        username = secrets.get("cora_user")
        password = secrets.get("cora_pass")

    if not (base_url and username and password):
        logger.error("❌ CORA credentials missing from secrets structure.")
        raise HTTPException(status_code=500, detail="CORA credentials missing. Ensure 'cora_dev' (with base_url/username/password) exists in secrets.json")

    # 3. Connect & Create
    try:
        harness = CoraHarness(base_url, username, password)
        
        timestamp = datetime.datetime.now().strftime("%d%H%M")
        project_name = f"{req.name}_{timestamp}"
        
        proj_data = harness.create_project(name=project_name, description=req.description)
        
        p_id = None
        if isinstance(proj_data, dict):
            p_id = proj_data.get("project_id") or proj_data.get("id")
            if not p_id and "data" in proj_data:
                p_id = proj_data["data"].get("project_id") or proj_data["data"].get("id")

        if not p_id:
             raise HTTPException(status_code=500, detail=f"Project created but ID missing: {proj_data}")

        harness.ensure_project_documents_attached(p_id, docs)
        
        return {
            "project_id": p_id,
            "project_name": project_name,
            "linked_documents": len(docs),
            "missing_celex": missing
        }

    except Exception as e:
        logger.error(f"Project Creation Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))