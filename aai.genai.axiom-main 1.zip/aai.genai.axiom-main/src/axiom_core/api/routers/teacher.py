# Layer 1: Teacher – question set generation (uses TeacherService)
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import json
from datetime import datetime
from typing import List, Dict, Any, Optional

from src.axiom_core.api.dependencies import (
    DOMAIN_PROFILES,
    LLM_PROFILES,
    mongo,
    load_api_keys,
    TEACHER_DIR,
)
from src.axiom_core.layer1_teacher.brains import OpenSourceTeacher, PremiumTeacher
from src.axiom_core.services.teacher_service import TeacherService

router = APIRouter()


class GenerationRequest(BaseModel):
    domain: str
    persona: str
    technique: str
    context: str
    count: int = 10
    source_metadata: Dict[str, Any] = {}
    exam_type: str = "static"
    models: List[str]


class SimpleGenerateRequest(BaseModel):
    prompt: str
    model_id: str
    system_prompt: Optional[str] = "You are a helpful AI assistant."
    temperature: Optional[float] = 0.7


@router.post("/generate")
def generate_questions(req: GenerationRequest):
    """Validate request → call TeacherService → return response."""
    try:
        artifact_dict, filename = TeacherService.run_generation(
            domain=req.domain,
            persona=req.persona,
            technique=req.technique,
            context=req.context,
            count=req.count,
            source_metadata=req.source_metadata,
            models=req.models,
        )
        turns = artifact_dict.get("question_set", {}).get("turns", [])
        return {"status": "Success", "filename": filename, "data": turns}
    except RuntimeError as e:
        if "MongoDB" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/chat")
def generate_simple_text(req: SimpleGenerateRequest):
    try:
        profiles = LLM_PROFILES.get("profiles", {})
        selected_profile = profiles.get(req.model_id, {})
        provider = selected_profile.get("provider", "local")
        model_name = selected_profile.get("model_name", req.model_id)
        if provider in ("openai", "anthropic", "azure", "google"):
            keys = load_api_keys()
            secret_key_name = selected_profile.get("api_key_env", provider)
            api_key = keys.get(secret_key_name) or keys.get(provider)
            if not api_key:
                raise HTTPException(status_code=400, detail=f"Missing API key for {provider}")
            brain = PremiumTeacher(api_key=api_key, model_name=model_name)
        else:
            brain = OpenSourceTeacher(model_name=model_name)
        return {"response": brain.generate(req.prompt)}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/artifacts")
def list_teacher_artifacts():
    if not os.path.exists(TEACHER_DIR):
        return []
    results = []
    for root, _, files in os.walk(TEACHER_DIR):
        for f in files:
            if f.endswith(".json") and f.startswith("Teacher_"):
                path = os.path.join(root, f)
                raw_ts = os.path.getmtime(path)
                iso_ts = datetime.fromtimestamp(raw_ts).isoformat()
                results.append({"filename": f, "mode": os.path.basename(root), "created_at": iso_ts})
    return sorted(results, key=lambda x: x["created_at"], reverse=True)
