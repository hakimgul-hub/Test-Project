from fastapi import APIRouter, UploadFile, File, HTTPException
import os
import json
import io
import shutil
import uuid
import requests
from pydantic import BaseModel
from pypdf import PdfReader

# --- ABSOLUTE IMPORTS (Phase 6) ---
from src.axiom_core.api.dependencies import (
    CONFIG_DIR,
    DATA_DIR,
    TEACHER_DIR,
    EXAMINER_DIR,
    JUDGE_DIR,
    _scan_artifact_dir,
    load_api_keys,
    save_api_keys,
    LAYER1_CONF,
    LLM_PROFILES,
    DOMAIN_PROFILES,
    TEACHER_REST_CONF,
    mongo,
)
from src.axiom_core.api.models import KeyUpdate

import logging
logger = logging.getLogger("AxiomCore.System")
router = APIRouter()

class ActiveModelRequest(BaseModel):
    model_id: str

@router.post("/config/active_model")
def set_active_model(req: ActiveModelRequest):
    """Updates the active_profile in llm_profiles.json"""
    config_path = os.path.join(CONFIG_DIR, "llm_profiles.json")
    if not os.path.exists(config_path):
        raise HTTPException(404, "Config file not found")
    try:
        with open(config_path, 'r') as f: data = json.load(f)
        if req.model_id not in data.get("profiles", {}):
            raise HTTPException(400, "Invalid model ID")
        data["active_profile"] = req.model_id
        with open(config_path, 'w') as f: json.dump(data, f, indent=2)
        return {"status": "success", "active_profile": req.model_id}
    except Exception as e:
        raise HTTPException(500, str(e))
    
# ==========================================
# 1️⃣ SYSTEM SETTINGS & API KEYS
# ==========================================

@router.get("/settings/status")
def get_status():
    k = load_api_keys()
    return {
        "openai": bool(k.get("openai")), 
        "anthropic": bool(k.get("anthropic")), 
        "gemini": bool(k.get("gemini")), 
        "local": True, 
        "cora": True,   
        "mongo": mongo.enabled   
    }

@router.post("/settings/key")
def update_key(req: KeyUpdate):
    k = load_api_keys()
    k[req.provider] = req.key
    save_api_keys(k)
    return {"status": "Updated"}


# ==========================================
# 2️⃣ DYNAMIC CONFIGURATION
# ==========================================

def _ollama_models_available(base_url: str, timeout: int = 3) -> list:
    """Fetch list of model names available in Ollama (e.g. ['llama3:latest', 'deepseek-r1:14b'])."""
    try:
        url = base_url.rstrip("/") + "/api/tags"
        r = requests.get(url, timeout=timeout)
        if r.status_code != 200:
            return []
        data = r.json()
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except Exception:
        return []


def _model_name_matches(machine_name: str, wanted: str) -> bool:
    """Ollama tags can be 'llama3:latest'; config has 'llama3'. Match if tag equals or starts with wanted."""
    if not wanted:
        return False
    return machine_name == wanted or machine_name.startswith(wanted + ":")


@router.get("/config/active_model")
def get_active_model():
    """Returns the current active LLM profile id from llm_profiles.json."""
    config_path = os.path.join(CONFIG_DIR, "llm_profiles.json")
    if not os.path.exists(config_path):
        return {"active_profile": None}
    try:
        with open(config_path, "r") as f:
            data = json.load(f)
        return {"active_profile": data.get("active_profile")}
    except Exception:
        return {"active_profile": None}


@router.get("/config/layer1")
def get_l1_config():
    strategies = []
    if isinstance(DOMAIN_PROFILES, dict):
        for key, val in DOMAIN_PROFILES.items():
            if isinstance(val, dict): strategies.append({"id": key, "name": val.get("name", key)})
            else: strategies.append({"id": key, "name": str(key)})
    
    personas = []
    p_conf = LAYER1_CONF.get("personas", {})
    if isinstance(p_conf, dict):
        for key, val in p_conf.items():
            if isinstance(val, dict):
                desc = val.get("description", "")
                personas.append({"id": key, "name": f"{key} - {desc}" if desc else key})
            else: personas.append({"id": key, "name": key})

    return {
        "strategies": strategies,
        "personas": personas,
        "modes": LAYER1_CONF.get("modes", {}),
        "rest_config": TEACHER_REST_CONF 
    }

@router.get("/config/llms")
def get_llm_profiles():
    """
    Returns LLM profiles with a 'status' field per profile:
    - available: model/service is configured and reachable (Ollama model pulled, or cloud API key set).
    - not_configured: Ollama model not pulled, or cloud API key missing.
    - unavailable: Ollama not running or unreachable.
    """
    api_keys = load_api_keys()
    raw_profiles = LLM_PROFILES.get("profiles", {}) if isinstance(LLM_PROFILES, dict) else {}
    ollama_models = None  # cache per request: base_url -> list of model names

    profiles = []
    for key, val in raw_profiles.items():
        if not isinstance(val, dict):
            continue
        provider = (val.get("provider") or "local").lower()
        status = "not_configured"

        if provider in ("ollama", "local"):
            base_url = (val.get("base_url") or "http://localhost:11434").rstrip("/")
            model_name = val.get("model_name") or ""
            if ollama_models is None:
                ollama_models = {}
            if base_url not in ollama_models:
                ollama_models[base_url] = _ollama_models_available(base_url)
            available_names = ollama_models[base_url]
            if not available_names:
                status = "unavailable"  # Ollama not running or unreachable
            elif any(_model_name_matches(name, model_name) for name in available_names):
                status = "available"
            # else: not_configured (model not pulled)
        else:
            # Cloud: openai, anthropic, gemini (Settings tab uses keys openai, anthropic, gemini)
            env_key = (val.get("api_key_env") or "").strip()
            settings_key = {"openai": "openai", "anthropic": "anthropic", "anthropic_api_key": "anthropic",
                            "gemini": "gemini", "gemini_api_key": "gemini"}.get(env_key.lower(), env_key.lower())
            has_key = bool(
                api_keys.get(settings_key) or
                api_keys.get(env_key) or
                api_keys.get(env_key.lower()) or
                os.environ.get(env_key)
            )
            status = "available" if has_key else "not_configured"

        profiles.append({
            "id": key,
            "name": val.get("display_name", key),
            "provider": provider,
            "description": val.get("description", ""),
            "parameters": val.get("parameters", "Unknown"),
            "always": val.get("provider") in ["ollama", "local"],
            "status": status,
        })

    if not profiles:
        profiles = [
            {
                "id": "local_deepseek",
                "name": "DeepSeek (Fallback)",
                "provider": "ollama",
                "description": "System fallback",
                "parameters": "Unknown",
                "always": True,
                "status": "not_configured",
            }
        ]
    return profiles


# ==========================================
# 3️⃣ DATA & LIBRARY MANAGEMENT (SAFE)
# ==========================================

@router.get("/library/search")
def search(q: str):
    """Searches MongoDB safely."""
    if not mongo.enabled:
        raise HTTPException(503, "MongoDB is not available. Set MONGO_URI in .env and ensure the database is reachable.")
    results = mongo.search(q)
    for r in results:
        if r.get("id") is None: r["id"] = ""
        if r.get("title") is None: r["title"] = "Untitled"
    return results

@router.get("/library/{id}")
def get_doc(id: str):
    """Fetches full doc from MongoDB."""
    if not mongo.enabled:
        raise HTTPException(503, "MongoDB is not available. Set MONGO_URI in .env and ensure the database is reachable.")
    doc = mongo.get_doc(id)
    if not doc or doc.get("title") == "Error":
        raise HTTPException(404, "Document not found or MongoDB returned an error.")
    return doc

@router.get("/artifacts")
def list_l1():
    """List Teacher artifacts from data/Teacher/ (recursive), newest first."""
    return _scan_artifact_dir(TEACHER_DIR, "Teacher_")

# Examiner/Interrogator write as cora_* or Viva_* (thread names), not "Examiner_"
EXAMINER_FILE_PREFIXES = ("cora_", "Viva_")

@router.get("/transcripts")
def list_l2():
    """List Examiner artifacts from data/Examiner/ (recursive), newest first. Only cora_* and Viva_* JSON."""
    return _scan_artifact_dir(EXAMINER_DIR, EXAMINER_FILE_PREFIXES)

@router.get("/evaluations")
def list_l3():
    """List Judge reports from data/Judge/ (recursive), newest first."""
    return _scan_artifact_dir(JUDGE_DIR, "Judge_")

@router.post("/upload")
async def upload_doc(file: UploadFile = File(...)):
    """
    Handles uploads:
    1. Saves file to disk (for Examiner/CORA upload).
    2. Extracts text (for Teacher UI preview).
    """
    try:
        # 1. Save to Disk
        temp_dir = os.path.join(DATA_DIR, "temp_uploads")
        os.makedirs(temp_dir, exist_ok=True)
        file_path = os.path.join(temp_dir, f"{uuid.uuid4()}_{file.filename}")
        
        # Read content once into memory
        content = await file.read()
        
        with open(file_path, "wb") as buffer:
            buffer.write(content)

        # 2. Extract Text
        text = ""
        if file.filename.lower().endswith(".pdf"):
            try:
                reader = PdfReader(io.BytesIO(content))
                text = "".join([page.extract_text() for page in reader.pages])
            except Exception as e:
                text = f"[PDF Parse Error: {e}]"
        else:
            try:
                text = content.decode('utf-8')
            except:
                text = "[Binary or Non-UTF8 Content]"

        return {
            "filename": file.filename, 
            "path": file_path, # Examiner needs this!
            "text": text       # UI needs this!
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload Error: {str(e)}")