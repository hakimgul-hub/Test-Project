# Layer 2: Examiner – batch run against CORA (uses ExaminerService; fail-fast if SDK missing)
from fastapi import APIRouter, BackgroundTasks, HTTPException, Query
from pydantic import BaseModel
import os
import json
import uuid
import datetime
from typing import Dict, Optional, List

from src.axiom_core.api.dependencies import TEACHER_DIR, EXAMINER_DIR
from src.axiom_core.services.examiner_service import ExaminerService, is_sdk_available
import logging

router = APIRouter()
logger = logging.getLogger("AxiomCore.Examiner")

# UI mode (e.g. single_doc) -> Teacher folder name for /artifacts
TEACHER_MODE_FOLDER = {"single_doc": "SingleDoc", "discovery": "Discovery", "project": "Project", "user_doc": "UserDoc"}
# UI mode -> Examiner folder name for /results
EXAMINER_MODE_FOLDER = {"single_doc": "Document", "discovery": "Discovery", "project": "PCT", "user_doc": "UserDoc"}


class ExaminerBatchRequest(BaseModel):
    l1_filename: str
    cora_config: Optional[Dict[str, str]] = None
    project_id: Optional[str] = None
    cora_model: str = "gpt-4o"


def _run_batch_task(run_id: str, req: ExaminerBatchRequest) -> None:
    """Background task: call service; catch and log errors (no 503 here, already checked)."""
    try:
        ExaminerService.run_batch(
            run_id=run_id,
            l1_filename=req.l1_filename,
            cora_config=req.cora_config,
            project_id=req.project_id,
            cora_model=req.cora_model,
        )
    except (FileNotFoundError, RuntimeError) as e:
        logger.exception("Examiner batch failed: %s", e)


@router.get("/artifacts")
def list_inputs(mode: Optional[str] = Query(None, description="Filter by use case: single_doc, discovery, project, user_doc")):
    root = TEACHER_DIR
    res = []
    allowed_folders = None
    if mode:
        folder = TEACHER_MODE_FOLDER.get((mode or "").strip().lower())
        if folder:
            allowed_folders = {folder}
    if os.path.exists(root):
        for r, _, files in os.walk(root):
            folder_name = os.path.basename(r)
            if allowed_folders and folder_name not in allowed_folders:
                continue
            for f in files:
                if f.startswith("Teacher_") or f == "Questions.json":
                    try:
                        mode_val = folder_name if folder_name in ("SingleDoc", "Project", "Discovery", "UserDoc") else "Discovery"
                        path = os.path.join(r, f)
                        with open(path, "r", encoding="utf-8") as fp:
                            data = json.load(fp)
                        q_c = 0
                        if "threads" in data:
                            for t in data["threads"]:
                                q_c += len(t.get("questions", []))
                        elif "question_set" in data:
                            q_c = len(data["question_set"].get("turns", []))
                        elif "data" in data:
                            q_c = len(data["data"])
                        res.append({
                            "filename": f,
                            "mode": mode_val,
                            "question_count": q_c,
                            "created_at": datetime.datetime.fromtimestamp(os.path.getmtime(path)).isoformat(),
                            "relative_path": os.path.relpath(path, root).replace("\\", "/"),
                        })
                    except Exception:
                        pass
    return sorted(res, key=lambda x: str(x.get("created_at") or ""), reverse=True)


@router.get("/results")
def list_outputs(mode: Optional[str] = Query(None, description="Filter by use case: single_doc, discovery, project, user_doc")):
    root = EXAMINER_DIR
    res = []
    allowed_folders = None
    if mode:
        folder = EXAMINER_MODE_FOLDER.get((mode or "").strip().lower())
        if folder:
            allowed_folders = {folder}
    if os.path.exists(root):
        for r, _, files in os.walk(root):
            folder_name = os.path.basename(r)
            if allowed_folders and folder_name not in allowed_folders:
                continue
            for f in files:
                if f.endswith(".json"):
                    try:
                        path = os.path.join(r, f)
                        with open(path, "r", encoding="utf-8") as fp:
                            data = json.load(fp)
                        rel = os.path.relpath(path, root).replace("\\", "/")
                        res.append({
                            "filename": f,
                            "mode": data.get("mode", "unknown"),
                            "created_at": data.get("created_at"),
                            "path": path,
                            "relative_path": rel,
                            "folder": folder_name,
                        })
                    except Exception:
                        pass
    return sorted(res, key=lambda x: str(x.get("created_at") or ""), reverse=True)


@router.post("/run_batch")
def run_batch(req: ExaminerBatchRequest, bg_tasks: BackgroundTasks):
    if not is_sdk_available():
        raise HTTPException(
            status_code=503,
            detail="CORA SDK not available or misconfigured. Install layer2_harness and ensure CORA dependencies are available.",
        )
    run_id = str(uuid.uuid4())
    bg_tasks.add_task(_run_batch_task, run_id, req)
    return {"status": "Started", "run_id": run_id}
