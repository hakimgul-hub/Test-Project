from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class KeyUpdate(BaseModel):
    provider: str
    key: str

# LAYER 1: TEACHER
class GenerationRequest(BaseModel):
    domain: str
    persona: str
    technique: str
    context: str
    count: int
    source_metadata: dict = {}
    exam_type: str = "static"
    # UPDATED: Now accepts a list of model IDs (e.g. ["local_llama3", "local_mistral"])
    models: List[str] = ["local_llama3"]


# LAYER 2: EXAMINER
class ExamRequest(BaseModel):
    mode: str  # "questions" or "interview"
    filename: Optional[str] = None
    objective: Optional[str] = None
    source_context: Optional[str] = None
    candidates: List[str]
    max_turns: int = 5  # 1-50 slider support

# LAYER 2A: INTERROGATOR
class VivaStartRequest(BaseModel):
    objective: str
    mode: str 
    target_id: str = "" 
    judge_provider: str = "local:llama3:latest"

class VivaTurnRequest(BaseModel):
    session_id: str
    turn_index: int
    history: List[Dict[str, str]] 
    judge_provider: str
    mode: str
    target_id: str

# LAYER 3: JUDGE
# Note: Judge router uses JudgeRunRequest (candidate_file, teacher_file, model_name) in judge.py.
# EvaluationRequest below is legacy; prefer JudgeRunRequest for POST /judge/run.
class EvaluationRequest(BaseModel):
    transcript_file: str
    judge_model: str = "llama3:latest"
