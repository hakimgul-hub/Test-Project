from fastapi import FastAPI, Query
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging
import os
import uvicorn
import requests

# Configure logging first (before any imports that log, e.g. dependencies / MongoHelper)
from src.axiom_core.log_config import configure_logging
configure_logging()
logger = logging.getLogger("AxiomCore")

# 1. ABSOLUTE IMPORTS (after logging so early logs from dependencies show)
from src.axiom_core.api.routers import (
    system,
    teacher,
    examiner,
    interrogator,
    judge,
    projects_examiner,
)

# --- SINGLE VERSION SOURCE ---
__version__ = "1.0"

# --- LIFESPAN (Startup/Shutdown Events) ---
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 AXIOM Core %s Starting...", __version__)
    yield
    logger.info("🛑 AXIOM Core Shutting Down...")

# --- APP INITIALIZATION ---
app = FastAPI(title="AXIOM Core API", version=__version__, lifespan=lifespan)

# --- CORS CONFIGURATION ---
import os as _os
_cors_origins = _os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:8501,http://127.0.0.1:5173,http://127.0.0.1:8501").strip().split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- ROUTER REGISTRATION ---

# 1. System & Config (Mounts at Root)
app.include_router(system.router)

# 2. Layer 1: Teacher (Mounts at Root)
# ✅ FIX: Removed 'prefix="/teacher"' so "/generate" works at the root level
app.include_router(teacher.router, tags=["Layer 1: Teacher"])

# 3. Layer 2: Examiner (Mounts at /examiner)
app.include_router(examiner.router, prefix="/examiner", tags=["Layer 2: Examiner"])

# 4. Layer 2a: Interrogator (Mounts at /interrogator)
app.include_router(interrogator.router, prefix="/interrogator", tags=["Layer 2a: Interrogator"])

# 5. Layer 3: Judge (Mounts at /judge)
app.include_router(judge.router, prefix="/judge", tags=["Layer 3: Judge"])

# 6. Projects (project init / CELEX linking; mounts at /projects)
app.include_router(projects_examiner.router, tags=["Projects"])

# --- 📸 IMAGE PROXY (allowlist for SSRF safety) ---
_PROXY_ALLOWED_HOSTS = ("storage.googleapis.com", "storage.cloud.google.com", "www.gstatic.com")

@app.get("/proxy/image")
def proxy_image(url: str = Query(..., description="The full GCS URL to fetch")):
    """
    Fetches an external image (e.g. from Google Cloud) and serves it back
    to the frontend to bypass CORS. Only https URLs to allowed hosts are permitted.
    """
    try:
        if not url.startswith("https://"):
            return Response(status_code=400)
        from urllib.parse import urlparse
        parsed = urlparse(url)
        if parsed.hostname not in _PROXY_ALLOWED_HOSTS:
            return Response(status_code=400)
        resp = requests.get(url, stream=True, timeout=10)
        if resp.status_code != 200:
            return Response(status_code=404)
        content_type = resp.headers.get("Content-Type", "image/jpeg")
        return Response(content=resp.content, media_type=content_type)
    except Exception as e:
        logger.exception("Proxy error for %s: %s", url, e)
        return Response(status_code=404)

# --- HEALTH CHECK ---
@app.get("/")
def health_check():
    return {
        "status": "AXIOM Core Online",
        "version": __version__,
        "modules": ["Teacher", "Examiner", "Interrogator", "Judge", "ImageProxy"],
        "endpoints": {
            "teacher": "/generate",
            "judge": "/judge/run",
            "examiner": "/examiner/run_batch",
            "proxy": "/proxy/image"
        }
    }

if __name__ == "__main__":
    uvicorn.run("src.axiom_core.api.main:app", host="0.0.0.0", port=8000, reload=True)