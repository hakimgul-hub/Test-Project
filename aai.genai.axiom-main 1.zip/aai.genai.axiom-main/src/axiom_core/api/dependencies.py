import os
import json
import warnings
import logging
import uuid
from datetime import datetime

# Load .env from repo root first so MONGO_URI etc. are set before any config reads them
try:
    from dotenv import load_dotenv
    _repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../.."))
    load_dotenv(os.path.join(_repo_root, ".env"))
except Exception:
    pass  # .env optional; logger not yet configured

# Suppress warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

# SDK Imports
try: import openai
except ImportError: openai = None
try: import anthropic
except ImportError: anthropic = None
try: import google.generativeai as genai
except ImportError: genai = None
try: 
    from pymongo import MongoClient
    from bson import ObjectId, Binary
except ImportError: 
    MongoClient = None
    ObjectId = None
    Binary = None

from src.axiom_core.layer1_teacher.brains import OpenSourceTeacher
from src.axiom_core.layer2_harness.adapters import CoraHarness

logger = logging.getLogger("AxiomCore.Dependencies")

# --- ROBUST PATH SETUP ---
CURRENT_FILE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.abspath(os.path.join(CURRENT_FILE_DIR, "../.."))
PROJECT_ROOT = os.path.abspath(os.path.join(SRC_DIR, ".."))
CONFIG_DIR = os.path.join(SRC_DIR, "config")

if os.path.exists(os.path.join(PROJECT_ROOT, "Data")):
    DATA_DIR = os.path.join(PROJECT_ROOT, "Data")
else:
    DATA_DIR = os.path.join(PROJECT_ROOT, "data")

# Layer artifact directories (single source for API listing)
TEACHER_DIR = os.path.join(DATA_DIR, "Teacher")
EXAMINER_DIR = os.path.join(DATA_DIR, "Examiner")
JUDGE_DIR = os.path.join(DATA_DIR, "Judge")
VIVA_DIR = os.path.join(DATA_DIR, "Viva")  # Streamlit L2A (Interrogator/Viva)

# Config assets (logos etc.) for Judge/PDF
CONFIG_ASSETS_DIR = os.path.join(SRC_DIR, "config", "assets")

if os.path.exists(os.path.join(DATA_DIR, "Examiner")):
    ARTIFACT_DIR = os.path.join(DATA_DIR, "Examiner")
else:
    ARTIFACT_DIR = os.path.join(PROJECT_ROOT, "test_artifacts")

def get_secrets_path() -> str:
    """Single source for secrets.json path. Tries CONFIG_DIR then PROJECT_ROOT/config."""
    candidates = [
        os.path.join(CONFIG_DIR, "secrets.json"),
        os.path.join(PROJECT_ROOT, "config", "secrets.json"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0]


def get_config_path(filename: str) -> str:
    """Path for a config file under CONFIG_DIR (e.g. llm_profiles.json)."""
    return os.path.join(CONFIG_DIR, filename)


SECRETS_FILE = get_secrets_path()

if not os.path.exists(ARTIFACT_DIR): os.makedirs(ARTIFACT_DIR, exist_ok=True)
if not os.path.exists(DATA_DIR): os.makedirs(DATA_DIR, exist_ok=True)

# --- HELPER: Safe ID Converter ---
def safe_str_id(value):
    if value is None: return ""
    if isinstance(value, str): return value
    if ObjectId and isinstance(value, ObjectId): return str(value)
    if isinstance(value, bytes): return value.hex()
    if isinstance(value, uuid.UUID): return str(value)
    return str(value)

# --- PATH MANAGER ---
# Canonical mode -> folder name for Examiner, Judge, Teacher (align UI dropdowns)
EXAMINER_MODE_FOLDERS = {"discovery": "Discovery", "pct": "PCT", "document": "Document", "user_document": "UserDoc"}
JUDGE_MODE_FOLDERS = {"discovery": "Discovery", "pct": "PCT", "single_doc": "SingleDoc", "document": "Document", "user_doc": "UserDoc", "user_document": "UserDoc", "project": "Project"}

def get_data_path(layer: str, mode: str) -> str:
    mode_map = {
        "discovery": "Discovery", "single_doc": "SingleDoc",
        "singledoc": "SingleDoc", "project": "Project", "user_doc": "UserDoc",
        "user_document": "UserDoc", "pct": "PCT", "document": "Document",
    }
    clean_mode = mode_map.get(mode.lower().strip(), "Misc")
    target_dir = os.path.join(DATA_DIR, layer.capitalize(), clean_mode)
    if not os.path.exists(target_dir):
        try: os.makedirs(target_dir, exist_ok=True)
        except: return ARTIFACT_DIR
    return target_dir

def generate_filename(layer: str, mode: str, ext="json") -> str:
    tag_map = {"discovery": "DISC", "single_doc": "SDOC", "project": "PROJ", "user_doc": "UDOC"}
    clean_mode = mode.lower().strip() if isinstance(mode, str) else "gen"
    tag = tag_map.get(clean_mode, "GEN")
    timestamp = datetime.now().strftime("%Y-%m-%d_%Hh%M")
    return f"{layer.capitalize()}_{tag}_{timestamp}.{ext}"


def _scan_artifact_dir(root_dir: str, prefix_filter=None) -> list:
    """Scan root_dir recursively for .json files; return relative paths sorted by mtime (newest first).
    prefix_filter: optional str (single prefix) or list of str (file must start with any of these).
    """
    if not os.path.isdir(root_dir):
        return []
    prefixes = None
    if prefix_filter is not None:
        prefixes = [prefix_filter] if isinstance(prefix_filter, str) else prefix_filter
    out = []
    for root, _, files in os.walk(root_dir):
        for f in files:
            if not f.endswith(".json"):
                continue
            if prefixes and not any(f.startswith(p) for p in prefixes):
                continue
            rel = os.path.relpath(os.path.join(root, f), root_dir)
            rel = rel.replace("\\", "/")
            out.append((rel, os.path.getmtime(os.path.join(root, f))))
    out.sort(key=lambda x: x[1], reverse=True)
    return [p for p, _ in out]

# --- CONFIG LOADER ---
def load_json_config(filename, default={}):
    path = os.path.join(CONFIG_DIR, filename)
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f: 
                return json.load(f) or default
    except: pass
    return default

# --- LOAD CONFIGS ---
SECRETS = {}
if os.path.exists(SECRETS_FILE):
    try: 
        with open(SECRETS_FILE, 'r') as f: 
            SECRETS = json.load(f)
    except: 
        pass

LAYER1_CONF = load_json_config("layer1_config.json")
LAYER2_CONF = load_json_config("layer2_config.json")
LAYER2A_CONF = load_json_config("layer2a_config.json")
DOMAIN_PROFILES = load_json_config("domain_profiles.json")
LLM_PROFILES = load_json_config("llm_profiles.json")
CORA_ANCHORS = load_json_config("cora_anchors.json")
MONGO_CONF = load_json_config("mongo_config.json")
TEACHER_REST_CONF = load_json_config("teacher_config_rest.json")

# --- UNIVERSAL BRAIN ---
class UniversalBrain:
    def __init__(self, provider="local", model="llama3", temperature=0.7):
        self.provider = provider
        self.model = model
        self.temperature = temperature
        self.local_brain = None
        if provider in ["local", "ollama"]:
            self.local_brain = OpenSourceTeacher(model_name=model)

    def generate(self, system_prompt, user_prompt):
        try:
            if self.provider in ["local", "ollama"] and self.local_brain:
                full_prompt = f"{system_prompt}\n\nUser Input: {user_prompt}"
                return self.local_brain.generate_response(full_prompt)
            if self.provider == "openai" and openai:
                client = openai.OpenAI(api_key=SECRETS.get("openai"))
                response = client.chat.completions.create(
                    model=self.model, messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}], temperature=self.temperature
                )
                return response.choices[0].message.content
            if self.provider == "anthropic" and anthropic:
                client = anthropic.Anthropic(api_key=SECRETS.get("anthropic"))
                response = client.messages.create(
                    model=self.model, max_tokens=4096, system=system_prompt, messages=[{"role": "user", "content": user_prompt}]
                )
                return response.content[0].text
            return "Error: Provider unavailable."
        except Exception as e: return f"Error generating response: {str(e)}"

# --- MONGODB HELPER ---
class MongoHelper:
    def __init__(self):
        self.client = None
        self.db = None
        self.collection = None
        self.enabled = False
        try:
            profile = MONGO_CONF.get("active_profile", "local")
            conf = MONGO_CONF.get("profiles", {}).get(profile, {})
            uri = (SECRETS.get("mongo_uri") or os.environ.get(conf.get("uri_env_var", "MONGO_URI")) or "").strip()
            # Only connect if a URI is explicitly set; do not default to localhost (avoids connection refused when MongoDB is optional)
            if not uri and MongoClient:
                pass  # leave enabled=False
            elif uri and MongoClient:
                try:
                    import certifi
                    _tls_kw = {"tlsCAFile": certifi.where()}
                except ImportError:
                    _tls_kw = {}
                self.client = MongoClient(uri, serverSelectionTimeoutMS=2000, **_tls_kw)
                try: self.db = self.client.get_default_database()
                except: self.db = self.client[conf.get("db_name", "corax-dev")]
                self.collection = self.db[conf.get("collection_name", "documents")]
                self.client.server_info()
                self.enabled = True
                logger.info("MongoDB connection active")
            else:
                logger.warning("PyMongo not installed")
        except Exception as e:
            logger.warning("MongoDB initialization error: %s", e)

    def search(self, query):
        if not self.enabled: return []
        try:
            regex = {"$regex": query, "$options": "i"}
            results = self.collection.find({"$or": [{"title": regex}, {"content": regex}, {"id": regex}]}).limit(10)
            return [{
                "id": safe_str_id(doc.get("id", doc.get("_id"))),
                "title": doc.get("title", "Untitled"),
                "version": doc.get("version", "1.0"),
                "content": doc.get("content", doc.get("text", ""))[:200]
            } for doc in results]
        except Exception as e: return []

    def _recursive_text_search(self, obj, depth=0):
        """Recursively finds the largest string in a nested object."""
        if depth > 5: return "" 
        best_text = ""
        
        if isinstance(obj, dict):
            for k, v in obj.items():
                if k in ["_id", "id", "date", "status", "type"]: continue
                found = self._recursive_text_search(v, depth+1)
                if len(found) > len(best_text):
                    best_text = found
        elif isinstance(obj, list):
            for item in obj:
                found = self._recursive_text_search(item, depth+1)
                if len(found) > len(best_text):
                    best_text = found
        elif isinstance(obj, str):
            if len(obj) > 50: return obj
        return best_text

    def _scavenge_text(self, doc, preferred_langs=["en", "eng", "english", "EN"]):
        """
        Intelligently hunts for text with strict language prioritization.
        Returns: (extracted_text, extraction_log)
        """
        logs = []
        
        # 1. Check Root Fields (No language variance usually)
        for key in ["text", "content", "body", "full_text", "page_content"]:
            if doc.get(key) and isinstance(doc[key], str) and len(doc[key]) > 50:
                 logs.append(f"✅ Found text in root key '{key}'")
                 return doc[key], logs

        # 2. CHECK CONSOLIDATED VERSIONS -> LANGUAGES (Strict Logic)
        if "consolidated_versions" in doc and isinstance(doc["consolidated_versions"], list):
            logs.append(f"🔎 Scanning {len(doc['consolidated_versions'])} consolidated versions.")
            versions_text = []
            
            for i, v in enumerate(doc["consolidated_versions"]):
                langs = v.get("languages", {})
                v_text = ""
                selected_lang = "None"
                
                # A. Try Preferred Languages
                for lang_key in preferred_langs:
                    if lang_key in langs:
                        selected_lang = lang_key
                        logs.append(f"   🔹 Version {i}: Found preferred language '{lang_key}'")
                        v_text = self._recursive_text_search(langs[lang_key])
                        break
                
                # B. Fallback to ANY language if preferred is missing
                if not v_text and langs:
                    # Get the first available key
                    fallback_lang = list(langs.keys())[0]
                    logs.append(f"   ⚠️ Version {i}: Preferred {preferred_langs} NOT FOUND. Available: {list(langs.keys())}. Falling back to '{fallback_lang}'.")
                    v_text = self._recursive_text_search(langs[fallback_lang])
                    selected_lang = fallback_lang

                if v_text:
                    v_date = v.get("date") or v.get("version_date") or f"Version {i+1}"
                    versions_text.append(f"--- VERSION: {v_date} [{selected_lang}] ---\n{v_text}")
                else:
                    logs.append(f"   ❌ Version {i}: No text found in language object.")

            if versions_text:
                return "\n\n".join(versions_text), logs

        # 3. Last Resort: Recursive Search
        logs.append("⚠️ Root/Versions empty. Attempting deep recursive search on doc...")
        fallback = self._recursive_text_search(doc)
        if fallback:
             logs.append(f"✅ Deep search found text ({len(fallback)} chars).")
             return fallback, logs

        logs.append("❌ All strategies failed.")
        return "", logs

    def get_doc(self, doc_id: str):
        if not self.enabled: return {"text": "MongoDB Unavailable", "title": "Error"}
        doc = None
        try:
            # 1. Exact String Match
            doc = self.collection.find_one({"id": doc_id}, {"_id": 0})
            
            # 2. UUID/Hex Handling
            if not doc and len(doc_id) == 32:
                try:
                    uuid_obj = uuid.UUID(doc_id)
                    formatted_str = str(uuid_obj)
                    doc = self.collection.find_one({"id": formatted_str}, {"_id": 0})
                    if not doc and Binary:
                        doc = self.collection.find_one({"_id": Binary.from_uuid(uuid_obj, uuid_representation=4)})
                        if not doc: doc = self.collection.find_one({"_id": Binary.from_uuid(uuid_obj, uuid_representation=3)})
                except: pass

            # 3. ObjectId Match
            if not doc and ObjectId and ObjectId.is_valid(doc_id):
                try: doc = self.collection.find_one({"_id": ObjectId(doc_id)})
                except: pass
            
            # 4. Fallback String on _id
            if not doc: doc = self.collection.find_one({"_id": doc_id})

            if doc:
                # 🚀 EXECUTE SCAVENGER WITH LOGGING
                raw_text, extraction_logs = self._scavenge_text(doc)
                
                # Print the logs for the user to see "WHY"
                for log_line in extraction_logs:
                    logger.debug("%s", log_line)

                # SCAVENGE FOR CHUNKS
                native_chunks = []
                if "chunks" in doc and isinstance(doc["chunks"], list):
                     for c in doc["chunks"]:
                         if isinstance(c, str): native_chunks.append(c)
                         elif isinstance(c, dict): native_chunks.append(c.get("text") or c.get("content") or "")

                # 🚨 RAW DUMP: Convert BSON types (like ObjectId/Binary) to string for JSON serialization
                def clean_for_json(obj):
                    if isinstance(obj, (ObjectId, uuid.UUID)): return str(obj)
                    if isinstance(obj, bytes): return obj.hex()
                    if isinstance(obj, dict): return {k: clean_for_json(v) for k, v in obj.items()}
                    if isinstance(obj, list): return [clean_for_json(i) for i in obj]
                    return obj
                
                raw_dump = clean_for_json(doc)

                return {
                    "id": safe_str_id(doc.get("id") or doc.get("_id")),
                    "title": doc.get("title", "Untitled Document"),
                    "text": raw_text,
                    "chunks": native_chunks,
                    "version": doc.get("version", "1.0"),
                    "extraction_logs": extraction_logs, # ✅ Save the "WHY"
                    "_raw": raw_dump, # ✅ Save the "WHOLE YAML"
                    
                    # Specific subsets for convenience
                    "document_meta": doc.get("document_meta", {}),
                    "source_info": doc.get("source_info", {}),
                    "consolidated_versions": doc.get("consolidated_versions", []) 
                }
            return {}
        except Exception as e: return {}

mongo = MongoHelper()
def load_api_keys(): return SECRETS
def save_api_keys(keys): global SECRETS; SECRETS = keys; json.dump(keys, open(SECRETS_FILE, 'w'))