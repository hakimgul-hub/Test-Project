"""
Teacher service: loads config, builds strategy, runs generator, builds artifact, saves to TEACHER_DIR.
Used by the Teacher router and by CLI entrypoints.
"""
import json
import logging
import math
import os
import re
import uuid
from datetime import datetime
from difflib import SequenceMatcher
from typing import Any, Dict, List, Tuple

from src.axiom_core.api.dependencies import (
    DOMAIN_PROFILES,
    LLM_PROFILES,
    TEACHER_DIR,
    load_api_keys,
    mongo,
)
from src.axiom_core.artifacts import TeacherOutput
from src.axiom_core.layer1_teacher.brains import OpenSourceTeacher, PremiumTeacher
from src.axiom_core.layer1_teacher.generator import GoldenDatasetGenerator
from src.axiom_core.layer1_teacher.strategies import (
    CoraAutomotiveStrategy,
    CoraLegalStrategy,
    CoraPharmaStrategy,
    Strategy,
)

logger = logging.getLogger("AxiomCore.TeacherService")


def _clean_text_for_llm(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"data:image\/[a-zA-Z]+;base64,[a-zA-Z0-9+/=]+", "[IMAGE BINARY REMOVED]", text)
    return text.strip()


def _enforce_context_limit(text: str, limit_str: str) -> str:
    if not limit_str or not isinstance(limit_str, str):
        return text
    match = re.search(r"(\d+)", limit_str)
    if not match:
        return text
    val = int(match.group(1))
    multiplier = 1000 if "k" in limit_str.lower() else (1000000 if "m" in limit_str.lower() else 1)
    token_limit = val * multiplier
    char_limit = int(token_limit * 4 * 0.90)
    if len(text) > char_limit:
        return text[:char_limit] + "\n...(truncated)..."
    return text


def _is_similar(q1: str, q2: str, threshold: float = 0.85) -> bool:
    return SequenceMatcher(None, q1.lower(), q2.lower()).ratio() > threshold


def _extract_and_clean_response(text_output: str) -> Tuple[str, str]:
    if not text_output:
        return "", ""
    thought = "N/A"
    think_match = re.search(r"<think>(.*?)</think>", text_output, flags=re.DOTALL)
    if think_match:
        thought = think_match.group(1).strip()
        text_output = re.sub(r"<think>.*?</think>", "", text_output, flags=re.DOTALL)
    match = re.search(r"```json(.*?)```", text_output, re.DOTALL)
    if match:
        text_output = match.group(1).strip()
    return text_output.strip(), thought


def _extract_rich_media(text: str) -> Dict[str, List[str]]:
    images = re.findall(r"!\[.*?\]\((.*?)\)", text, re.IGNORECASE)
    links = re.findall(r"(https?://[^\s]+)", text)
    citations = re.findall(r"\[(?:citation|cite):\s*(.*?)\]", text, re.IGNORECASE)
    flat_images = [img for group in images for img in group if img]
    return {"images": flat_images, "links": links, "citations": citations}


def _chunk_text(text: str, target_chunks: int) -> List[str]:
    if not text:
        return []
    text = text.replace("\r", "")
    if len(text) < 1000:
        return [text]
    paragraphs = [p for p in text.split("\n\n") if p.strip()]
    if len(paragraphs) <= target_chunks:
        return paragraphs
    chunk_size = math.ceil(len(paragraphs) / target_chunks)
    chunks = []
    for i in range(0, len(paragraphs), chunk_size):
        chunks.append("\n\n".join(paragraphs[i : i + chunk_size]))
    return chunks[:target_chunks]


def _filter_english_context(text: str) -> str:
    if "--- VERSION:" not in text:
        return text
    parts = re.split(r"(--- VERSION:.*---)", text)
    cleaned_text = []
    keep_next = False
    found_english = False
    for part in parts:
        if "--- VERSION:" in part:
            if "[EN]" in part.upper() or "[ENG]" in part.upper() or "ENGLISH" in part.upper():
                keep_next = True
                found_english = True
                cleaned_text.append(part)
            else:
                keep_next = False
        elif keep_next:
            cleaned_text.append(part)
    result = "".join(cleaned_text).strip()
    return result if found_english and result else text


class TracingBrainWrapper:
    def __init__(self, real_brain: Any):
        self.real_brain = real_brain
        self.last_thought = "N/A"

    def generate_response(self, prompt: str) -> str:
        if hasattr(self.real_brain, "generate_response"):
            raw = self.real_brain.generate_response(prompt)
        elif hasattr(self.real_brain, "generate"):
            raw = self.real_brain.generate(prompt)
        else:
            raw = str(self.real_brain(prompt))
        cleaned_json, thought = _extract_and_clean_response(raw)
        if thought != "N/A":
            self.last_thought = thought
        return cleaned_json

    def generate(self, prompt: str) -> str:
        return self.generate_response(prompt)


def _strategy_for_domain(domain: str) -> Strategy:
    """Map request domain to strategy (Phase 7)."""
    d = (domain or "").lower().strip()
    if "pharma" in d or "clinical" in d or "fda" in d:
        return CoraPharmaStrategy()
    if "legal" in d or "gdpr" in d or "eu" in d or "legis" in d:
        return CoraLegalStrategy()
    return CoraAutomotiveStrategy()


class TeacherService:
    """Orchestrates Teacher generation: config, strategy, generator, artifact, save."""

    @staticmethod
    def run_generation(
        domain: str,
        persona: str,
        technique: str,
        context: str,
        count: int,
        source_metadata: Dict[str, Any],
        models: List[str],
    ) -> Tuple[Dict[str, Any], str]:
        """
        Run full generation. Returns (artifact_dict for response, filename).
        Raises on error (e.g. MongoDB required but unavailable).
        """
        run_id = str(uuid.uuid4())
        logger.info("Teacher: Starting generation (run_id=%s, models=%s)", run_id[:8], models)

        merged_results: List[Dict[str, Any]] = []
        raw_ids = source_metadata.get("id")
        processed_ids: List[str] = []
        documents_meta_list: List[Dict[str, Any]] = []
        domain_profile = DOMAIN_PROFILES.get(domain, {"name": domain, "description": "Generic Domain"})

        if isinstance(raw_ids, list):
            processed_ids = raw_ids
        elif isinstance(raw_ids, str) and raw_ids not in ("N/A", "null", ""):
            processed_ids = [raw_ids]

        smart_chunks: List[Dict[str, str]] = []

        if processed_ids and not mongo.enabled:
            raise RuntimeError("MongoDB is not available. Document library is required; set MONGO_URI in .env.")

        if processed_ids:
            logger.info("Fetching context for %d documents", len(processed_ids))
            for d_id in processed_ids:
                try:
                    doc_data = mongo.get_doc(d_id)
                    if doc_data.get("id"):
                        raw_text = doc_data.get("text") or ""
                        safe_text = _clean_text_for_llm(raw_text)
                        clean_text = _filter_english_context(safe_text)
                        doc_meta = {
                            "id": doc_data["id"],
                            "title": doc_data.get("title", "Untitled"),
                            "version": doc_data.get("version", "1.0"),
                            "created_at": doc_data.get("created_at"),
                            "extraction_logs": doc_data.get("extraction_logs", []),
                            "content_preview": clean_text[:200],
                        }
                        documents_meta_list.append(doc_meta)
                        if clean_text:
                            smart_chunks.append({"text": clean_text, "source_doc": doc_meta["title"]})
                        elif doc_data.get("chunks"):
                            for c in doc_data["chunks"]:
                                smart_chunks.append({"text": _clean_text_for_llm(c), "source_doc": doc_meta["title"]})
                except Exception as e:
                    logger.warning("Error fetching doc %s: %s", d_id, e)

        if not smart_chunks and context:
            smart_chunks.append({"text": _clean_text_for_llm(context), "source_doc": "User Provided Context"})

        strategy = _strategy_for_domain(domain)
        strategy.domain_name = domain_profile.get("name", domain)

        final_processing_chunks: List[Dict[str, str]] = []
        if smart_chunks:
            for sc in smart_chunks:
                txt = sc["text"]
                if len(txt) > 8000:
                    sub_chunks = _chunk_text(txt, math.ceil(len(txt) / 8000))
                    for sub in sub_chunks:
                        final_processing_chunks.append({"text": sub, "source": sc["source_doc"]})
                else:
                    final_processing_chunks.append({"text": txt, "source": sc["source_doc"]})
        else:
            raw_splits = _chunk_text(_clean_text_for_llm(context), max(1, math.ceil(count / 3)))
            for r in raw_splits:
                final_processing_chunks.append({"text": r, "source": "Raw Input"})

        logger.info("Processing %d context units", len(final_processing_chunks))
        api_keys = load_api_keys()

        for model_key in models:
            logger.info("Running generator: %s", model_key)
            try:
                model_conf = LLM_PROFILES.get("profiles", {}).get(model_key)
                if not model_conf:
                    continue
                provider = model_conf.get("provider", "local")
                model_name = model_conf.get("model_name", "llama3")
                brain = None
                if provider in ("openai", "anthropic", "azure", "google", "gemini"):
                    secret_key_name = model_conf.get("api_key_env", provider)
                    api_key = api_keys.get(secret_key_name) or api_keys.get(provider) or os.getenv(secret_key_name)
                    if not api_key:
                        continue
                    brain = TracingBrainWrapper(PremiumTeacher(model_name=model_name, api_key=api_key))
                else:
                    brain = TracingBrainWrapper(OpenSourceTeacher(model_name=model_name))

                failures = 0
                max_failures = 3
                chunk_index = 0
                while True:
                    current_qs = len([x for x in merged_results if model_key in x.get("generator_model", "")])
                    if current_qs >= count or failures >= max_failures:
                        break
                    idx = chunk_index % len(final_processing_chunks)
                    current_chunk_obj = final_processing_chunks[idx]
                    current_text = current_chunk_obj["text"]
                    current_source = current_chunk_obj["source"]
                    needed = count - current_qs
                    ask_count = min(needed, 5)
                    safe_chunk = _enforce_context_limit(current_text, model_conf.get("context_window", "8k"))
                    persona_text = f"{persona}. CRITICAL: Include 'supporting_quote' proving your answer."
                    gen = GoldenDatasetGenerator(brain, strategy)
                    gen.inject_source_material(safe_chunk)
                    try:
                        logger.debug("Generating batch of %d using '%s...'", ask_count, current_source[:20])
                        raw = gen.create_exam(ask_count, persona=persona_text, technique=technique)
                        batch_added = 0
                        for item in raw.get("questions", []):
                            q_text = item.get("question", "")
                            if not any(_is_similar(ex["question"], q_text) for ex in merged_results):
                                media = _extract_rich_media(item.get("expected_answer", ""))
                                merged_results.append({
                                    "turn_id": str(uuid.uuid4()),
                                    "question": q_text,
                                    "expected_answer": item.get("expected_answer", "Refer to context."),
                                    "generator_model": model_key,
                                    "supporting_quote": item.get("supporting_quote", "N/A"),
                                    "citations": media["citations"],
                                    "image_path": media["images"][0] if media["images"] else None,
                                    "source_ref": {
                                        "document_title": current_source,
                                        "chunk_index": idx,
                                        "full_context_used": safe_chunk,
                                    },
                                    "llm_meta": {"reasoning_trace": brain.last_thought},
                                })
                                batch_added += 1
                        if batch_added == 0:
                            failures += 1
                        else:
                            failures = 0
                    except Exception as gen_e:
                        logger.warning("Generation warning: %s", gen_e)
                        failures += 1
                    chunk_index += 1
            except Exception as e:
                logger.exception("Model %s failed: %s", model_key, e)

        raw_mode = source_metadata.get("source_type", "Discovery").lower().replace(" ", "_")
        mode_map = {
            "single_doc": ("SingleDoc", "SDOC", "Single Document Audit"),
            "project": ("Project", "PROJ", "Project Thread Analysis"),
            "discovery": ("Discovery", "DISC", "Topic Research"),
            "user_doc": ("UserDoc", "UDOC", "User Document Audit"),
            "user_document": ("UserDoc", "UDOC", "User Document Audit"),
        }
        folder_name, prefix, human_readable_mode = mode_map.get(raw_mode, ("Discovery", "DISC", "General Analysis"))
        run_title = "General Audit"
        if "Single" in human_readable_mode:
            run_title = documents_meta_list[0]["title"] if documents_meta_list else "Unknown Document"
        elif "Project" in human_readable_mode:
            run_title = source_metadata.get("project_name", "Unnamed Project")
        elif "Discovery" in human_readable_mode:
            run_title = source_metadata.get("topic", "Topic Research")

        artifact_dict = {
            "run_id": run_id,
            "created_at": datetime.now().isoformat(),
            "teacher_configuration": {
                "mode": human_readable_mode,
                "model": models[0] if models else "Unknown",
                "document_title": run_title,
                "document_id": processed_ids[0] if processed_ids else None,
                "documents": documents_meta_list,
                "topic": source_metadata.get("topic"),
                "project_name": source_metadata.get("project_name"),
                "domain_profile": domain_profile,
            },
            "context_info": {
                "source_type": folder_name,
                "document_ids": processed_ids,
                "document_metadata": documents_meta_list,
            },
            "generation_stats": {"total_generated": len(merged_results), "end_time": datetime.now().isoformat()},
            "question_set": {"turns": merged_results},
        }

        timestamp = datetime.now().strftime("%Y-%m-%d_%Hh%M_%S")
        unique_suffix = run_id[:6]
        filename = f"Teacher_{prefix}_{timestamp}_{unique_suffix}.json"
        save_dir = os.path.join(TEACHER_DIR, folder_name)
        os.makedirs(save_dir, exist_ok=True)
        with open(os.path.join(save_dir, filename), "w", encoding="utf-8") as f:
            json.dump(artifact_dict, f, indent=2)

        logger.info("Teacher run saved: %s", filename)
        return artifact_dict, filename
