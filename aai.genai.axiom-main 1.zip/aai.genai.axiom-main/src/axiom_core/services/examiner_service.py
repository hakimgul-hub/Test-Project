"""
Examiner service: resolve Teacher file, configure SDK, run batch, hydrate, write to EXAMINER_DIR.
Used by the Examiner router and by CLI entrypoints.
"""
import json
import logging
import os
import time
from datetime import datetime
from typing import Any, Dict, Optional

import requests

from src.axiom_core.api.dependencies import EXAMINER_DIR, TEACHER_DIR, get_secrets_path, EXAMINER_MODE_FOLDERS

logger = logging.getLogger("AxiomCore.ExaminerService")

# SDK imports: fail at module load so router can return 503 (Phase 7)
try:
    from src.axiom_core.layer2_harness.cora_sdk.config import Config
    from src.axiom_core.layer2_harness.cora_sdk.auth import login
    from src.axiom_core.layer2_harness.cora_sdk.runner.spec import iter_run_units, normalize_custom_prompts
    from src.axiom_core.layer2_harness.cora_sdk.runner.modes import (
        run_discovery,
        run_pct,
        run_document,
        run_user_document,
    )
    from src.axiom_core.layer2_harness.cora_sdk.api.projects import (
        build_project_id_map,
        resolve_project_id_for_unit,
        create_project,
        ensure_project_documents_attached,
    )
    from src.axiom_core.layer2_harness.cora_sdk.api.openapi import fetch_openapi
    from src.axiom_core.layer2_harness.cora_sdk.api.grounding import resolve_grounding_sources_cached
    _SDK_AVAILABLE = True
except ImportError as e:
    logger.warning("CORA SDK not available: %s", e)
    _SDK_AVAILABLE = False
    Config = None  # type: ignore
    login = None  # type: ignore


def is_sdk_available() -> bool:
    return _SDK_AVAILABLE


def _inject_secrets_into_config(cfg: Any) -> None:
    path = get_secrets_path()
    creds: Dict[str, str] = {}
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
                if "cora_dev" in raw:
                    raw = raw["cora_dev"]
                elif "cora" in raw:
                    raw = raw["cora"]
                creds = {
                    "username": raw.get("username") or raw.get("cora_user"),
                    "password": raw.get("password") or raw.get("cora_pass"),
                    "base_url": raw.get("base_url") or raw.get("cora_base_url"),
                }
                logger.info("Loaded credentials from %s", os.path.basename(path))
        except Exception:
            pass
    if creds.get("username"):
        cfg.username = creds["username"]
    if creds.get("password"):
        cfg.password = creds["password"]
    base = creds.get("base_url", "")
    if base:
        base = base.rstrip("/")
        if base.endswith("/cora"):
            base = base[:-5]
        cfg.base_url = base


def _create_unique_run_project(sess: requests.Session, token: Optional[str], cfg: Any, run_id: str, mode: str) -> Optional[str]:
    date_str = datetime.now().strftime("%Y%m%d")
    mode_map = {"document": "SingleDoc", "user_document": "UserDoc", "discovery": "Discovery", "pct": "PCT"}
    mode_str = mode_map.get(mode.lower(), "PCT")
    rid_short = run_id[-6:] if len(run_id) > 6 else run_id
    unique_name = f"{date_str}_Exam_{mode_str}_{rid_short}"
    logger.info("Creating project: %s", unique_name)
    try:
        new_proj = create_project(sess, token, cfg, unique_name, f"Automated Run {run_id}")
        data = new_proj.get("data", new_proj)
        pid = data.get("project_id") or data.get("id")
        if pid:
            return pid
        logger.warning("Project created but ID missing: %s", list(new_proj.keys()))
        return None
    except Exception as e:
        logger.exception("Failed to create project: %s", e)
        return None


def _hydrate_missing_text(
    sess: requests.Session,
    token: Optional[str],
    cfg: Any,
    search_dir: str,
    run_id_marker: str,
    teacher_filename: Optional[str] = None,
) -> None:
    logger.info("Hydration: scanning %s for marker '%s'", search_dir, run_id_marker)
    found_files = []
    for root, _, files in os.walk(search_dir):
        for f in files:
            if f.endswith(".json") and run_id_marker in f:
                found_files.append(os.path.join(root, f))
    if not found_files:
        logger.info("No matching output files found to hydrate")
        return
    for filepath in found_files:
        try:
            modified = False
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            if teacher_filename and isinstance(data, dict):
                data["teacher_source"] = teacher_filename
                clean_name = teacher_filename.replace(".json", "")
                parts = clean_name.split("_")
                unique_id = parts[-1] if len(parts) > 1 else clean_name[-6:]
                if len(unique_id) < 6:
                    unique_id = clean_name[-6:]
                data["teacher_run_id"] = unique_id
                modified = True
            turns = data.get("turns") or data.get("results") or []
            if not turns and isinstance(data, list):
                turns = data
            ids_to_fetch: Dict[str, list] = {"library": [], "user": []}
            obj_map: Dict[tuple, list] = {}
            if turns:
                for item in turns:
                    raw_grounding = item.get("grounding_sources") or item.get("grounding") or []
                    raw_refs = item.get("references") or item.get("citations")
                    if not raw_refs:
                        raw_refs = (item.get("resp") or {}).get("references") or (item.get("resp") or {}).get("citations") or []
                    all_sources = list(raw_grounding) if isinstance(raw_grounding, list) else []
                    if isinstance(raw_refs, list):
                        all_sources.extend(raw_refs)
                    detailed_sources = item.get("grounding_sources_details") or []
                    details_map = {str(d.get("chunk_id") or d.get("id")): d for d in detailed_sources}
                    for source in all_sources:
                        if not isinstance(source, dict):
                            continue
                        doc_id = str(source.get("chunk_id") or source.get("id") or source.get("document_id") or "").strip()
                        if not doc_id:
                            continue
                        current_text = source.get("text") or source.get("text_content") or source.get("content")
                        if not current_text and doc_id in details_map:
                            d_src = details_map[doc_id]
                            current_text = d_src.get("text_content") or d_src.get("text")
                        if current_text and current_text != "" and current_text != "[DATA MISSING]":
                            continue
                        stype = str(source.get("source_type") or source.get("doc_type") or "library").strip().lower()
                        if stype not in ids_to_fetch:
                            ids_to_fetch[stype] = []
                        ids_to_fetch[stype].append(doc_id)
                        key = (stype, doc_id)
                        if key not in obj_map:
                            obj_map[key] = []
                        obj_map[key].append(source)
                count_needed = sum(len(v) for v in ids_to_fetch.values())
                if count_needed > 0:
                    try:
                        resolved = resolve_grounding_sources_cached(sess, token, cfg, ids_to_fetch)
                        for res in resolved:
                            rid = str(res.get("chunk_id") or res.get("id") or "").strip()
                            rtype = str(res.get("source_type") or "library").strip().lower()
                            text_content = res.get("text_content") or res.get("text") or res.get("content")
                            if rid and text_content:
                                for t in obj_map.get((rtype, rid), []):
                                    t["text"] = text_content
                                    t["document_id"] = rid
                                    if not t.get("document_name"):
                                        t["document_name"] = res.get("title") or res.get("document_title")
                                    modified = True
                    except Exception as e:
                        logger.warning("Hydration API call failed: %s", e)
            if modified:
                with open(filepath, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
                logger.info("Hydrated: %s", os.path.basename(filepath))
        except Exception as e:
            logger.exception("Error processing %s: %s", os.path.basename(filepath), e)


class ExaminerService:
    """Orchestrates Examiner batch run: resolve Teacher file, SDK config, run units, hydrate."""

    @staticmethod
    def run_batch(run_id: str, l1_filename: str, cora_config: Optional[Dict[str, str]] = None,
                  project_id: Optional[str] = None, cora_model: str = "gpt-4o") -> None:
        """
        Run batch: find Teacher file, init SDK, run units, hydrate. Writes to EXAMINER_DIR.
        Raises RuntimeError if SDK is not available or auth fails.
        """
        if not _SDK_AVAILABLE:
            raise RuntimeError("CORA SDK not available or misconfigured. Install layer2_harness dependencies.")
        l1_path = None
        for r, _, f in os.walk(TEACHER_DIR):
            if l1_filename in f:
                l1_path = os.path.join(r, l1_filename)
                break
        if not l1_path:
            logger.error("Input file not found: %s", l1_filename)
            raise FileNotFoundError(f"Teacher file not found: {l1_filename}")
        with open(l1_path, "r", encoding="utf-8") as f:
            spec_data = json.load(f)
        cfg = Config()
        _inject_secrets_into_config(cfg)
        cfg.timeout = 300
        # results_dir set per unit below to mode subfolder
        sess = requests.Session()
        token = login(sess, cfg)
        if not token and not sess.cookies:
            raise RuntimeError("CORA authentication failed. Check secrets.json.")
        logger.info("SDK authenticated")
        openapi = fetch_openapi(sess, token, cfg)
        openapi_version = openapi.get("info", {}).get("version", "unknown") if openapi else None
        project_id_map = {}
        try:
            project_id_map = build_project_id_map(sess, token, cfg, spec_data)
            if project_id_map:
                logger.info("Projects ready: %s", project_id_map)
        except Exception as e:
            logger.warning("Project setup failed (continuing): %s", e)
        global_custom_prompts = normalize_custom_prompts(spec_data.get("custom_prompts"), "spec.custom_prompts")
        units = iter_run_units(spec_data)
        clean_name = l1_filename.replace(".json", "")
        parts = clean_name.split("_")
        teacher_id_tag = parts[-1] if len(parts) > 1 else clean_name[-6:]
        if not units:
            raw_questions = spec_data.get("data") or spec_data.get("question_set", {}).get("turns")
            if isinstance(raw_questions, list) and raw_questions:
                logger.info("Detected flattened file with %d questions", len(raw_questions))
                fname_u = l1_filename.upper()
                mode = "discovery"
                if "PROJ" in fname_u:
                    mode = "pct"
                elif "SDOC" in fname_u:
                    mode = "document"
                elif "USER" in fname_u:
                    mode = "user_document"
                ctx = spec_data.get("context_info", {})
                doc_ids = ctx.get("document_ids", [])
                if isinstance(doc_ids, str):
                    doc_ids = [doc_ids]
                units = [{
                    "name": f"Auto_{mode}_{teacher_id_tag}",
                    "mode": mode,
                    "questions": raw_questions,
                    "document_id": doc_ids[0] if doc_ids else "",
                    "version_name": ctx.get("version_name", "Legal act"),
                    "project_id": project_id or ctx.get("project_id"),
                    "project_key": ctx.get("project_key"),
                    "documents_to_attach": doc_ids,
                }]
            else:
                logger.error("No questions found in spec")
                return
        for unit in units:
            u = unit if isinstance(unit, dict) else unit.__dict__
            name = u.get("name") or "Unnamed"
            mode = (u.get("mode") or "discovery").lower()
            # Write to mode-specific subfolder: Discovery, PCT, Document, UserDoc
            mode_folder = EXAMINER_MODE_FOLDERS.get(mode, "Discovery")
            unit_results_dir = os.path.join(EXAMINER_DIR, mode_folder)
            os.makedirs(unit_results_dir, exist_ok=True)
            cfg.results_dir = unit_results_dir
            clean_questions = [q.get("question") or str(q) if isinstance(q, dict) else str(q) for q in (u.get("questions") or [])]
            local_prompts = normalize_custom_prompts(u.get("custom_prompts"), "unit")
            final_prompts = {**global_custom_prompts, **local_prompts}
            pid = resolve_project_id_for_unit(u, project_id_map)
            if mode == "pct" and not pid:
                pid = _create_unique_run_project(sess, token, cfg, teacher_id_tag, mode)
                if pid:
                    docs_to_link = u.get("documents_to_attach") or spec_data.get("context_info", {}).get("document_ids", [])
                    if not docs_to_link and getattr(cfg, "project_context_thread_doc_id", None):
                        docs_to_link = [cfg.project_context_thread_doc_id]
                    attachments = [{"document_id": d, "document_type": "library", "version_name": u.get("version_name") or "Legal act", "language": "EN"} for d in docs_to_link if d]
                    if attachments:
                        try:
                            ensure_project_documents_attached(sess, token, cfg, pid, attachments)
                        except Exception as e:
                            logger.exception("Failed to attach documents: %s", e)
                            continue
            doc_id = u.get("document_id")
            if not doc_id:
                if mode == "discovery":
                    doc_id = getattr(cfg, "discovery_thread_doc_id", None)
                elif mode == "pct":
                    doc_id = getattr(cfg, "project_context_thread_doc_id", None)
            version_name = u.get("version_name") or "Legal act"
            logger.info("Running unit: %s [%s]", name, mode.upper())
            try:
                if mode == "discovery":
                    run_discovery(sess, token, cfg, name=name, questions=clean_questions, project_id=pid, custom_prompts=final_prompts, openapi=openapi, openapi_version=openapi_version)
                elif mode == "pct":
                    if not pid:
                        logger.warning("Skipping PCT unit: no project ID")
                        continue
                    run_pct(sess, token, cfg, name=name, questions=clean_questions, project_id=pid, custom_prompts=final_prompts, openapi=openapi, openapi_version=openapi_version)
                elif mode == "user_document":
                    run_user_document(sess, token, cfg, name=name, questions=clean_questions, document_id=doc_id, version_name=version_name, project_id=pid, custom_prompts=final_prompts, openapi=openapi, openapi_version=openapi_version)
                else:
                    run_document(sess, token, cfg, name=name, questions=clean_questions, document_id=doc_id, version_name=version_name, language="EN", project_id=pid, custom_prompts=final_prompts, openapi=openapi, openapi_version=openapi_version)
            except Exception as e:
                logger.exception("Unit failed: %s", e)
        time.sleep(1)
        _hydrate_missing_text(sess, token, cfg, EXAMINER_DIR, run_id[:4], teacher_filename=l1_filename)
        logger.info("Batch %s completed", run_id)
