"""
Profile-based LLM client: loads model profiles from llm_profiles.json and calls Ollama/OpenAI.
For direct provider/model usage, prefer axiom_core.llm.generate or LLMCaller.
"""
import os
import json
import requests
from pathlib import Path


def _default_config_path():
    """Resolve src/config relative to this package (axiom_core/llm -> src/config)."""
    here = Path(__file__).resolve().parent
    return here / ".." / ".." / "config"


class LLMClient:
    def __init__(self, config_path=None):
        self.config_path = Path(config_path) if config_path else _default_config_path()
        self.profiles = {}
        self.load_profiles()

    def load_profiles(self):
        """Loads the LLM Profiles from config."""
        try:
            path = self.config_path / "llm_profiles.json"
            with open(path, "r") as f:
                data = json.load(f)
                self.profiles = data.get("profiles", {})
        except Exception as e:
            print(f"LLMClient config error: {e}")

    def generate_completion(self, model_id, prompt, system_prompt="You are a helpful assistant."):
        profile = self.profiles.get(model_id)
        if not profile:
            return f"Error: Model profile '{model_id}' not found."
        provider = profile.get("provider", "ollama")
        if provider == "ollama":
            return self._call_ollama(profile, prompt, system_prompt)
        if provider == "openai":
            return self._call_openai(profile, prompt, system_prompt)
        return f"Error: Provider '{provider}' not implemented."

    def _call_ollama(self, profile, prompt, system_prompt):
        url = f"{profile['base_url']}/api/chat"
        payload = {
            "model": profile["model_name"],
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
            "stream": False,
            "options": {"temperature": 0.3},
        }
        try:
            res = requests.post(url, json=payload, timeout=120)
            if res.status_code == 200:
                return res.json().get("message", {}).get("content", "")
            return f"Ollama Error: {res.text}"
        except Exception as e:
            return f"Connection Error: {e}"

    def _call_openai(self, profile, prompt, system_prompt):
        api_key = os.getenv(profile.get("api_key_env", "OPENAI_API_KEY"))
        if not api_key:
            return "Error: Missing OpenAI API Key."
        return "OpenAI Placeholder Response"
