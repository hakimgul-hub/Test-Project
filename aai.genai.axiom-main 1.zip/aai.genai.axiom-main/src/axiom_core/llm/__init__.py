"""
Shared LLM client for Teacher, Judge, and Interrogator.
No dependency on api.dependencies to avoid circular imports.
Callers pass provider, model, base_url, api_key from their config.
"""
import os
import requests
from typing import Optional


def generate(
    prompt: str,
    *,
    system_prompt: str = "",
    provider: str = "ollama",
    model: str = "llama3",
    temperature: float = 0.7,
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
) -> str:
    """
    Call LLM and return the generated text.
    - provider: "ollama" | "openai" | "anthropic"
    - For ollama: base_url defaults to http://localhost:11434 (supports /api/generate).
    - For openai/anthropic: api_key is required (from caller).
    """
    if provider in ("ollama", "local"):
        base = (base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")).rstrip("/")
        # Ollama /api/generate expects a single prompt (we merge system + user)
        full_prompt = f"{system_prompt}\n\n{prompt}".strip() if system_prompt else prompt
        payload = {
            "model": model,
            "prompt": full_prompt,
            "stream": False,
            "options": {"temperature": temperature, "num_ctx": 8192},
        }
        try:
            resp = requests.post(f"{base}/api/generate", json=payload, timeout=180)
            resp.raise_for_status()
            return resp.json().get("response", "")
        except Exception as e:
            return f"Error: {str(e)}"

    if provider == "openai":
        try:
            import openai
            client = openai.OpenAI(api_key=api_key or os.getenv("OPENAI_API_KEY"))
            messages = []
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            messages.append({"role": "user", "content": prompt})
            r = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
            )
            return (r.choices[0].message.content or "")
        except Exception as e:
            return f"Error: {str(e)}"

    if provider == "anthropic":
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=api_key or os.getenv("ANTHROPIC_API_KEY"))
            r = client.messages.create(
                model=model,
                max_tokens=4096,
                system=system_prompt or "You are a helpful assistant.",
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
            )
            return (r.content[0].text if r.content else "")
        except Exception as e:
            return f"Error: {str(e)}"

    return f"Error: Provider '{provider}' not implemented."


class LLMCaller:
    """Thin wrapper that holds config and exposes .generate(prompt) for drop-in use."""

    def __init__(
        self,
        provider: str = "ollama",
        model: str = "llama3",
        temperature: float = 0.7,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        self.provider = provider
        self.model = model
        self.temperature = temperature
        self.base_url = base_url
        self.api_key = api_key

    def generate(self, prompt: str, system_prompt: str = "") -> str:
        return generate(
            prompt,
            system_prompt=system_prompt,
            provider=self.provider,
            model=self.model,
            temperature=self.temperature,
            base_url=self.base_url,
            api_key=self.api_key,
        )


# Profile-based client (loads from llm_profiles.json)
from .profile_client import LLMClient

__all__ = ["generate", "LLMCaller", "LLMClient"]
