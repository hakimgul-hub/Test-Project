import json
import os
import re
import uuid
import datetime
import logging
from typing import Dict, Any, List, Optional

# --- DEPENDENCIES ---
from src.axiom_core.layer3_judge.brains import DiagnosticJudge
from src.axiom_core.api.dependencies import DATA_DIR, EXAMINER_DIR, JUDGE_DIR

logger = logging.getLogger("JudgeEngine")

class ScientificScorer:
    @staticmethod
    def _safe_text(text: Any) -> str:
        if text is None: return ""
        return str(text).strip()

    @staticmethod
    def calculate_cosine_similarity(text1: str, text2: str) -> float:
        # Simple Jaccard fallback if sklearn is missing
        t1 = ScientificScorer._safe_text(text1).lower().split()
        t2 = ScientificScorer._safe_text(text2).lower().split()
        if not t1 or not t2: return 0.0
        intersection = len(set(t1) & set(t2))
        union = len(set(t1) | set(t2))
        return float(intersection / union) if union else 0.0

    @staticmethod
    def calculate_recall(ground_truth: str, student_answer: str) -> float:
        gt = ScientificScorer._safe_text(ground_truth)
        ans = ScientificScorer._safe_text(student_answer)
        def extract_keywords(text): return set(re.findall(r'\b\w{4,}\b', text.lower()))
        gt_keywords = extract_keywords(gt)
        if not gt_keywords: return 1.0 
        student_keywords = extract_keywords(ans)
        intersection = gt_keywords.intersection(student_keywords)
        return len(intersection) / len(gt_keywords)

class JudgeEngine:
    def __init__(self, model_name="local_deepseek", provider="local"):
        self.brain = DiagnosticJudge(model_name=model_name, provider=provider)
        self.model_id = model_name

    def _extract_document_context(self, data: Dict) -> List[Dict]:
        """Scans the input file to find which documents were used."""
        docs_found = {}
        items = data.get("results", []) or data.get("turns", [])
        for item in items:
            citations = item.get("cora_metadata", {}).get("citations", [])
            for cit in citations:
                doc_id = cit.get("document_id")
                if doc_id and doc_id not in docs_found:
                    docs_found[doc_id] = {
                        "title": cit.get("document_name") or cit.get("title") or "Untitled Document",
                        "id": doc_id,
                        "summary": cit.get("context_excerpt") or cit.get("title") or "No summary available."
                    }
        return list(docs_found.values())

    def evaluate_file(self, examiner_filename: str) -> Dict[str, Any]:
        file_path = None
        examiner_root = EXAMINER_DIR
        for root, _, files in os.walk(examiner_root):
            if examiner_filename in files:
                file_path = os.path.join(root, examiner_filename)
                break
        
        if not file_path:
            return {"status": "Error", "message": "File not found"}

        with open(file_path, 'r') as f: data = json.load(f)

        print(f"⚖️ Judge: Scientifically Diagnosing '{examiner_filename}'...")
        
        results = []
        scores = []
        failure_counts = {}

        items = data.get("results", []) or data.get("turns", [])

        for item in items:
            try:
                result_item = self._evaluate_single_item(item)
                results.append(result_item)
                
                verdict = result_item.get("judge_verdict", {})
                scores.append(verdict.get("score", 0))
                
                cat = verdict.get("failure_category", "UNKNOWN")
                failure_counts[cat] = failure_counts.get(cat, 0) + 1
                
                print(f"   👉 [Grade: {verdict.get('score')}/10] {cat}")
            except Exception as e:
                print(f"   ❌ Item failed: {e}")

        avg_score = round(sum(scores) / len(scores), 1) if scores else 0
        final_verdict = "PASS" if avg_score >= 7.0 else "FAIL"

        doc_context = self._extract_document_context(data)
        teacher_conf = data.get("teacher_configuration", {})

        provenance = {
            "source_teacher_file": data.get("source_file", "Unknown"),
            "examiner_run_id": data.get("run_id", "Unknown"),
            "examiner_timestamp": data.get("created_at", "Unknown"),
            "mode": data.get("mode", "Unknown"),
            "documents": doc_context,
            # ✅ Added Detailed Teacher Context
            "teacher_config": {
                "persona": teacher_conf.get("persona", "Default"),
                "domain": teacher_conf.get("domain", "General"),
                "model_used": teacher_conf.get("llm_model_id") or teacher_conf.get("model") or "Unknown LLM"
            },
            "cora_context": {
                "project_id": data.get("examiner_configuration", {}).get("project_id"),
                "thread_id": data.get("examiner_configuration", {}).get("thread_id"),
                "endpoint": data.get("examiner_configuration", {}).get("cora_endpoint"),
            }
        }

        report = {
            "report_id": str(uuid.uuid4()),
            "created_at": datetime.datetime.now().isoformat(),
            "examiner_file": examiner_filename,
            "judge_model": self.model_id,
            "provenance": provenance,
            "summary": {
                "average_score": avg_score,
                "final_verdict": final_verdict,
                "total_questions": len(scores),
                "failure_breakdown": failure_counts,
                "scientific_metrics": {
                    "accuracy_index": avg_score / 10.0,
                    "completeness_index": avg_score / 10.0 
                }
            },
            "results": results
        }

        self._save_report(report, examiner_filename)
        return report

    def _evaluate_single_item(self, item):
        question = item.get("question", "")
        expected = item.get("expected_answer", "")
        student = item.get("student_answer") or item.get("cora_response", {}).get("answer_text") or ""
        
        context = ""
        # ✅ Ensure we explicitly grab the teacher's source context for the report
        if "source_ref" in item:
            context = item["source_ref"].get("full_context_used", "")
        elif "supporting_quote" in item:
            context = item.get("supporting_quote", "")

        math_acc = ScientificScorer.calculate_cosine_similarity(expected, student)
        llm_audit = self.brain.evaluate(question, expected, student, context, metadata=item)

        final_score = (math_acc * 4.0) + (llm_audit["score"] * 0.6)
        final_score = min(10.0, round(final_score, 1))

        item["judge_verdict"] = {
            "score": final_score,
            "truth_validity": llm_audit.get("truth_validity", True),
            "failure_category": llm_audit.get("failure_category", "NONE"),
            "reasoning": llm_audit.get("reasoning", "No reasoning provided."),
            "scientific_metrics": {
                "vector_similarity": round(math_acc, 2),
                "keyword_recall": 0.0
            }
        }
        return item

    def _save_report(self, report, original_filename):
        mode = "Discovery"
        if "PROJ" in original_filename: mode = "Project"
        elif "SDOC" in original_filename: mode = "SingleDoc"
        elif "USER" in original_filename: mode = "UserDoc"
        
        save_dir = os.path.join(JUDGE_DIR, mode)
        os.makedirs(save_dir, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%Hh%M_%S")
        filename = f"Judge_{original_filename.replace('Examiner_', '').replace('.json', '')}_{timestamp}.json"
        
        with open(os.path.join(save_dir, filename), 'w') as f:
            json.dump(report, f, indent=2)
        print(f"✅ Saved Judge Report: {filename}")