import json
import re
import logging
import os
import requests  # Standard library for API calls
from typing import Dict, Any

logger = logging.getLogger("JudgeBrain")

# --- STANDALONE BRAIN (No Project Dependencies) ---
class StandaloneBrain:
    """
    A lightweight, dependency-free LLM client for the Judge.
    Bypasses 'src.axiom_core.dependencies' to prevent circular import crashes.
    """
    def __init__(self, provider="local", model="local_deepseek", temperature=0.0):
        self.provider = provider
        self.model = model
        self.temperature = temperature
        
        # Load keys directly from env or secrets file if needed
        self.openai_key = os.getenv("OPENAI_API_KEY")
        self.anthropic_key = os.getenv("ANTHROPIC_API_KEY")
        
        # Try to find secrets.json just in case
        try:
            root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            secret_path = os.path.join(root, "config", "secrets.json")
            if os.path.exists(secret_path):
                with open(secret_path, 'r') as f:
                    secrets = json.load(f)
                    self.openai_key = secrets.get("openai", self.openai_key)
                    self.anthropic_key = secrets.get("anthropic", self.anthropic_key)
        except: pass

    def generate(self, system_prompt, user_prompt):
        """Generates text using the configured provider."""
        try:
            if self.provider == "openai":
                return self._call_openai(system_prompt, user_prompt)
            elif self.provider == "anthropic":
                return self._call_anthropic(system_prompt, user_prompt)
            else:
                return self._call_local(system_prompt, user_prompt)
        except Exception as e:
            logger.error(f"Brain Gen Error: {e}")
            return f"{{ \"score\": 0, \"reasoning\": \"LLM Generation Failed: {str(e)}\", \"failure_category\": \"SYSTEM_ERROR\" }}"

    def _call_local(self, sys_p, user_p):
        """Direct call to Ollama/Local API (Default: localhost:11434)."""
        # Try Ollama standard endpoint
        url = "http://localhost:11434/api/generate"
        payload = {
            "model": self.model,
            "prompt": f"{sys_p}\n\n{user_p}",
            "stream": False,
            "options": {"temperature": self.temperature}
        }
        try:
            resp = requests.post(url, json=payload, timeout=120)
            if resp.status_code == 200:
                return resp.json().get("response", "")
        except:
            # Fallback to LM Studio/OpenAI-compatible local endpoint
            return self._call_openai(sys_p, user_p, base_url="http://localhost:8000/v1")
        return "{}"

    def _call_openai(self, sys_p, user_p, base_url="https://api.openai.com/v1"):
        import openai
        client = openai.OpenAI(api_key=self.openai_key or "lm-studio", base_url=base_url)
        resp = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": sys_p},
                {"role": "user", "content": user_p}
            ],
            temperature=self.temperature
        )
        return resp.choices[0].message.content

    def _call_anthropic(self, sys_p, user_p):
        import anthropic
        client = anthropic.Anthropic(api_key=self.anthropic_key)
        resp = client.messages.create(
            model=self.model,
            max_tokens=4000,
            system=sys_p,
            messages=[{"role": "user", "content": user_p}]
        )
        return resp.content[0].text

# --- JUDGE CLASSES ---

class BaseJudge:
    def evaluate(self, question: str, expected: str, student: str, context: str) -> Dict[str, Any]:
        raise NotImplementedError

class DiagnosticJudge(BaseJudge):
    def __init__(self, model_name="local_deepseek", provider="local"):
        self.brain = StandaloneBrain(provider=provider, model=model_name)

    def evaluate(self, question: str, expected: str, student: str, context: str, metadata: Dict = {}) -> Dict[str, Any]:
        
        system_prompt = """You are a Forensic QA Auditor for an advanced RAG system. 
Your goal is to evaluate a Student's answer against a Teacher's expected answer, referencing the Source Context.

STEP 1: AUDIT THE TEACHER (Ground Truth Verification)
- Look at the [SOURCE CONTEXT]. Is the [EXPECTED ANSWER] supported by it?
- If the Question asks about a Diagram/Chart, does the text describe it?
- If the Teacher asked about something not in the text, mark 'truth_validity' as FALSE.

STEP 2: AUDIT THE STUDENT (Answer Quality)
- If the Student is wrong, DIAGNOSE WHY.
- Failure Categories:
  - [BLINDNESS]: Student says "no diagram" but text describes one.
  - [LANGUAGE_MISMATCH]: Student answers in wrong language (e.g., Croatian vs English).
  - [HALLUCINATION]: Student invents facts.
  - [MISSING_CONTENT]: Specific fact not retrieved.
  - [NONE]: Correct answer.

OUTPUT JSON ONLY:
{
  "score": <0.0 to 10.0>,
  "truth_validity": <true/false>,
  "failure_category": <"NONE", "BLINDNESS", "LANGUAGE_MISMATCH", "HALLUCINATION", "MISSING_CONTENT", "TEACHER_ERROR">,
  "reasoning": "<Short explanation>"
}"""

        # Serialize metadata safely
        meta_str = "[]"
        try:
            meta_str = json.dumps(metadata.get('cora_metadata', {}).get('citations', []), indent=2, default=str)
        except: pass

        user_prompt = f"""
[SOURCE CONTEXT]:
{context[:3000]}...

[QUESTION]: {question}
[EXPECTED]: {expected}
[STUDENT]: {student}
[METADATA]: {meta_str}

Audit now. JSON only.
"""
        try:
            raw_response = self.brain.generate(system_prompt, user_prompt)
            return self._clean_json(raw_response)
        except Exception as e:
            logger.error(f"Judge Execution Failed: {e}")
            return {"score": 0, "reasoning": f"Judge Logic Crash: {e}", "failure_category": "SYSTEM_ERROR"}

    def _clean_json(self, text):
        try:
            text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
            text = re.sub(r'```json|```', '', text).strip()
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match: return json.loads(match.group(0))
            return json.loads(text)
        except:
            return {"score": 1, "reasoning": "Failed to parse Judge JSON output.", "failure_category": "JSON_ERROR"}

# Alias for compatibility
JudgeBrain = DiagnosticJudge