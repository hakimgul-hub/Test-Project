"""
Typed in-memory models for pipeline artifacts (Teacher, Examiner, Judge).
File formats on disk remain unchanged; these represent the structure when reading/writing.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# --- Teacher (Layer 1) ---

class TeacherTurn(BaseModel):
    """Single question/answer turn in a Teacher question set."""
    turn_id: Optional[str] = None
    question: str = ""
    expected_answer: str = ""
    generator_model: Optional[str] = None
    supporting_quote: Optional[str] = None
    citations: List[str] = Field(default_factory=list)
    image_path: Optional[str] = None
    source_ref: Optional[Dict[str, Any]] = None
    llm_meta: Optional[Dict[str, Any]] = None


class TeacherConfiguration(BaseModel):
    mode: str = ""
    model: str = ""
    document_title: Optional[str] = None
    document_id: Optional[str] = None
    documents: List[Dict[str, Any]] = Field(default_factory=list)
    topic: Optional[str] = None
    project_name: Optional[str] = None
    domain_profile: Optional[Dict[str, Any]] = None


class TeacherContextInfo(BaseModel):
    source_type: str = ""
    document_ids: List[str] = Field(default_factory=list)
    document_metadata: List[Dict[str, Any]] = Field(default_factory=list)


class TeacherOutput(BaseModel):
    """Teacher (Layer 1) artifact: run_id, question_set, teacher_configuration, context_info."""
    run_id: str = ""
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    teacher_configuration: TeacherConfiguration = Field(default_factory=TeacherConfiguration)
    context_info: TeacherContextInfo = Field(default_factory=TeacherContextInfo)
    generation_stats: Optional[Dict[str, Any]] = None
    question_set: Dict[str, Any] = Field(default_factory=lambda: {"turns": []})

    class Config:
        extra = "allow"

    def to_writable_dict(self) -> Dict[str, Any]:
        """Serialize for JSON write; include any extra fields."""
        return self.model_dump(exclude_none=True, by_alias=False)


# --- Examiner (Layer 2) ---

class ExaminerTurn(BaseModel):
    """Single turn in an Examiner run (question, answer, evidence)."""
    question: Optional[str] = None
    answer: Optional[str] = None
    answer_text: Optional[str] = None
    student_answer: Optional[str] = None
    resp: Optional[Dict[str, Any]] = None
    grounding_sources: Optional[List[Dict[str, Any]]] = None
    grounding_sources_details: Optional[List[Dict[str, Any]]] = None
    references: Optional[List[Any]] = None
    citations: Optional[List[Any]] = None
    links: Optional[List[Dict[str, Any]]] = None

    class Config:
        extra = "allow"


class ExaminerOutput(BaseModel):
    """Examiner (Layer 2) run output: turns/results and metadata."""
    turns: List[Dict[str, Any]] = Field(default_factory=list)
    results: Optional[List[Dict[str, Any]]] = None
    mode: Optional[str] = None
    created_at: Optional[str] = None
    teacher_source: Optional[str] = None
    teacher_run_id: Optional[str] = None
    examiner_configuration: Optional[Dict[str, Any]] = None

    class Config:
        extra = "allow"

    def get_turns(self) -> List[Dict[str, Any]]:
        if self.turns:
            return self.turns
        return self.results or []


# --- Judge (Layer 3) ---

class JudgeDetail(BaseModel):
    """Single turn evaluation in a Judge report."""
    turn_index: int = 0
    question: str = ""
    candidate_answer: str = ""
    reference_answer: str = ""
    score: float = 0.0
    metrics: Dict[str, Any] = Field(default_factory=dict)
    judge_verdict: str = ""
    failure_category: str = "NONE"
    student_evidence: List[Dict[str, Any]] = Field(default_factory=list)
    teacher_context: Optional[str] = None


class JudgeReport(BaseModel):
    """Judge (Layer 3) report: scores, metrics, verdicts, details."""
    run_id: str = ""
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    candidate_file: str = ""
    teacher_file: str = ""
    judge_model: str = ""
    run_context: Dict[str, Any] = Field(default_factory=dict)
    teacher_configuration: Optional[Dict[str, Any]] = None
    context_info: Optional[Dict[str, Any]] = None
    domain_profile: Optional[Dict[str, Any]] = None
    total_turns: int = 0
    average_score: float = 0.0
    details: List[Dict[str, Any]] = Field(default_factory=list)

    class Config:
        extra = "allow"

    def to_writable_dict(self) -> Dict[str, Any]:
        return self.model_dump(exclude_none=True, by_alias=False)
