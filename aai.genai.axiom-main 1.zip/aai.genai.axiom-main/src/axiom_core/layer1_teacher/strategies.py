# src/axiom_core/layer1_teacher/strategies.py
import json
import logging
import os

logger = logging.getLogger("AxiomCore.Strategies")


class Strategy:
    def __init__(self, domain_name, compliance_standard):
        self.domain_name = domain_name
        self.compliance_standard = compliance_standard
        self.config = self._load_config()

    def _load_config(self):
        """Loads the external configuration file."""
        try:
            # Calculate path relative to this file
            base_dir = os.path.dirname(os.path.abspath(__file__))
            # Go up 2 levels (to src/) then into config/
            config_path = os.path.join(base_dir, "..", "..", "config", "layer1_config.json")
            
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning("Config load error: %s. Using defaults.", e)
            return {"personas": {"Auditor": {"system_prompt": "You are an Auditor."}}}

    def get_generation_prompt(self, context, count, technique, persona_name="Auditor", **kwargs):
        """Alias for generator: same as get_prompt with count -> num_questions (Phase 7 interface alignment)."""
        return self.get_prompt(context, num_questions=count, persona_name=persona_name, technique=technique)

    def get_prompt(self, context, num_questions, persona_name="Auditor", technique="Strict Context"):
        """
        Generates a dynamic prompt by looking up the Persona in the JSON config.
        """
        # 1. Lookup Persona (Default to Auditor if not found)
        personas = self.config.get("personas", {})
        persona_def = personas.get(persona_name, personas.get("Auditor"))
        
        sys_prompt = persona_def.get("system_prompt", "You are an expert.")
        
        # 2. Define Output Format
        json_structure = """
        {
          "questions": [
            { 
              "question": "The specific question text...", 
              "type": "Compliance", 
              "expected_answer": "The correct answer based strictly on the text provided." 
            }
          ]
        }
        """

        # 3. Build Prompt
        if "Discovery" in technique:
            return f"""
            {sys_prompt}
            DOMAIN: {self.domain_name} ({self.compliance_standard})
            
            TASK:
            The user is exploring the topic: "{context}".
            Using your general knowledge, generate {num_questions} questions a {persona_name} would ask.
            
            CRITICAL:
            - Provide the "expected_answer" for each question based on standard industry knowledge.
            - Return ONLY valid JSON:
            {json_structure}
            """
            
        else:
            # Standard / Strict / Adversarial Context
            return f"""
            {sys_prompt}
            DOMAIN: {self.domain_name} ({self.compliance_standard})
            
            TASK:
            Review the CONTEXT MATERIAL below.
            Generate {num_questions} specific questions using the "{technique}" technique.
            
            CRITICAL:
            - You MUST provide an "expected_answer" for every question based ONLY on the context.
            - If the context mentions a specific value (e.g. 5ms), the expected answer must cite it.
            - Return ONLY valid JSON:
            {json_structure}

            CONTEXT MATERIAL:
            {context[:25000]} 
            """

# --- CONCRETE STRATEGIES ---
class CoraAutomotiveStrategy(Strategy):
    def __init__(self): super().__init__("Automotive ADAS", "ISO 26262 / ISO 21448")

class CoraPharmaStrategy(Strategy):
    def __init__(self): super().__init__("Clinical Pharma", "FDA 21 CFR Part 11")

class CoraLegalStrategy(Strategy):
    def __init__(self): super().__init__("Legal Tech", "GDPR / EU AI Act")


# Aliases for tests and scripts (same behavior as concrete strategies above)
CoraAdasStrategy = CoraAutomotiveStrategy  # ADAS = Automotive ADAS
OmniLegisStrategy = CoraLegalStrategy      # Legal / legislation