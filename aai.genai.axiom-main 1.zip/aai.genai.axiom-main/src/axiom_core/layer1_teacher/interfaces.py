from abc import ABC, abstractmethod
from typing import Dict, Any

class ITeacherBrain(ABC):
    """
    Interface for the 'Brain' of the agent.
    Responsible for raw text processing and JSON generation.
    Adapters: OpenSourceLlama, GeminiUltra, GPT4.
    """
    @abstractmethod
    def generate_exam_content(self, system_prompt: str, source_text: str) -> Dict[str, Any]:
        """
        Takes the thinking rules (system_prompt) and the content (source_text).
        Returns a validated dictionary (the exam).
        """
        pass

    @abstractmethod
    def get_model_metadata(self) -> Dict[str, str]:
        """Returns model name, version, and cost tier."""
        pass


class IDomainStrategy(ABC):
    """
    Interface for the 'Domain Knowledge'.
    Responsible for telling the Brain HOW to think about a specific industry.
    Adapters: AutomotiveADAS, LegalTechEU, AutoSAR.
    """
    @abstractmethod
    def get_system_prompt(self) -> str:
        """Returns the prompt that defines the persona (e.g., 'Act as a Safety Engineer')."""
        pass

    @abstractmethod
    def validate_source_material(self, text_snippet: str) -> bool:
        """Sanity check: Is this text actually relevant to the selected domain?"""
        pass