from abc import ABC, abstractmethod
import os
from src.axiom_core.llm import generate as llm_generate

class BaseTeacher(ABC):
    """
    Abstract Base Class for all Teacher Brains (LLMs).
    Enforces the implementation of generation methods.
    """
    
    @abstractmethod
    def generate(self, prompt: str) -> str:
        """Standard generation"""
        pass

    @abstractmethod
    def generate_exam_content(self, prompt: str) -> str:
        """
        Specialized generation for exam content. 
        Required by GoldenDatasetGenerator.
        """
        pass

class OpenSourceTeacher(BaseTeacher):
    """
    Connects to local LLMs via Ollama (uses shared LLM client).
    """
    def __init__(self, model_name="llama3", base_url=None):
        self.model_name = model_name
        self.base_url = base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        if self.base_url.endswith("/api/generate"):
            self.base_url = self.base_url.replace("/api/generate", "")

    def generate(self, prompt: str) -> str:
        return llm_generate(
            prompt,
            provider="ollama",
            model=self.model_name,
            temperature=0.7,
            base_url=self.base_url,
        )

    def generate_exam_content(self, prompt: str) -> str:
        return self.generate(prompt)


class PremiumTeacher(BaseTeacher):
    """
    Connects to paid APIs (OpenAI, Anthropic) via shared LLM client.
    """
    def __init__(self, api_key: str, model_name="gpt-4"):
        self.api_key = api_key
        self.model_name = model_name
        self.provider = "anthropic" if "claude" in model_name.lower() else "openai"

    def generate(self, prompt: str) -> str:
        return llm_generate(
            prompt,
            provider=self.provider,
            model=self.model_name,
            temperature=0.7,
            api_key=self.api_key,
        )

    def generate_exam_content(self, prompt: str) -> str:
        return self.generate(prompt)