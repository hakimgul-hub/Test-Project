import json
import logging
import re

logger = logging.getLogger("AxiomCore.Generator")


class GoldenDatasetGenerator:
    def __init__(self, brain, strategy):
        self.brain = brain
        self.strategy = strategy
        self.context = ""

    def inject_source_material(self, text):
        self.context = text

    def create_exam(self, num_questions=5, persona="Auditor", technique="Strict Context"):
        """
        Generates exam questions.
        Matches the arguments sent by teacher.py: create_exam(ask_count, persona=..., technique=...)
        """
        
        # 1. Get Dynamic Prompt from Strategy
        # Note: We check which method exists to ensure compatibility with different strategy versions
        if hasattr(self.strategy, "get_generation_prompt"):
            prompt = self.strategy.get_generation_prompt(
                context=self.context,
                count=num_questions,
                technique=technique,
                persona_name=persona,
            )
        else:
            # Fallback to legacy method name
            prompt = self.strategy.get_prompt(
                context=self.context, 
                num_questions=num_questions, 
                persona_name=persona, 
                technique=technique
            )

        model_name = getattr(self.brain, "model_name", getattr(self.brain, "model", "Unknown"))
        logger.info("%s (%s) requesting %d items via %s", persona[:20], technique, num_questions, model_name)
        
        # 2. Generate
        raw_response = self.brain.generate(prompt)
        
        # 3. Parse
        return self._clean_and_parse(raw_response)

    def _clean_and_parse(self, raw_text):
        """
        Your trusted parsing logic, with a tiny 'JSON Repair' safety net added.
        """
        try:
            # Clean Markdown wrappers
            clean_text = raw_text.strip()
            if "```json" in clean_text:
                clean_text = clean_text.split("```json")[1].split("```")[0].strip()
            elif "```" in clean_text:
                clean_text = clean_text.split("```")[1].split("```")[0].strip()
            
            # Regex to find the JSON block
            match = re.search(r'(\[.*\]|\{.*\})', clean_text, re.DOTALL)
            if not match: 
                return {"questions": [], "raw_error": "No JSON found"}
            
            json_str = match.group(1)
            
            # --- THE SAFETY NET (Only runs if needed) ---
            # Attempt direct load first (Fast & Standard)
            try:
                data = json.loads(json_str)
            except json.JSONDecodeError:
                # If that fails, try the simple regex repair for missing commas
                # (Common issue with 8b models)
                json_str = re.sub(r'}\s*{', '}, {', json_str) # Fix missing comma between objects
                json_str = re.sub(r',\s*}', '}', json_str)    # Fix trailing comma
                data = json.loads(json_str)

            # --- NORMALIZATION (Your original logic) ---
            if isinstance(data, list):
                data = {"questions": data} 

            # Handle different keys models might output
            if "question" in data and isinstance(data["question"], list):
                data["questions"] = data["question"]
            
            if "questions" not in data: data["questions"] = []

            for q in data["questions"]:
                if "type" not in q: q["question_type"] = "General"
                if "expected_answer" not in q: q["expected_answer"] = "Refer to documentation."

            return data

        except Exception as e:
            logger.warning("Parse error: %s", e)
            # Return empty list so the Teacher loop doesn't crash, just skips this chunk
            return {"questions": [], "raw_error": str(e)}