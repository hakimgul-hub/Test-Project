# src/axiom_core/mongo_loader.py
import os
import json
import uuid
import pymongo
from bson import Binary
from dotenv import load_dotenv

# Load .env from repo root so MONGO_URI is set even when cwd is e.g. src/axiom_ui
try:
    _mongo_loader_dir = os.path.dirname(os.path.abspath(__file__))
    _repo_root = os.path.abspath(os.path.join(_mongo_loader_dir, "../.."))
    load_dotenv(os.path.join(_repo_root, ".env"))
except Exception:
    load_dotenv()  # fallback: cwd

# --- CONFIG ---
def load_mongo_config():
    config = { "uri": os.getenv("MONGO_URI"), "db": "corax-dev", "col": "documents" }
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__)) 
        src_dir = os.path.dirname(current_dir)
        config_path = os.path.join(src_dir, "config", "mongo_config.json")
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                profile = data.get("profiles", {}).get(data.get("active_profile", "dev"), {})
                config["uri"] = os.getenv(profile.get("uri_env_var", "MONGO_URI"))
                config["db"] = profile.get("db_name", "corax-dev")
                config["col"] = profile.get("collection_name", "documents")
    except: pass
    return config

MONGO_CONF = load_mongo_config()

def _mongo_client_kwargs():
    """Kwargs for MongoClient so TLS to Atlas (and other cloud) works on macOS and elsewhere."""
    try:
        import certifi
        return {"tlsCAFile": certifi.where()}
    except ImportError:
        return {}

def get_mongo_client():
    if not MONGO_CONF["uri"]: return None
    try:
        kwargs = {"uuidRepresentation": "standard", **_mongo_client_kwargs()}
        return pymongo.MongoClient(MONGO_CONF["uri"], **kwargs)
    except Exception:
        return None

# --- ID HELPERS ---
def _clean_id(raw_id):
    if not raw_id: return None
    try:
        if isinstance(raw_id, str):
            if raw_id.startswith("b'") or raw_id.startswith('b"'): return raw_id.strip("b'\"")
            return raw_id
        if isinstance(raw_id, uuid.UUID): return str(raw_id)
        if isinstance(raw_id, Binary): return str(uuid.UUID(bytes=raw_id))
        if isinstance(raw_id, bytes): return str(uuid.UUID(bytes=raw_id))
    except: pass
    return str(raw_id)

def _format_doc(doc):
    if not doc: return {}
    raw_id = doc.get("id") or doc.get("uuid") or doc.get("_id")
    return {
        "id": _clean_id(raw_id),
        "title": doc.get("title") or doc.get("document_name") or "Untitled",
        "full_title": doc.get("full_title", ""),
        "celex_id": doc.get("celex_id", "N/A"),
        "date_document": doc.get("date_document", doc.get("date", "N/A")),
        "version": doc.get("version", doc.get("version_name", "1.0")),
        "lifecycle": doc.get("lifecycle_status", "Active"),
        "summary": doc.get("summary", "No summary.")
    }

# --- AVAILABILITY CHECK (for UI and API) ---
def is_mongo_available():
    """
    Returns (ok: bool, message: str). Use in UI/API to show warnings when DB is not working.
    message is empty when ok is True, otherwise a short reason (e.g. "MONGO_URI not set", "Connection refused").
    """
    if not (MONGO_CONF.get("uri") or "").strip():
        return False, "MongoDB not configured (set MONGO_URI in .env for document library)."
    client = get_mongo_client()
    if not client:
        return False, "MongoDB connection failed (check MONGO_URI and network)."
    try:
        client.server_info()
        return True, ""
    except Exception as e:
        msg = str(e).split("(")[0].strip() or "Connection failed"
        if len(msg) > 80:
            msg = msg[:77] + "..."
        return False, msg

# --- EXPORTED FUNCTIONS ---

def fetch_document_library_index(search_query=None):
    client = get_mongo_client()
    if not client: return []
    try:
        col = client[MONGO_CONF["db"]][MONGO_CONF["col"]]
        query = {}
        if search_query and search_query.strip():
            regex = {"$regex": search_query.strip(), "$options": "i"}
            query = {"$or": [
                {"title": regex}, {"full_title": regex}, 
                {"filename": regex}, {"id": regex}
            ]}
        cursor = col.find(query).limit(50)
        return [_format_doc(d) for d in cursor]
    except Exception as e:
        print(f"❌ Search Error: {e}")
        return []

def get_document_content(doc_id):
    """
    Fetches full content + metadata.
    """
    client = get_mongo_client()
    if not client: return None
    try:
        col = client[MONGO_CONF["db"]][MONGO_CONF["col"]]
        
        # Robust ID search
        query = {"$or": [{"id": doc_id}, {"_id": doc_id}]}
        try:
            as_uuid = uuid.UUID(doc_id)
            query["$or"].append({"id": as_uuid})
            query["$or"].append({"_id": as_uuid})
        except: pass

        doc = col.find_one(query)
        if doc:
            meta = _format_doc(doc)
            
            # 🚨 CRITICAL: Ensure 'text' key always exists
            text_content = (doc.get("content") or 
                            doc.get("text") or 
                            doc.get("full_text") or 
                            doc.get("summary") or 
                            "")
            
            if not text_content:
                text_content = f"⚠️ Document '{meta['title']}' has no text content in the database."

            meta["text"] = text_content
            return meta

        return None
    except Exception as e:
        print(f"❌ Get Content Error: {e}")
        return None


def get_detailed_document_info(doc_id):
    """Alias for get_document_content for UI compatibility."""
    return get_document_content(doc_id)


def find_document_hierarchy(cora_id):
    """
    Returns hierarchy info for a document by ID, or None if not found.
    UI expects: {"metadata": {...}, "hierarchy_type": str, "parent_id": optional, "parent_title": optional}.
    """
    doc = get_document_content(cora_id)
    if not doc:
        return None
    return {
        "metadata": doc,
        "hierarchy_type": doc.get("lifecycle") or "Root",
        "parent_id": None,
        "parent_title": None,
    }