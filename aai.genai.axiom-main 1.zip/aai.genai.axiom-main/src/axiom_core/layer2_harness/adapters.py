import requests
import json
import uuid
import logging
import os
from pathlib import Path
from typing import Dict, Any, List, Optional

logger = logging.getLogger("CoraHarness")

class CoraHarness:
    def __init__(self, base_url=None, username=None, password=None):
        self.anchors = self._load_anchors()
        
        if not base_url or not username or not password:
            creds = self._load_creds_from_file()
            if creds:
                base_url = base_url or creds.get("base_url")
                username = username or creds.get("username")
                password = password or creds.get("password")
        
        if not base_url: base_url = os.environ.get("CORA_BASE_URL")
        if not username: username = os.environ.get("CORA_USERNAME")
        if not password: password = os.environ.get("CORA_PASSWORD")

        if not base_url or not username or not password:
            raise ValueError("CoraHarness: Missing credentials.")

        self.base_url = self._fix_url(base_url)
        self.username = username
        self.password = password
        self.token = None
        self._login()

    def _load_anchors(self):
        current_file = Path(__file__).resolve()
        project_root = current_file.parent.parent.parent.parent
        candidates = [
            project_root / "src" / "config" / "cora_anchors.json",
            project_root / "config" / "cora_anchors.json",
        ]
        for path in candidates:
            if path.exists():
                try:
                    with open(path, 'r') as f: return json.load(f).get("environments", {}).get("dev", {})
                except: pass
        return {}

    def _load_creds_from_file(self):
        current_file = Path(__file__).resolve()
        project_root = current_file.parent.parent.parent.parent
        candidates = [
            project_root / "src" / "config" / "secrets.json",
            project_root / "config" / "secrets.json",
        ]
        for path in candidates:
            if path.exists():
                try:
                    with open(path, 'r', encoding='utf-8') as f: 
                        raw = json.load(f)
                        if "cora_dev" in raw: raw = raw["cora_dev"]
                        elif "cora" in raw: raw = raw["cora"]
                        return {
                            "base_url": raw.get("base_url") or raw.get("cora_base_url"),
                            "username": raw.get("username") or raw.get("cora_user"),
                            "password": raw.get("password") or raw.get("cora_pass")
                        }
                except: pass
        return None

    def _fix_url(self, url):
        if not url: return ""
        url = url.rstrip("/")
        if "automotive-ai.com" in url and not url.endswith("/cora"): return f"{url}/cora"
        return url

    def _login(self):
        try:
            url = f"{self.base_url}/api/v1/auth/login"
            resp = requests.post(url, data={"username": self.username, "password": self.password})
            if resp.status_code == 200:
                self.token = resp.json().get("access_token")
                print("✅ [Adapter] Logged in.")
            else:
                print(f"❌ [Adapter] Login failed: {resp.status_code}")
        except Exception as e:
            print(f"❌ [Adapter] Connection Error: {e}")

    # --- THREADS ---
    def create_thread(self, mode="discovery", doc_id=None, project_id=None, version_name="Legal act", language="EN"):
        if not self.token: self._login()
        url = f"{self.base_url}/api/v1/threads/"
        
        payload = {
            "thread_name": f"Viva_{mode}_{uuid.uuid4().hex[:6]}",
            "language": language
        }

        if mode == "discovery":
            magic_id = self.anchors.get("discovery_anchor_id")
            if not magic_id and self.anchors: magic_id = list(self.anchors.values())[0]
            if not magic_id: print("⚠️ [Adapter] Missing Anchor ID for Discovery!")
            payload["document_id"] = magic_id
            payload["version_name"] = version_name 

        elif mode in ["pct", "project"]:
            if not project_id: print(f"⚠️ [Adapter] Warning: PCT mode missing project_id")
            payload["project_id"] = project_id
            payload["version_name"] = version_name
            payload["document_id"] = doc_id if doc_id else self.anchors.get("discovery_anchor_id")

        elif mode in ["document", "single_doc", "user_doc", "user_document"]:
            if not doc_id: raise ValueError(f"{mode} mode requires document_id")
            payload["document_id"] = doc_id
            payload["version_name"] = version_name

        print(f"→ [Adapter] POST /threads | Payload: {json.dumps(payload)}")

        try:
            resp = requests.post(url, json=payload, headers={"Authorization": f"Bearer {self.token}"})
            if resp.status_code in [200, 201]:
                data = resp.json()
                inner = data.get("data", {})
                thread_id = inner.get("thread_id") or inner.get("id") or data.get("id")
                
                if thread_id:
                    return {
                        "thread_id": thread_id, 
                        "mode": mode, 
                        "project_id": project_id, 
                        "document_id": payload.get("document_id")
                    }
                print(f"⚠️ [Adapter] Thread created but ID missing. Response keys: {data.keys()}")
            
            print(f"❌ [Adapter] Thread Create Failed ({resp.status_code}): {resp.text}")
        except Exception as e:
            print(f"❌ [Adapter] Thread Exception: {e}")
        return {} 

    # --- CHAT ---
    def ask_llm_stream(self, context, model_id, question):
        if not self.token: self._login()
        url = f"{self.base_url}/api/v1/llm-connect/ask-llm/stream"
        
        mode = context.get("mode", "discovery")
        doc_trace = {}

        if mode == "discovery":
            doc_trace = {
                "thread_id": context.get("thread_id"), 
                "document_id": context.get("document_id"), 
                "document_part": "search-engine"
            }
        elif mode in ["pct", "project"]:
            doc_trace = {
                "thread_id": context.get("thread_id"), 
                "project_id": context.get("project_id"),
                "document_id": context.get("document_id"), 
                "document_part": "search-engine"
            }
        else:
            doc_trace = {
                "thread_id": context.get("thread_id"),
                "document_id": context.get("document_id"),
                "document_version_name": context.get("version_name", "Legal act"),
                "document_language": "EN",
                "document_part": "search-engine"
            }

        payload = {"document_trace": doc_trace, "question": question}
        full_text, citations, grounding = "", [], []

        try:
            with requests.post(url, json=payload, headers={"Authorization": f"Bearer {self.token}"}, stream=True) as r:
                for line in r.iter_lines():
                    if line:
                        try:
                            decoded = line.decode('utf-8').replace('data: ', '')
                            if decoded == '[DONE]': break
                            chunk = json.loads(decoded)
                            val = chunk.get("answer") or chunk.get("text") or chunk.get("content") or ""
                            full_text += val
                            if "grounding_sources" in chunk: grounding.extend(chunk["grounding_sources"])
                            if "citations" in chunk: citations.extend(chunk["citations"])
                        except: pass
        except: pass

        return {"answer_text": full_text, "citations": citations, "grounding_sources": grounding, "model_used": model_id}

    # --- PROJECT HELPERS (ROBUST FALLBACK) ---
    def get_or_create_project(self, name):
        if not self.token: self._login()
        
        # 1. Try Create
        try:
            payload = {"project_name": name, "description": "Automated Project"}
            resp = requests.post(f"{self.base_url}/api/v1/projects/", json=payload, headers={"Authorization": f"Bearer {self.token}"})
            
            if resp.status_code in [200, 201]: 
                data = resp.json()
                pid = data.get("data", {}).get("id") or data.get("id")
                if pid:
                    print(f"   ✅ [Adapter] Created Project '{name}' -> {pid}")
                    return pid
        except: pass

        # 2. If Create failed (e.g. duplicate), LIST and FIND
        try:
            print(f"   🔄 [Adapter] Checking existing projects...")
            list_resp = requests.get(f"{self.base_url}/api/v1/projects/", headers={"Authorization": f"Bearer {self.token}"})
            if list_resp.status_code == 200:
                raw = list_resp.json()
                projects = raw if isinstance(raw, list) else raw.get("items", []) or raw.get("data", []) or raw.get("data", {}).get("items", [])
                
                # A. Find exact match
                for p in projects:
                    if p.get("project_name") == name or p.get("name") == name:
                        pid = p.get("id")
                        print(f"   ✅ [Adapter] Found existing Project '{name}' -> {pid}")
                        return pid
                
                # B. Find ANY match (Fail-safe)
                if projects:
                    first = projects[0]
                    pid = first.get("id")
                    pname = first.get("project_name") or first.get("name")
                    print(f"   ⚠️ [Adapter] Exact match failed. Using First Available Project: '{pname}' ({pid})")
                    return pid
        except Exception as e:
            print(f"   ❌ [Adapter] List Projects Exception: {e}")
        
        return None

    def attach_document_to_project(self, project_id, document_id, version="Legal act"):
        if not self.token: self._login()
        if not project_id: return
        url = f"{self.base_url}/api/v1/projects/{project_id}"
        try:
            curr = requests.get(url, headers={"Authorization": f"Bearer {self.token}"}).json().get("attached_documents", [])
            if not any(d.get('document_id') == document_id for d in curr):
                curr.append({"document_id": document_id, "version_name": version, "language": "EN"})
                requests.patch(url, json={"attached_documents": curr}, headers={"Authorization": f"Bearer {self.token}"})
                print(f"   📎 [Adapter] Attached {document_id}")
        except: pass

    def upload_document(self, file_path):
        if not self.token: self._login()
        try:
            with open(file_path, 'rb') as f:
                resp = requests.post(f"{self.base_url}/api/v1/documents/upload", files={'file': f}, headers={"Authorization": f"Bearer {self.token}"})
                if resp.status_code == 200: 
                    data = resp.json()
                    return data.get("data", {}).get("id") or data.get("id")
        except: pass
        return None

    def get_grounding_details(self, library_ids, user_ids):
        if not self.token: self._login()
        if not library_ids and not user_ids: return {}
        url = f"{self.base_url}/api/v1/grounding-sources/"
        payload = {"grounding_sources": []}
        if library_ids: payload["grounding_sources"].append({"source_type": "library", "ids": library_ids})
        if user_ids: payload["grounding_sources"].append({"source_type": "user", "ids": user_ids})
        resolved = {}
        try:
            resp = requests.post(url, json=payload, headers={"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"})
            if resp.status_code == 200:
                data = resp.json()
                items = data.get("items", []) if isinstance(data, dict) else data
                for item in items:
                    if item.get("id"): resolved[item.get("id")] = item
        except: pass
        return resolved