from __future__ import annotations

import json
import os
import sys
from datetime import datetime
from typing import Any, Dict, Optional

import requests


def die(msg: str) -> None:
    # ✅ MODIFIED FOR SERVER: Raise Exception instead of killing process
    print(f"\n❌ {msg}\n", file=sys.stderr)
    raise RuntimeError(msg)  # <-- This prevents the server crash


def now_ts() -> str:
    return datetime.utcnow().isoformat() + "Z"


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def safe_filename(s: str, maxlen: int = 80) -> str:
    s = "".join(ch for ch in s if ch.isalnum() or ch in (" ", "_", "-", ".")).strip()
    s = s.replace(" ", "_")
    return (s[:maxlen] if len(s) > maxlen else s) or "file"


def is_json(r: requests.Response) -> bool:
    return "application/json" in (r.headers.get("Content-Type") or "").lower()


def dump_response(r: requests.Response, label: str = "") -> None:
    ct = r.headers.get("Content-Type", "")
    print(f"\n--- {label} RESPONSE DEBUG ---")
    print("URL:", r.url)
    print("Status:", r.status_code)
    print("Content-Type:", ct)
    print("Set-Cookie:", (r.headers.get("Set-Cookie", "") or "")[:250])
    txt = r.text or ""
    print("Body (first 1200 chars):")
    print(txt[:1200])
    print("--- END DEBUG ---\n")


def get_json_or_die(r: requests.Response) -> Any:
    if not is_json(r):
        dump_response(r, "NON-JSON")
        die(f"Expected JSON, got {r.headers.get('Content-Type')}")
    return r.json()


def auth_headers(token: Optional[str]) -> Dict[str, str]:
    h = {"Accept": "application/json"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def print_json(obj: Any, max_chars: int = 5000) -> None:
    try:
        s = json.dumps(obj, indent=2, ensure_ascii=False)
    except Exception:
        s = str(obj)
    if len(s) > max_chars:
        s = s[:max_chars] + "…"
    print(s)