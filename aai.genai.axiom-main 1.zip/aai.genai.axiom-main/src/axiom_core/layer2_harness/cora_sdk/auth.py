from __future__ import annotations

from getpass import getpass
from typing import Optional

import requests

from .config import Config
from .utils import die, dump_response, get_json_or_die, is_json


def login(sess: requests.Session, cfg: Config) -> Optional[str]:
    """
    Login behavior:
      1) Prefer env vars CORA_USERNAME / CORA_PASSWORD
      2) If missing, prompt interactively in CLI
      3) Retry a few times on auth failure

    Returns:
      - Bearer token string if returned by backend
      - None if backend uses cookie-session auth (cookies stored in sess)
    """

    url = f"{cfg.base_url}{cfg.api_prefix}/auth/login"
    print("→ POST", url)

    def _attempt(u: str, p: str) -> requests.Response:
        # Try JSON first
        r = sess.post(
            url,
            json={"username": u, "password": p},
            headers={"Accept": "application/json"},
            timeout=cfg.timeout,
            allow_redirects=True,
        )
        # Fallback to form if needed
        if r.status_code >= 400:
            r = sess.post(
                url,
                data={"username": u, "password": p},
                headers={"Accept": "application/json"},
                timeout=cfg.timeout,
                allow_redirects=True,
            )
        return r

    use_env = bool((cfg.username or "").strip()) and bool((cfg.password or "").strip())
    if not use_env:
        print("ℹ️ CORA_USERNAME/CORA_PASSWORD not found in environment. Falling back to interactive login.")
        print("   Tip: export CORA_USERNAME and CORA_PASSWORD to skip this prompt next time.\n")

    last_error: Optional[str] = None

    for attempt in range(1, cfg.login_max_attempts + 1):
        if use_env and attempt == 1:
            u = (cfg.username or "").strip()
            p = (cfg.password or "").strip()
        else:
            u = (input("CORA Username: ") or "").strip()
            p = (getpass("CORA Password: ") or "").strip()

        if not u or not p:
            print("❌ Username/password cannot be empty.\n")
            last_error = "empty credentials"
            use_env = False
            continue

        r = _attempt(u, p)
        print("  [", r.status_code, "]")

        if r.status_code >= 400:
            last_error = f"HTTP {r.status_code}"
            if is_json(r):
                try:
                    j = r.json()
                    msg = j.get("detail") or j.get("message") or j.get("error")
                    if msg:
                        print(f"⚠️ Login failed: {msg}\n")
                    else:
                        print("⚠️ Login failed.\n")
                except Exception:
                    print("⚠️ Login failed.\n")
            else:
                print("⚠️ Login failed (non-JSON response).\n")

            use_env = False
            continue

        # success: persist into cfg (useful for downstream tool calls)
        cfg.username = u
        cfg.password = p

        token = None
        if is_json(r):
            data = get_json_or_die(r)
            token = data.get("access_token") or data.get("token") or data.get("id_token")

        if token:
            print("✅ Logged in with Bearer token.")
            return token

        if sess.cookies:
            print("✅ Logged in with cookie session (no token returned).")
            return None

        dump_response(r, "LOGIN NO TOKEN/COOKIE")
        die("Login returned neither token nor cookies. Wrong endpoint/fields or SSO redirect.")

    die(
        f"Unable to log in after {cfg.login_max_attempts} attempt(s). "
        f"Last error: {last_error or 'unknown'}"
    )
