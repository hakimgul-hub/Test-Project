import os
from dataclasses import dataclass

class Config:
    def __init__(self):
        # Environment
        self.cora_env = os.getenv("CORA_ENV", "dev").lower().strip() or "dev"
        
        # Base URL
        if self.cora_env == "prod":
            self.base_url = "https://corax.automotive-ai.com"
        else:
            self.base_url = "https://corax-dev.automotive-ai.com"
            
        # API Prefix
        self.api_prefix = os.getenv("CORA_API_PREFIX", "/cora/api/v1")

        # Auth
        self.username = os.getenv("CORA_USERNAME", "")
        self.password = os.getenv("CORA_PASSWORD", "")
        self.login_max_attempts = int(os.getenv("CORA_LOGIN_MAX_ATTEMPTS", "1"))
        self.timeout = int(os.getenv("CORA_TIMEOUT", "120"))

        # Defaults
        self.language = os.getenv("CORA_LANGUAGE", "EN")
        self.document_part = os.getenv("CORA_DOCUMENT_PART", "search-engine")
        
        # Output
        self.threads_registry = os.getenv("CORA_THREADS_REGISTRY", "threads_index.json")
        self.results_dir = os.getenv("CORA_RESULTS_DIR", "results")
        self.write_every_n_turns = int(os.getenv("CORA_WRITE_EVERY_N_TURNS", "1"))
        self.log_payloads = True

        # System IDs
        self.discovery_thread_doc_id = os.getenv("CORA_DISCOVERY_THREAD_DOC_ID", "36f27a7f-badb-4701-be01-4d7c1baeda78")
        self.project_context_thread_doc_id = os.getenv("CORA_PCT_THREAD_DOC_ID", "47f38bbb-c3b9-47b1-9fc2-250617d7459f")

        # --- REQUIRED FLAGS (Add these) ---
        self.capture_custom_prompt_text = True
        self.capture_system_prompts = False
        self.capture_system_prompt_text = False
        self.system_prompt_version_default = "v1"

    @classmethod
    def from_env(cls):
        return cls()