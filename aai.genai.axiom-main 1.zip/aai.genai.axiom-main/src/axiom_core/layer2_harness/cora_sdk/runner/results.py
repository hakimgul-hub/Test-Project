from __future__ import annotations

import json
import os
import uuid
from typing import Any, Dict, Optional

from ..config import Config
from ..utils import ensure_dir, now_ts, safe_filename


def init_run_log(cfg: Config, question_set: str, mode: str, ids: Dict[str, str], thread_name: str, document_id: str, version_name: str, document_part: str, api_version: str | None) -> Dict[str, Any]:
    return {
        "run_id": uuid.uuid4().hex,
        "created_at": now_ts(),
        "question_set": question_set,
        "mode": mode,
        "thread": {"thread_name": thread_name, **ids},
        "document": {
            "document_id": document_id,
            "version_name": version_name,
            "language": cfg.language,
            "document_part": document_part,
        },
        "turns": [],
        "debug_info": {
            "cora_env": cfg.cora_env,
            "base_url": cfg.base_url,
            "api_prefix": cfg.api_prefix,
            "openapi_version": api_version,
            "messages_snapshot": None,
        },
    }


def write_run_log(cfg: Config, thread_name: str, run_log: Dict[str, Any]) -> str:
    ensure_dir(cfg.results_dir)
    out_path = os.path.join(cfg.results_dir, f"{safe_filename(thread_name)}.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(run_log, f, ensure_ascii=False, indent=2)
    return out_path
