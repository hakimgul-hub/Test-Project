from __future__ import annotations

from typing import Dict, List, Optional

import requests

from ..config import Config
from ..api.threads import create_thread, make_thread_name, register_thread
from ..api.projects import get_project_cached, extract_project_summary
from ..api.llm import ask_llm_stream
from ..api.grounding import extract_ids_by_type, resolve_grounding_sources_cached
from ..api.openapi import fetch_messages_best_effort
from ..api.prompts import capture_prompts_bundle
from ..utils import now_ts
from .results import init_run_log, write_run_log


# =============================================================================
# Modes overview (what differs)
#
# Common pipeline for ALL modes:
#   - create/reuse thread
#   - ask questions sequentially (ask-llm/stream)
#   - parse response (answer, links, grounding_sources, debug stream)
#   - resolve grounding sources via /grounding-sources/ (non-blocking)
#   - write run log
#
# Mode differences are ONLY:
#   - which document_id is used
#   - which inputs are required
#
# Required / Optional per mode:
#
# DISCOVERY
#   Required: name, questions,
#   Optional: project_id, custom_prompts, existing_thread_ids, 
#   document_id: cfg.discovery_thread_doc_id
#
# PCT
#   Required: name, questions, project_id
#   Optional: custom_prompts, existing_thread_ids,
#   document_id: cfg.project_context_thread_doc_id
#
# DOCUMENT
#   Required: name, questions, document_id, version_name, language
#   Optional: custom_prompts, existing_thread_ids, document_part
#
# USER_DOCUMENT
#   Required: name, questions, document_id, version_name, language
#   Optional: project_id, custom_prompts, existing_thread_ids, document_part
# =============================================================================

def run_mode_questions(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    *,
    mode: str,
    name: str,
    questions: List[str],
    document_id: str,
    version_name: str,
    language: Optional[str] = "EN",
    project_id: Optional[str] = None,
    document_part: Optional[str] = None,
    custom_prompts: Optional[Dict[str, str]] = None,
    existing_thread_ids: Optional[Dict[str, str]] = None,
    openapi: Optional[dict] = None, #for logging
    openapi_version: Optional[str] = None, #for logging
) -> dict:
    """
    Generic runner used by all modes.

    Thread behavior:
      - Default: create a new thread for this run unit
      - Advanced: reuse an existing thread if caller provides:
        {"thread_id": "...", "version_id": "...", "document_store_id": "...", "thread_name": "optional"}
    """

    # if thread id exists, we link to old thread else we create new thread
    if existing_thread_ids:
        ids = {
            "thread_id": existing_thread_ids.get("thread_id"),
            "version_id": existing_thread_ids.get("version_id"),
            "document_store_id": existing_thread_ids.get("document_store_id"),
        }
        if not all(ids.values()):
            raise ValueError("existing_thread_ids must include thread_id, version_id, document_store_id")
        thread_name = str(existing_thread_ids.get("thread_name") or f"reuse_{ids['thread_id']}")
        created_new_thread = False
    else:
        thread_name = make_thread_name(f"cora_{name}")
        ids = create_thread(
            sess=sess,
            token=token,
            cfg=cfg,
            document_id=document_id,
            version_name=version_name,
            thread_name=thread_name,
            project_id=project_id,
            language=language,
        )
        created_new_thread = True

    working_part = document_part or cfg.document_part

    # Registry (useful for debugging/quick reuse)
    if created_new_thread:
        register_thread(cfg, name, ids, document_id, version_name, language, working_part, thread_name)

    run_log = init_run_log(cfg, name, mode, ids, thread_name, document_id, version_name, working_part, openapi_version)
    run_log["thread"]["created_new"] = created_new_thread

    if project_id:
        try:
            pj =  get_project_cached(sess, token, cfg, project_id)
            run_log["project"] = extract_project_summary(pj)
        except Exception as e:
            run_log["project"] = {"project_id": project_id, "error": str(e)}
    

    # Prompt bundle is run-level (not per turn)
    try:
        run_log["prompts"] = capture_prompts_bundle(sess, token, cfg, custom_prompts or {})
    except Exception as e:
        run_log["prompts"] = {"error": str(e), "custom_prompts_used": {}, "system_prompts": {}}

    for idx, q in enumerate(questions, start=1):
        print(f"\n[{idx}/{len(questions)}] You: {q}")

        resp = ask_llm_stream(
            sess=sess,
            token=token,
            cfg=cfg,
            ids=ids,
            document_id=document_id,
            version_name=version_name,
            question=q,
            document_part=working_part,
            language=language,
            custom_prompts=custom_prompts,
        )

        answer_text = resp.get("answer_text") or ""
        links = resp.get("links", []) or []
        summary_memory = resp.get("summary")
        grounding_sources = resp.get("grounding_sources", []) or []
        grounding_claims = resp.get("grounding_claims", []) or []
        images_meta = resp.get("images_meta")
        llm_metadata = resp.get("metadata")

        # Grounding sources (non-blocking)
        grounding_sources_details = []
        grounding_sources_resolve_error = None
        try:
            ids_by_type = extract_ids_by_type(grounding_sources)
            grounding_sources_details = resolve_grounding_sources_cached(sess, token, cfg, ids_by_type)
        except Exception as e:
            grounding_sources_resolve_error = str(e)
            print("⚠️ grounding_sources resolve skipped (non-blocking):", grounding_sources_resolve_error)

        turn = {
            "ts": now_ts(),
            "resp": resp,
            "question": q,
            "answer_text": answer_text,
            "links": links,
            "summary_memory": summary_memory,
            "grounding_sources": grounding_sources,
            "grounding_sources_details": grounding_sources_details,
            "grounding_sources_resolve_error": grounding_sources_resolve_error,
            "grounding_claims": grounding_claims,            
            "images_meta": images_meta,
            "llm_metadata": llm_metadata,
            "errors": resp.get("errors", []),
            "document_part_used": resp.get("document_part_used"),
            "request_payload": resp.get("request_payload"),
            "raw_stream_lines": resp.get("raw_lines", []),
            "stream_json_objects": resp.get("json_objects", []),
        }
        run_log["turns"].append(turn)

        # Write periodically
        if idx == 1 or idx == len(questions) or (cfg.write_every_n_turns > 0 and idx % cfg.write_every_n_turns == 0):
            write_run_log(cfg, thread_name, run_log)

        print("Assistant:", answer_text[:800] + ("..." if len(answer_text) > 800 else ""))

    # Message history snapshot (best-effort)
    run_log["debug_info"]["messages_snapshot"] = fetch_messages_best_effort(
        sess=sess,
        token=token,
        cfg=cfg,
        ids=ids,
        document_id=document_id,
        openapi=openapi,
        limit=1000,
    )
    run_log["run_completed_at"] = now_ts()

    write_run_log(cfg, thread_name, run_log)
    return run_log


# ---- Mode-specific wrappers ----

def run_discovery(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    *,
    name: str,
    questions: List[str],
    project_id: Optional[str] = None,
    custom_prompts: Optional[Dict[str, str]] = None,
    existing_thread_ids: Optional[Dict[str, str]] = None,
    openapi: Optional[dict] = None, # for logging
    openapi_version: Optional[str] = None, # for logging
) -> dict:
    """Discovery mode: uses discovery thread doc_id."""
    return run_mode_questions(
        sess, token, cfg,
        mode="discovery",
        name=name,
        questions=questions,
        document_id=cfg.discovery_thread_doc_id,
        version_name="Legal act",
        # project_id=project_id,
        custom_prompts=custom_prompts,
        openapi=openapi,
        openapi_version=openapi_version,
        existing_thread_ids=existing_thread_ids,
    )


def run_pct(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    *,
    name: str,
    questions: List[str],
    project_id: str,
    custom_prompts: Optional[Dict[str, str]] = None,
    existing_thread_ids: Optional[Dict[str, str]] = None,
    openapi: Optional[dict] = None, # for logging
    openapi_version: Optional[str] = None, # for logging
    
) -> dict:
    """PCT mode: requires project_id and uses pct thread doc_id."""
    return run_mode_questions(
        sess, token, cfg,
        mode="pct",
        name=name,
        questions=questions,
        document_id=cfg.project_context_thread_doc_id,
        version_name="Legal act",
        project_id=project_id,
        custom_prompts=custom_prompts,
        openapi=openapi,
        openapi_version=openapi_version,
        existing_thread_ids=existing_thread_ids,
    )


def run_document(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    *,
    name: str,
    questions: List[str],
    document_id: str,
    version_name: str,
    language: str,
    document_part: Optional[str] = None,
    project_id: Optional[str] = None,
    custom_prompts: Optional[Dict[str, str]] = None,
    existing_thread_ids: Optional[Dict[str, str]] = None,
    openapi: Optional[dict] = None, # for logging
    openapi_version: Optional[str] = None, # for logging
) -> dict:
    """Single document mode: requires document_id + version_name."""
    
    return run_mode_questions(
        sess, token, cfg,
        mode="document",
        name=name,
        questions=questions,
        document_id=document_id,
        version_name=version_name,
        language=language,
        document_part= document_part,
        project_id=project_id,
        custom_prompts=custom_prompts,
        openapi=openapi,
        openapi_version=openapi_version,
        existing_thread_ids=existing_thread_ids,
    )


def run_user_document(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    *,
    name: str,
    questions: List[str],
    document_id: str,
    version_name: str,
    project_id: Optional[str] = None,
    custom_prompts: Optional[Dict[str, str]] = None,
    existing_thread_ids: Optional[Dict[str, str]] = None,
    openapi: Optional[dict] = None, # for logging
    openapi_version: Optional[str] = None, # for logging    
) -> dict:
    """User document mode: same runner; expected that document_id points to a user doc on BE."""
    return run_mode_questions(
        sess, token, cfg,
        mode="user_document",
        name=name,
        questions=questions,
        document_id=document_id,
        version_name=version_name,
        project_id=project_id,
        custom_prompts=custom_prompts,
        openapi=openapi,
        openapi_version=openapi_version,
        existing_thread_ids=existing_thread_ids,
    )
