from __future__ import annotations

from typing import Any, Dict, Optional

import requests

from ..config import Config
from ..auth import login
from ..utils import ensure_dir, die
from ..api.openapi import fetch_openapi
from ..api.projects import build_project_id_map, resolve_project_id_for_unit, get_project, extract_project_summary
from ..api.projects import parse_project_id
from .spec import iter_run_units, normalize_custom_prompts, validate_spec
from .modes import run_discovery, run_pct, run_document, run_user_document


def get_doc_meta_for_unit(cfg: Config, unit: Dict[str, Any]) -> Dict[str, str]:
    """
    Compatibility with legacy schema:
      - mode: discovery/pct/document/user_document
      - document_id may be empty for discovery/pct
    """
    document_id = (unit.get("document_id") or "").strip()
    version_name = (unit.get("version_name") or "").strip()
    mode = (unit.get("mode") or "").strip()

    if not mode and not document_id:
        die(f"Missing mode & document_id in unit '{unit.get('name')}'")

    if mode == "discovery" and not document_id:
        document_id = cfg.discovery_thread_doc_id
    elif mode == "pct" and not document_id:
        document_id = cfg.project_context_thread_doc_id

    if not document_id:
        die(f"Missing document_id in unit '{unit.get('name')}'")

    if not version_name:
        die(f"Missing version_name in unit '{unit.get('name')}'")

    return {"document_id": document_id, "version_name": version_name, "mode": mode}


def run_from_spec(spec: Dict[str, Any]) -> None:
    validate_spec(spec)

    cfg = Config.from_env()
    ensure_dir(cfg.results_dir)

    print(f"🌍 CORA_ENV={cfg.cora_env} | BASE_URL={cfg.base_url}")

    sess = requests.Session()
    token = login(sess, cfg)

    openapi = fetch_openapi(sess, token, cfg)
    openapi_version = "UNKNOWN"
    if openapi:
        info = openapi.get("info") or {}
        openapi_version = info.get("version") or "UNKNOWN"
        print("✅ CORA - OpenAPI loaded.", openapi_version)
    else:
        print("⚠️ CORA - OpenAPI not available (continuing).")

    # Projects
    project_id_map: Dict[str, str] = {}
    if isinstance(spec.get("projects"), list) and spec["projects"]:
        project_id_map = build_project_id_map(sess, token, cfg, spec)
        print("✅ Project map:", project_id_map)
    else:
        print("ℹ️ No projects listed in spec; running standalone threads.")

    # Global custom prompts
    global_custom_prompts = normalize_custom_prompts(spec.get("custom_prompts"), "spec.custom_prompts")

    units = iter_run_units(spec)
    if not units:
        die("Spec must contain either 'question_sets' (legacy) or 'threads' (new).")

    for unit in units:
        name = unit.get("name") or "unnamed_set"
        questions = unit.get("questions") or []
        if not isinstance(questions, list) or not questions:
            print(f"⚠️ Skipping empty unit: {name}")
            continue

        project_id = resolve_project_id_for_unit(unit, project_id_map)

        doc_meta = get_doc_meta_for_unit(cfg, unit)
        mode = doc_meta["mode"] or "document"

        qs_level = normalize_custom_prompts(unit.get("custom_prompts"), f"unit[{name}].custom_prompts")
        qs_custom_prompts = {**global_custom_prompts, **qs_level}
        existing_thread_ids = unit.get("existing_thread_ids") or unit.get("thread_ids")

        print("\n==============================")
        print("Running:", name)
        print("Mode:", mode)
        print("Doc:", doc_meta)
        print("==============================")

        if mode == "discovery":
            run_discovery(
                sess, token, cfg,
                name=name,
                questions=[str(q) for q in questions],
                project_id=project_id,                     # - Optional
                custom_prompts=qs_custom_prompts,          # - Optional
                openapi=openapi,                           # - Optional
                openapi_version=openapi_version,           # - Optional
                existing_thread_ids=existing_thread_ids,   # - Optional
            )
        elif mode == "pct":
            if not project_id:
                die(f"Unit '{name}' is pct mode but no project_id/project_key was provided/resolved.")
            run_pct(
                sess, token, cfg,
                name=name,
                questions=[str(q) for q in questions],
                project_id=project_id,
                custom_prompts=qs_custom_prompts,          # - Optional
                openapi=openapi,                           # - Optional
                openapi_version=openapi_version,           # - Optional
                existing_thread_ids=existing_thread_ids,   # - Optional
            )
        elif mode == "user_document":
            run_user_document(
                sess, token, cfg,
                name=name,
                questions=[str(q) for q in questions],
                document_id=doc_meta["document_id"],
                version_name=doc_meta["version_name"],
                project_id=project_id,                     # - Optional
                custom_prompts=qs_custom_prompts,          # - Optional
                openapi=openapi,                           # - Optional
                openapi_version=openapi_version,           # - Optional
                existing_thread_ids=existing_thread_ids,   # - Optional
            )
        else:
            # default to document
            run_document(
                sess, token, cfg,
                name=name,
                questions=[str(q) for q in questions],
                document_id=doc_meta["document_id"],
                version_name=doc_meta["version_name"],
                language="EN",
                project_id=project_id,                     # - Optional
                custom_prompts=qs_custom_prompts,          # - Optional
                openapi=openapi,                           # - Optional
                openapi_version=openapi_version,           # - Optional
                existing_thread_ids=existing_thread_ids,   # - Optional
            )

    print("\n✅ Done.")
    print(f"Results folder:   {cfg.results_dir}")
