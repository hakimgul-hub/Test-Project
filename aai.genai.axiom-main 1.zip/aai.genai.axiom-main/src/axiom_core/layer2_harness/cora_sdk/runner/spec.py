from __future__ import annotations

import json
import uuid
from dataclasses import dataclass
from json import JSONDecodeError
from typing import Any, Dict, List

from ..utils import die


@dataclass
class RunUnit:
    name: str
    mode: str
    document_id: str
    version_name: str
    questions: List[str]
    project_key: str | None = None
    project_id: str | None = None
    custom_prompts: Dict[str, str] | None = None
    thread_id: str | None = None   # future: reuse existing thread


@dataclass
class RunSpec:
    raw: Dict[str, Any]
    projects: List[Dict[str, Any]]
    units: List[Dict[str, Any]]
    custom_prompts: Dict[str, str]


def load_spec(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except JSONDecodeError as e:
        die(
            f"Invalid JSON in '{path}'.\n"
            f"Reason: {e.msg}\n"
            f"Line {e.lineno}, column {e.colno} (char {e.pos}).\n"
            f"Tip: Check for trailing commas or comments."
        )
    except Exception as e:
        die(f"Failed to read '{path}': {e}")


def iter_run_units(spec: Dict[str, Any]) -> List[Dict[str, Any]]:
    if isinstance(spec.get("threads"), list):
        return [t for t in spec["threads"] if isinstance(t, dict)]
    if isinstance(spec.get("question_sets"), list):
        return [qs for qs in spec["question_sets"] if isinstance(qs, dict)]
    return []


def normalize_custom_prompts(v: Any, label: str) -> Dict[str, str]:
    if v is None:
        return {}
    if not isinstance(v, dict):
        die(f"{label} must be an object/dict: {{prompt_key: prompt_id}}")

    out: Dict[str, str] = {}
    for k, pid in v.items():
        pk = str(k).strip()
        pv = str(pid).strip() if pid is not None else ""
        if not pk:
            die(f"{label} contains empty prompt_key")
        if not pv:
            die(f"{label}[{pk}] has empty prompt_id")

        try:
            uuid.UUID(pv)
        except Exception:
            die(f"{label}[{pk}] prompt_id is not a valid UUID: {pv}")

        out[pk] = pv
    return out


def validate_spec(spec: Dict[str, Any]) -> None:
    if not isinstance(spec, dict):
        die("Spec must be a JSON object at top-level.")
    if not isinstance(spec.get("question_sets"), list) and not isinstance(spec.get("threads"), list):
        die("Spec must contain either 'question_sets' (legacy) or 'threads' (new).")
