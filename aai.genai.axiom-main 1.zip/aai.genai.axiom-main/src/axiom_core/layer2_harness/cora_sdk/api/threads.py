from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Any, Dict, Optional

import requests

from ..config import Config
from ..utils import auth_headers, dump_response, get_json_or_die, now_ts, safe_filename


def make_thread_name(prefix: str) -> str:
    return f"{prefix}_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}_{uuid.uuid4().hex[:6]}"


def create_thread(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    document_id: str,
    version_name: str,
    thread_name: str,
    project_id: Optional[str] = None,
    language: Optional[str] = None,
) -> Dict[str, str]:
    """
    Create a new thread. If project_id is provided, the thread is created inside the project.
    """
    url = f"{cfg.base_url}{cfg.api_prefix}/threads/"

    headers = auth_headers(token)
    headers["Content-Type"] = "application/json"

    payload: Dict[str, Any] = {
        "thread_name": thread_name,
        "version_name": version_name,
        "language": language or cfg.language,
        "document_id": document_id,
    }
    if project_id:
        payload["project_id"] = project_id

    if cfg.log_payloads:
        print("\n--- THREAD CREATE PAYLOAD ---")
        print("→ POST", url)
        print(json.dumps(payload, indent=2))

    r = sess.post(url, headers=headers, json=payload, timeout=cfg.timeout)
    print("→ POST", url, "[", r.status_code, "]")
    if r.status_code >= 400:
        dump_response(r, "THREAD CREATE FAILED")
        r.raise_for_status()

    data = get_json_or_die(r)
    ids = data.get("data", data)

    thread_id = ids.get("thread_id") or ids.get("id")
    version_id = ids.get("version_id")
    document_store_id = ids.get("document_store_id")

    if not (thread_id and version_id and document_store_id):
        raise RuntimeError("Thread created but IDs missing: " + json.dumps(data, indent=2))

    return {"thread_id": thread_id, "version_id": version_id, "document_store_id": document_store_id}


def load_registry(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"threads": []}


def upsert_registry(path: str, entry: Dict[str, Any]) -> None:
    reg = load_registry(path)
    threads = reg.get("threads", [])
    threads = [t for t in threads if t.get("thread_id") != entry.get("thread_id")]
    threads.append(entry)
    reg["threads"] = threads
    with open(path, "w", encoding="utf-8") as f:
        json.dump(reg, f, ensure_ascii=False, indent=2)


def register_thread(cfg: Config, question_set: str, ids: Dict[str, str], document_id: str, version_name: str, language: str, document_part: str, thread_name: str) -> None:
    upsert_registry(cfg.threads_registry, {
        "created_at": now_ts(),
        "question_set": question_set,
        "thread_name": thread_name,
        **ids,
        "document_id": document_id,
        "version_name": version_name,
        "language": language,
        "document_part": document_part,
    })
