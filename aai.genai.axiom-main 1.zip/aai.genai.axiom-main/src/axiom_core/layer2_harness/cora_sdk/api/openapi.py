from __future__ import annotations

import json
from typing import Any, Dict, Optional

import requests

from ..config import Config
from ..utils import auth_headers, is_json


def fetch_openapi(sess: requests.Session, token: Optional[str], cfg: Config) -> Optional[Dict[str, Any]]:
    url = f"{cfg.base_url}{cfg.api_prefix}/openapi.json"
    r = sess.get(url, headers=auth_headers(token), timeout=cfg.timeout)
    if r.status_code == 200 and is_json(r):
        return r.json()
    return None


def fetch_messages_best_effort(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    ids: Dict[str, str],
    document_id: str,
    openapi: Optional[Dict[str, Any]],
    limit: int = 1000,
) -> Any:
    """Best-effort message dump for debugging/evaluation."""
    if not openapi:
        print("ℹ️ OpenAPI missing; cannot discover message endpoints.")
        return None

    paths = openapi.get("paths", {})
    target_path = f"{cfg.api_prefix}/thread-versions/{{version_id}}/documents/{{document_id}}/messages"
    if target_path not in paths or "get" not in paths[target_path]:
        print("ℹ️ Messages endpoint not found in OpenAPI paths.")
        return None

    url = f"{cfg.base_url}{cfg.api_prefix}/thread-versions/{ids['version_id']}/documents/{document_id}/messages"
    headers = auth_headers(token)

    params_spec = paths[target_path]["get"].get("parameters", [])
    query_params = [p for p in params_spec if p.get("in") == "query"]
    required_q = [p["name"] for p in query_params if p.get("required")]

    print("\n--- MESSAGES FETCH (OpenAPI-guided) ---")
    print("URL:", url)
    print("Required query params:", required_q)

    candidate_params = []
    if "limit" in [p.get("name") for p in query_params]:
        candidate_params.append({"limit": limit})
        candidate_params.append({"limit": limit, "offset": 0})
    else:
        candidate_params.append({})

    for base in list(candidate_params):
        p = dict(base)
        for rq in required_q:
            if rq not in p:
                if rq.lower() in ("offset", "skip"):
                    p[rq] = 0
                elif rq.lower() in ("page",):
                    p[rq] = 1
                elif rq.lower() in ("pagesize", "page_size"):
                    p[rq] = min(200, limit)
        candidate_params.append(p)

    uniq = []
    seen = set()
    for p in candidate_params:
        key = tuple(sorted(p.items()))
        if key not in seen:
            seen.add(key)
            uniq.append(p)

    for params in uniq:
        r = sess.get(url, headers=headers, params=params, timeout=cfg.timeout)
        print("→ GET", r.url, "[", r.status_code, "]")
        if r.status_code == 200 and is_json(r):
            print("✅ Messages fetched.")
            return r.json()
        if r.status_code == 422 and is_json(r):
            try:
                print("⚠️ 422 detail:", json.dumps(r.json(), indent=2)[:1200])
            except Exception:
                pass

    print("ℹ️ Could not fetch messages; see 422 details above for required params.")
    return None
