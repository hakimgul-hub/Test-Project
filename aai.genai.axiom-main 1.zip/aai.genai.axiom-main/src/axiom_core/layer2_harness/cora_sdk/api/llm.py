from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import requests

from ..config import Config
from ..utils import auth_headers, dump_response


def ask_llm_stream(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    ids: Dict[str, str],
    document_id: str,
    version_name: str,
    question: str,
    document_part: str,
    language: Optional[str] = None,
    custom_prompts: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Calls the streaming endpoint and returns a parsed response.
    This wrapper keeps the stream parser in one place so modes can reuse it.
    """
    url = f"{cfg.base_url}{cfg.api_prefix}/llm-connect/ask-llm/stream"

    headers = auth_headers(token)
    headers["Content-Type"] = "application/json"
    headers["Accept"] = "*/*"

    payload: Dict[str, Any] = {
        "version_id": ids["version_id"],
        "document_trace": {
            "thread_id": ids["thread_id"],
            "document_store_id": ids["document_store_id"],
            "document_id": document_id,
            "document_version_name": version_name,
            "document_language": language or cfg.language,
            "document_part": document_part,
        },
        "question": question,
    }
    if custom_prompts:
        payload["custom_prompts"] = custom_prompts

    if cfg.log_payloads:
        print("\n--- STREAM REQUEST ---")
        print("URL:", url)
        print("document_part:", document_part)
        print("Payload:", json.dumps(payload, indent=2, ensure_ascii=False))

    r = sess.post(url, headers=headers, json=payload, stream=True, timeout=cfg.timeout)
    print("→ POST", url, "[", r.status_code, "]")
    if r.status_code >= 400:
        dump_response(r, "STREAM FAILED")
        r.raise_for_status()

    raw_lines: List[str] = []
    json_objects: List[Dict[str, Any]] = []
    errors: List[str] = []
    answer_chunks: List[str] = []

    links: List[Dict[str, Any]] = []
    references: List[Dict[str, Any]] = []
    grounding_sources: List[Any] = []
    images_meta: Any = None
    full_metadata: Any = None
    summary_memory: str = None

    def _extend_unique_dicts(dst: List[Dict[str, Any]], src: Any) -> None:
        if not isinstance(src, list):
            return
        for item in src:
            if isinstance(item, dict) and item not in dst:
                dst.append(item)

    def _collect_from_obj(obj: Dict[str, Any]) -> None:
        nonlocal answer_chunks, links, references, grounding_sources, images_meta, full_metadata, errors, summary_memory

        obj_type = obj.get("type")

        if obj_type == "error":
            c = obj.get("content")
            if isinstance(c, str) and c.strip():
                errors.append(c)

        if obj.get("success") is False:
            msg = obj.get("message") or obj.get("detail") or obj.get("error")
            if isinstance(msg, str) and msg.strip():
                errors.append(msg)

        if obj_type == "full_response":
            c = obj.get("content")
            if isinstance(c, dict):
                v = c.get("answer") or c.get("answer_text")
                if isinstance(v, str) and v.strip():
                    answer_chunks = [v]

                _extend_unique_dicts(links, c.get("links"))
                _extend_unique_dicts(references, c.get("references") or c.get("citations") or c.get("sources"))

                gs = c.get("grounding_sources")
                if isinstance(gs, list):
                    for item in gs:
                        if item not in grounding_sources:
                            grounding_sources.append(item)

                if "images_meta" in c:
                    images_meta = c.get("images_meta")
                if "metadata" in c:
                    full_metadata = c.get("metadata")
                if "summary" in c:
                    summary_memory = c.get("summary")

                inner_errs = c.get("errors")
                if isinstance(inner_errs, list):
                    for e in inner_errs:
                        if isinstance(e, dict):
                            m = e.get("message")
                            if isinstance(m, str) and m.strip():
                                errors.append(m)
                        elif isinstance(e, str) and e.strip():
                            errors.append(e)
            return

        if obj_type in ("token", "text", "delta", "chunk", "chat_response_stream"):
            c = obj.get("content")
            if isinstance(c, str) and c:
                answer_chunks.append(c)

        if obj_type == "answer":
            c = obj.get("content")
            if isinstance(c, str) and c.strip():
                answer_chunks.append(c)

        for key in ("answer_text", "answer", "response", "text", "message", "result", "output"):
            v = obj.get(key)
            if isinstance(v, str) and v.strip():
                answer_chunks = [v]
                break

        d = obj.get("data")
        if isinstance(d, dict):
            for key in ("answer_text", "answer", "response", "text", "message", "result", "output"):
                v = d.get(key)
                if isinstance(v, str) and v.strip():
                    answer_chunks = [v]
                    break

            _extend_unique_dicts(links, d.get("links"))
            _extend_unique_dicts(references, d.get("references") or d.get("citations") or d.get("sources"))

            gs = d.get("grounding_sources")
            if isinstance(gs, list):
                for item in gs:
                    if item not in grounding_sources:
                        grounding_sources.append(item)

            if images_meta is None and "images_meta" in d:
                images_meta = d.get("images_meta")
            if full_metadata is None and "metadata" in d:
                full_metadata = d.get("metadata")

        _extend_unique_dicts(links, obj.get("links"))
        _extend_unique_dicts(references, obj.get("references") or obj.get("citations") or obj.get("sources"))

    for line in r.iter_lines(decode_unicode=True):
        if not line:
            continue
        raw_lines.append(line)
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                json_objects.append(obj)
                _collect_from_obj(obj)
            elif isinstance(obj, list):
                for it in obj:
                    if isinstance(it, dict):
                        json_objects.append(it)
                        _collect_from_obj(it)
        except Exception:
            # Not a JSON line; ignore.
            pass

    answer_text = "".join(answer_chunks).strip()
    if not answer_text:
        answer_text = "\n".join(raw_lines).strip()

    errors = list(dict.fromkeys([e for e in errors if isinstance(e, str) and e.strip()]))

    return {
        "answer_text": answer_text,
        "links": links,
        "references": references,
        "grounding_sources": grounding_sources,
        "summary":summary_memory,
        "images_meta": images_meta,
        "metadata": full_metadata,
        "errors": errors,
        "raw_lines": raw_lines,
        "json_objects": json_objects,
        "http_status": r.status_code,
        "request_payload": payload,
        "document_part_used": document_part,
    }
