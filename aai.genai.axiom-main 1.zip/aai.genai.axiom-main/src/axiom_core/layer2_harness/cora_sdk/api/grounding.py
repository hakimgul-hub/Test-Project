from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import requests

from ..config import Config
from ..utils import auth_headers, dump_response, get_json_or_die


# Cache key: (source_type, chunk_id)
GROUNDING_CACHE: Dict[Tuple[str, str], Dict[str, Any]] = {}


def extract_ids_by_type(grounding_sources: Any) -> Dict[str, List[str]]:
    """
    Input from LLM stream:
      [
        {"chunk_id":"...", "doc_type":"library", ...},
        {"chunk_id":"...", "doc_type":"user", ...},
      ]

    Output:
      {"library":[...], "user":[...]}
    """
    grouped: Dict[str, List[str]] = {}
    if not isinstance(grounding_sources, list):
        return grouped

    seen_per_type: Dict[str, set] = {}

    for item in grounding_sources:
        if not isinstance(item, dict):
            continue

        chunk_id = str(item.get("chunk_id") or "").strip()
        source_type = str(item.get("doc_type") or item.get("source_type") or "").strip().lower()

        if not chunk_id or not source_type:
            continue

        if source_type not in grouped:
            grouped[source_type] = []
            seen_per_type[source_type] = set()

        if chunk_id not in seen_per_type[source_type]:
            seen_per_type[source_type].add(chunk_id)
            grouped[source_type].append(chunk_id)

    return grouped


def fetch_grounding_sources(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    ids_by_type: Dict[str, List[str]],
) -> List[Dict[str, Any]]:
    """
    New API payload shape:
      {"grounding_sources":[{"source_type":"library","ids":[...]}, ...]}
    """
    url = f"{cfg.base_url}{cfg.api_prefix}/grounding-sources/"

    # Build payload: list of {source_type, ids}
    grounding_sources_payload: List[Dict[str, Any]] = []
    for source_type, ids in (ids_by_type or {}).items():
        st = str(source_type or "").strip().lower()
        if not st or not ids:
            continue

        # De-dupe per type (defensive)
        seen = set()
        clean_ids: List[str] = []
        for cid in ids:
            c = str(cid or "").strip()
            if c and c not in seen:
                seen.add(c)
                clean_ids.append(c)

        if clean_ids:
            grounding_sources_payload.append({"source_type": st, "ids": clean_ids})

    if not grounding_sources_payload:
        return []

    payload = {"grounding_sources": grounding_sources_payload}

    headers = auth_headers(token)
    headers["Content-Type"] = "application/json"
    headers["Accept"] = "application/json"

    if cfg.log_payloads:
        print("\n--- GROUNDING SOURCES PAYLOAD ---")
        print("→ POST", url)
        # avoid importing json globally just for this; keep it readable
        import json as _json
        print(_json.dumps(payload, indent=2))

    r = sess.post(url, headers=headers, json=payload, timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "GROUNDING SOURCES FAILED")
        r.raise_for_status()

    j = get_json_or_die(r)

    # Tolerant response wrappers
    data = j.get("data", j) if isinstance(j, dict) else {}
    if not isinstance(data, dict):
        return []

    gs = data.get("grounding_sources") or data.get("sources") or data.get("items") or []
    if not isinstance(gs, list):
        return []

    return [x for x in gs if isinstance(x, dict)]


def resolve_grounding_sources_cached(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    ids_by_type: Dict[str, List[str]],
) -> List[Dict[str, Any]]:
    """
    Cache key: (source_type, chunk_id)
    Returns flattened results in stable order (type iteration order + id order).
    """
    # Requested keys in order
    ordered_keys: List[Tuple[str, str]] = []
    for source_type, ids in (ids_by_type or {}).items():
        st = str(source_type or "").strip().lower()
        if not st:
            continue
        for cid in ids or []:
            c = str(cid or "").strip()
            if c:
                ordered_keys.append((st, c))

    if not ordered_keys:
        return []

    # Find missing keys
    missing_by_type: Dict[str, List[str]] = {}
    for st, cid in ordered_keys:
        if (st, cid) not in GROUNDING_CACHE:
            missing_by_type.setdefault(st, []).append(cid)

    # Fetch missing in one call
    if missing_by_type:
        fetched = fetch_grounding_sources(sess, token, cfg, missing_by_type)

        # Cache returned items
        for item in fetched:
            cid = str(item.get("chunk_id") or item.get("id") or "").strip()
            st = str(item.get("source_type") or item.get("doc_type") or "").strip().lower()

            # If BE doesn't return type, we cannot safely cache by (type,id).
            if cid and st:
                GROUNDING_CACHE[(st, cid)] = item

    # Return in requested order
    out: List[Dict[str, Any]] = []
    for st, cid in ordered_keys:
        obj = GROUNDING_CACHE.get((st, cid))
        if obj:
            out.append(obj)

    return out
