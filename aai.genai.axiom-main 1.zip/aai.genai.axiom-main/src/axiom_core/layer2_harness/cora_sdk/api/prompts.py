from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests

from ..config import Config
from ..utils import auth_headers, dump_response, get_json_or_die


# Simple in-memory caches (avoid repeated calls)
_USER_PROMPT_CACHE: Dict[str, Dict[str, Any]] = {}        # prompt_id -> prompt object
_SYSTEM_PROMPT_LIST_CACHE: Optional[List[Dict[str, Any]]] = None  # list of prompt key metadata
_SYSTEM_PROMPT_DETAILS_CACHE: Dict[str, Dict[str, Any]] = {}      # (prompt_key|version) -> details


def list_user_prompts(sess: requests.Session, token: Optional[str], cfg: Config) -> List[Dict[str, Any]]:
    url = f"{cfg.base_url}{cfg.api_prefix}/prompts/"
    r = sess.get(url, headers=auth_headers(token), timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "LIST USER PROMPTS FAILED")
        r.raise_for_status()
    j = get_json_or_die(r)
    data = j.get("data", j) if isinstance(j, dict) else {}
    if isinstance(data, dict) and isinstance(data.get("items"), list):
        return [x for x in data["items"] if isinstance(x, dict)]
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict) and isinstance(data.get("data"), list):
        return [x for x in data["data"] if isinstance(x, dict)]
    return []


def get_user_prompt(sess: requests.Session, token: Optional[str], cfg: Config, prompt_id: str) -> Dict[str, Any]:
    pid = str(prompt_id or "").strip()
    if not pid:
        return {}
    if pid in _USER_PROMPT_CACHE:
        return _USER_PROMPT_CACHE[pid]

    url = f"{cfg.base_url}{cfg.api_prefix}/prompts/{pid}"
    r = sess.get(url, headers=auth_headers(token), timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "GET USER PROMPT FAILED")
        r.raise_for_status()

    j = get_json_or_die(r)
    data = j.get("data", j) if isinstance(j, dict) else {}
    if isinstance(data, dict):
        _USER_PROMPT_CACHE[pid] = data
        return data
    return {}


def list_llm_connect_prompts(sess: requests.Session, token: Optional[str], cfg: Config) -> List[Dict[str, Any]]:
    global _SYSTEM_PROMPT_LIST_CACHE
    if _SYSTEM_PROMPT_LIST_CACHE is not None:
        return _SYSTEM_PROMPT_LIST_CACHE

    url = f"{cfg.base_url}{cfg.api_prefix}/prompts/llm-connect"
    r = sess.get(url, headers=auth_headers(token), timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "LIST LLM-CONNECT PROMPTS FAILED")
        r.raise_for_status()

    j = get_json_or_die(r)
    data = j.get("data", j) if isinstance(j, dict) else {}
    if isinstance(data, list):
        _SYSTEM_PROMPT_LIST_CACHE = [x for x in data if isinstance(x, dict)]
    elif isinstance(data, dict) and isinstance(data.get("items"), list):
        _SYSTEM_PROMPT_LIST_CACHE = [x for x in data["items"] if isinstance(x, dict)]
    else:
        _SYSTEM_PROMPT_LIST_CACHE = []
    return _SYSTEM_PROMPT_LIST_CACHE


def get_llm_connect_prompt_details(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    prompt_key: str,
    version: Optional[str] = None,
) -> Dict[str, Any]:
    pk = str(prompt_key or "").strip()
    if not pk:
        return {}
    v = (version or cfg.system_prompt_version_default).strip() or cfg.system_prompt_version_default
    cache_key = f"{pk}|{v}"
    if cache_key in _SYSTEM_PROMPT_DETAILS_CACHE:
        return _SYSTEM_PROMPT_DETAILS_CACHE[cache_key]

    url = f"{cfg.base_url}{cfg.api_prefix}/prompts/llm-connect/{pk}"
    r = sess.get(url, headers=auth_headers(token), params={"version": v}, timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "GET LLM-CONNECT PROMPT DETAILS FAILED")
        r.raise_for_status()

    j = get_json_or_die(r)
    data = j.get("data", j) if isinstance(j, dict) else {}
    if isinstance(data, dict):
        _SYSTEM_PROMPT_DETAILS_CACHE[cache_key] = data
        return data
    return {}


def _extract_prompt_text(obj: Dict[str, Any]) -> Optional[str]:
    # Different backends may use different keys
    for k in ("prompt_text", "text", "template", "content"):
        v = obj.get(k)
        if isinstance(v, str) and v.strip():
            return v
    # Sometimes nested
    inner = obj.get("prompt") or obj.get("data")
    if isinstance(inner, dict):
        for k in ("prompt_text", "text", "template", "content"):
            v = inner.get(k)
            if isinstance(v, str) and v.strip():
                return v
    return None


def capture_prompts_bundle(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    custom_prompts: Dict[str, str],
) -> Dict[str, Any]:
    """
    Returns a dictionary to store inside results.

    Output shape:
    {
      "custom_prompts_used": {
         "<prompt_key_from_spec>": {"prompt_id": "...", "prompt_key": "...", "prompt_text": "...", "raw": {...}}
      },
      "system_prompts": {
         "<system_prompt_key>": {"version":"v1", "prompt_text":"...", "raw": {...}}
      }
    }
    """
    out: Dict[str, Any] = {"custom_prompts_used": {}, "system_prompts": {}}

    # 1) Custom prompts (by prompt_id)
    if cfg.capture_custom_prompt_text and custom_prompts:
        for spec_key, prompt_id in custom_prompts.items():
            pid = str(prompt_id or "").strip()
            if not pid:
                continue
            try:
                obj = get_user_prompt(sess, token, cfg, pid)
                txt = _extract_prompt_text(obj) if cfg.capture_custom_prompt_text else None
                out["custom_prompts_used"][spec_key] = {
                    "prompt_id": pid,
                    "prompt_key": obj.get("prompt_key") or spec_key,
                    "prompt_text": txt,
                    "raw": obj,
                }
            except Exception as e:
                out["custom_prompts_used"][spec_key] = {
                    "prompt_id": pid,
                    "error": str(e),
                }

    # 2) System prompts (llm-connect)
    if cfg.capture_system_prompts:
        try:
            system_list = list_llm_connect_prompts(sess, token, cfg)
        except Exception as e:
            out["system_prompts_error"] = str(e)
            system_list = []

        # Store metadata list too (useful even if we skip text)
        out["system_prompts_index"] = system_list

        if cfg.capture_system_prompt_text:
            for meta in system_list:
                pk = str(meta.get("prompt_key") or meta.get("key") or "").strip()
                if not pk:
                    continue
                try:
                    # Prefer meta-provided version if present, otherwise default
                    version = meta.get("version") or meta.get("default_version") or cfg.system_prompt_version_default
                    details = get_llm_connect_prompt_details(sess, token, cfg, pk, version=version)
                    txt = _extract_prompt_text(details)
                    out["system_prompts"][pk] = {
                        "version": version,
                        "prompt_text": txt,
                        "raw": details,
                    }
                except Exception as e:
                    out["system_prompts"][pk] = {"error": str(e)}

    return out
