from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests

from ..config import Config
from ..utils import auth_headers, dump_response, get_json_or_die, die


def _canon_attached_doc(d: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Convert JSON attach_documents item to backend attached_documents item."""
    if not isinstance(d, dict):
        return None
    doc_id = (d.get("document_id") or "").strip()
    doc_type = (d.get("document_type") or "library").strip()
    language = (d.get("language") or "").strip()
    version_name = (d.get("version_name") or "").strip()

    if not doc_id:
        return None

    out = {"document_type": doc_type, "document_id": doc_id}
    if version_name:
        out["version_name"] = version_name
    if language:
        out["language"] = language
    return out


def _dedupe_attached_docs(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = set()
    out: List[Dict[str, Any]] = []
    for x in items or []:
        if not isinstance(x, dict):
            continue
        key = (
            (x.get("document_type") or "").strip(),
            (x.get("document_id") or "").strip(),
            (x.get("version_name") or "").strip(),
            (x.get("language") or "").strip(),
        )
        if key in seen:
            continue
        seen.add(key)
        out.append(x)
    return out


def get_project(sess: requests.Session, token: Optional[str], cfg: Config, project_id: str) -> Dict[str, Any]:
    url = f"{cfg.base_url}{cfg.api_prefix}/projects/{project_id}"
    r = sess.get(url, headers=auth_headers(token), timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "GET PROJECT FAILED")
        r.raise_for_status()
    return get_json_or_die(r)

PROJECT_CACHE: Dict[str, Dict[str, Any]] = {}
def get_project_cached(sess: requests.Session, token: Optional[str], cfg: Config, project_id: str) -> Dict[str, Any]:
    if project_id in PROJECT_CACHE:
        return PROJECT_CACHE[project_id]
    pj = get_project(sess, token, cfg, project_id)
    PROJECT_CACHE[project_id] = pj
    return pj

def extract_project_summary(project_json: Dict[str, Any]) -> Dict[str, Any]:
    data = project_json.get("data", project_json) if isinstance(project_json, dict) else {}
    if not isinstance(data, dict):
        return {}
    return {
        "project_id": data.get("project_id"),
        "project_name": data.get("project_name"),
        "description": data.get("description"),
        "instructions": data.get("instructions"),
        "thread_count": data.get("thread_count"),
        "attached_documents": data.get("attached_documents") or [],
        "created_at": data.get("created_at"),
        "updated_at": data.get("updated_at"),
    }


def patch_project_attached_documents(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    project_id: str,
    attached_documents: List[Dict[str, Any]],
) -> Dict[str, Any]:
    url = f"{cfg.base_url}{cfg.api_prefix}/projects/{project_id}"
    headers = auth_headers(token)
    headers["Content-Type"] = "application/json"

    payload = {"attached_documents": attached_documents}

    if cfg.log_payloads:
        import json as _json
        print("\n--- PROJECT PATCH PAYLOAD ---")
        print("→ PATCH", url)
        print(_json.dumps(payload, indent=2))

    r = sess.patch(url, headers=headers, json=payload, timeout=cfg.timeout, allow_redirects=False)
    if r.status_code >= 400:
        dump_response(r, "PROJECT PATCH FAILED")
        r.raise_for_status()
    return get_json_or_die(r)


def ensure_project_documents_attached(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    project_id: str,
    attach_documents: Any,
) -> Dict[str, Any]:
    """
    Merge existing attached_documents + requested attach_documents and PATCH.
    """
    if not attach_documents:
        return {}

    if not isinstance(attach_documents, list):
        die("projects[].attach_documents must be a list.")

    requested: List[Dict[str, Any]] = []
    for d in attach_documents:
        cd = _canon_attached_doc(d)
        if cd:
            requested.append(cd)

    requested = _dedupe_attached_docs(requested)
    if not requested:
        return {}

    current = get_project(sess, token, cfg, project_id)
    current_data = current.get("data", current) if isinstance(current, dict) else {}
    existing = current_data.get("attached_documents") or []
    if not isinstance(existing, list):
        existing = []

    existing_clean: List[Dict[str, Any]] = []
    for d in existing:
        if not isinstance(d, dict):
            continue

        doc_id = str(d.get("document_id") or "").strip()
        if not doc_id:
            continue

        existing_item = {"document_type": str(d.get("document_type") or "library").strip(), "document_id": doc_id}

        vn = str(d.get("version_name") or "").strip()
        lg = str(d.get("language") or "").strip()
        if vn:
            existing_item["version_name"] = vn
        if lg:
            existing_item["language"] = lg

        existing_clean.append(existing_item)

    merged = _dedupe_attached_docs(existing_clean + requested)

    existing_keys = set((x.get("document_type"), x.get("document_id"), x.get("version_name", ""), x.get("language", "")) for x in existing_clean)
    merged_keys = set((x.get("document_type"), x.get("document_id"), x.get("version_name", ""), x.get("language", "")) for x in merged)
    if merged_keys == existing_keys:
        print(f"ℹ️ Project {project_id}: attached_documents already up to date.")
        return current

    updated = patch_project_attached_documents(sess, token, cfg, project_id, merged)
    print(f"✅ Project {project_id}: attached_documents patched ({len(merged)} total).")
    return updated


def create_project(
    sess: requests.Session,
    token: Optional[str],
    cfg: Config,
    project_name: str,
    description: str = "",
    instructions: str = "",
) -> Dict[str, Any]:
    url = f"{cfg.base_url}{cfg.api_prefix}/projects/"
    headers = auth_headers(token)
    headers["Content-Type"] = "application/json"

    payload: Dict[str, Any] = {"project_name": project_name}
    if description:
        payload["description"] = description
    if instructions:
        payload["instructions"] = instructions

    r = sess.post(url, json=payload, headers=headers, timeout=cfg.timeout)
    if r.status_code >= 400:
        dump_response(r, "PROJECT CREATE FAILED")
        r.raise_for_status()
    return get_json_or_die(r)


def parse_project_id(v: Any) -> Optional[str]:
    if v is None:
        return None
    s = str(v).strip()
    if not s or s.lower() in ("null", "none"):
        return None
    return s


def build_project_id_map(sess: requests.Session, token: Optional[str], cfg: Config, spec: Dict[str, Any]) -> Dict[str, str]:
    """
    Returns: { project_key: project_id }
    - Existing projects: project_id provided. project_key optional.
    - Runtime projects: project_id null + create_if_missing=true => must have project_key; create and map.
    """
    projects = spec.get("projects") or []
    if not isinstance(projects, list):
        die("'projects' must be a list if provided.")

    project_id_map: Dict[str, str] = {}

    for i, p in enumerate(projects):
        if not isinstance(p, dict):
            continue

        project_key = (p.get("project_key") or p.get("project_ref") or "").strip()
        project_id = parse_project_id(p.get("project_id"))
        create_if_missing = bool(p.get("create_if_missing", False))

        if project_id:
            ensure_project_documents_attached(sess, token, cfg, project_id, p.get("attach_documents"))
            if project_key:
                project_id_map[project_key] = project_id
            continue

        if create_if_missing:
            if not project_key:
                die(f"projects[{i}] has create_if_missing=true but missing project_key.")
            project_name = (p.get("project_name") or "").strip()
            if not project_name:
                die(f"projects[{i}] has create_if_missing=true but missing project_name.")

            created = create_project(
                sess=sess,
                token=token,
                cfg=cfg,
                project_name=project_name,
                description=(p.get("description") or "").strip(),
                instructions=(p.get("instructions") or "").strip(),
            )

            created_data = created.get("data", created) if isinstance(created, dict) else {}
            new_id = parse_project_id(created_data.get("project_id") or created_data.get("id"))
            if not new_id:
                die(f"Project '{project_key}' created but backend returned no project_id:\n{created}")

            ensure_project_documents_attached(sess, token, cfg, new_id, p.get("attach_documents"))
            project_id_map[project_key] = new_id
            print(f"✅ Created project '{project_key}' -> {new_id}")
            continue

        print(f"ℹ️ projects[{i}] not resolved (project_id missing and create_if_missing=false).")

    return project_id_map


def resolve_project_id_for_unit(unit: Dict[str, Any], project_id_map: Dict[str, str]) -> Optional[str]:
    pid = parse_project_id(unit.get("project_id"))
    if pid:
        return pid

    pkey = (unit.get("project_key") or unit.get("project_ref") or "").strip()
    if pkey:
        resolved = project_id_map.get(pkey)
        if not resolved:
            die(f"Unit references project_key '{pkey}' but no project with that key was created/resolved.")
        return resolved

    return None
