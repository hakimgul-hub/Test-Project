# src/axiom_core/log_config.py
"""
Central logging configuration for AXIOM.
Call configure_logging() at process startup, before any code that logs (e.g. dependencies).
Used by the API (main.py), and can be used by Streamlit, scripts, or tests for consistent logs.
"""
import logging
import os
import sys

# ANSI colors for console (no colors in log files)
_RESET = "\033[0m"
_GRAY = "\033[90m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_RED = "\033[31m"
_CYAN = "\033[36m"
_MAGENTA = "\033[35m"

_LEVEL_COLORS = {
    logging.DEBUG: _GRAY,
    logging.INFO: _GREEN,
    logging.WARNING: _YELLOW,
    logging.ERROR: _RED,
    logging.CRITICAL: _RED,
}


class ColoredFormatter(logging.Formatter):
    """Formats log records with ANSI colors for level and logger name on supported terminals."""

    def __init__(self, fmt: str, datefmt: str | None = None, use_color: bool = True):
        super().__init__(fmt, datefmt=datefmt)
        self.use_color = use_color and sys.stderr.isatty()

    def format(self, record: logging.LogRecord) -> str:
        if not self.use_color:
            return super().format(record)
        orig_levelname, orig_name = record.levelname, record.name
        color = _LEVEL_COLORS.get(record.levelno, _RESET)
        record.levelname = f"{color}{orig_levelname}{_RESET}"
        record.name = f"{_CYAN}{orig_name}{_RESET}"
        try:
            return super().format(record)
        finally:
            record.levelname, record.name = orig_levelname, orig_name


def configure_logging(
    level: str | None = None,
    log_dir: str | None = None,
    format: str = "%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    datefmt: str = "%Y-%m-%d %H:%M:%S",
    force: bool = True,
) -> None:
    """
    Configure the root logger for console (and optionally file) output.
    Reads LOG_LEVEL and LOG_DIR from os.environ if not passed.
    """
    level = level or os.getenv("LOG_LEVEL", "INFO")
    log_level = getattr(logging, level.upper(), logging.INFO)
    log_dir = (log_dir or os.getenv("LOG_DIR", "")).strip()

    logging.basicConfig(
        level=log_level,
        format=format,
        datefmt=datefmt,
        force=force,
    )
    root = logging.getLogger()

    # Apply colored formatter to console (stream) handlers only
    for h in root.handlers:
        if isinstance(h, logging.StreamHandler):
            h.setFormatter(ColoredFormatter(format, datefmt=datefmt, use_color=True))

    if log_dir:
        try:
            os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(log_dir, "axiom.log")
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setLevel(log_level)
            fh.setFormatter(logging.Formatter(format, datefmt=datefmt))
            root.addHandler(fh)
        except Exception as e:
            root.warning("LOG_DIR set but file logging failed: %s", e)

    # Use the same format for Uvicorn loggers (they use their own by default)
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        uv_log = logging.getLogger(name)
        uv_log.handlers.clear()
        uv_log.propagate = True
        uv_log.setLevel(log_level)
