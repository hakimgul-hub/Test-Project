import os
import json
import datetime
import glob

# --- CONFIGURATION: Single source of truth from dependencies ---
try:
    from src.axiom_core.api.dependencies import (
        DATA_DIR,
        TEACHER_DIR,
        EXAMINER_DIR,
        JUDGE_DIR,
        VIVA_DIR,
    )
except ImportError:
    from axiom_core.api.dependencies import (
        DATA_DIR,
        TEACHER_DIR,
        EXAMINER_DIR,
        JUDGE_DIR,
        VIVA_DIR,
    )

# Streamlit UI writes to subfolders under the same data layout as API (Teacher/Examiner/Judge)
L1_DIR = os.path.join(TEACHER_DIR, "Streamlit")
L2_DIR = os.path.join(EXAMINER_DIR, "Streamlit")
L2A_DIR = VIVA_DIR
L3_DIR = os.path.join(JUDGE_DIR, "Streamlit")

# Ensure directories exist
for d in [L1_DIR, L2_DIR, L2A_DIR, L3_DIR]:
    os.makedirs(d, exist_ok=True)

# Maps UI Keys -> Actual Folder Paths (aligned with data/Teacher|Examiner|Judge|Viva)
LAYER_MAP = {
    "L1": L1_DIR,
    "L1_GENERATION": L1_DIR,
    "L2": L2_DIR,
    "L2_RESULT": L2_DIR,
    "L2A_VIVA": L2A_DIR,
    "L3": L3_DIR,
    "L3_REPORT": L3_DIR,
}

# ✅ FIX: Added 'parent_id' argument here
def save_artifact(layer, data, filename_suffix="", parent_id=None):
    """
    Saves a JSON artifact to the specific layer folder.
    """
    target_dir = LAYER_MAP.get(layer)
    
    if not target_dir:
        raise ValueError(f"Unknown Layer: '{layer}'. Allowed: {list(LAYER_MAP.keys())}")

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # Clean suffix for filename if provided
    if filename_suffix:
        clean_suffix = "".join([c for c in filename_suffix if c.isalnum() or c in (' ', '_', '-')]).strip()
        clean_suffix = clean_suffix.replace(" ", "_")
        filename = f"{clean_suffix}.json"
        
        # If suffix doesn't look like a full filename, append timestamp
        if not clean_suffix.startswith("Gen_") and not clean_suffix.startswith("L"):
             filename = f"{layer}_{timestamp}_{clean_suffix}.json"
    else:
        filename = f"{layer}_{timestamp}.json"
    
    # Ensure .json extension
    if not filename.endswith(".json"):
        filename += ".json"

    # ✅ FIX: Inject parent_id into the data if provided (Links L2 -> L1)
    if parent_id:
        data["parent_id"] = parent_id

    filepath = os.path.join(target_dir, filename)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        
    return filename

def list_artifacts(layer):
    """
    Returns a list of available files for a given layer, sorted by newest first.
    """
    target_dir = LAYER_MAP.get(layer)
    
    if not target_dir:
        found = False
        for key, path in LAYER_MAP.items():
            if layer in key:
                target_dir = path
                found = True
                break
        if not found:
            return []

    files = glob.glob(os.path.join(target_dir, "*.json"))
    files.sort(key=os.path.getmtime, reverse=True)
    return [os.path.basename(f) for f in files]

def load_artifact(filename, layer=None):
    """
    Loads a specific JSON file. 
    """
    # 1. Direct Lookup
    if layer and layer in LAYER_MAP:
        filepath = os.path.join(LAYER_MAP[layer], filename)
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)

    # 2. Global Search
    for folder_path in LAYER_MAP.values():
        filepath = os.path.join(folder_path, filename)
        if os.path.exists(filepath):
             with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
                
    return None