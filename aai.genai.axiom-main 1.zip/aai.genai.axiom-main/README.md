# AXIOM – Verification Platform for CORA

AXIOM is a verification and evaluation platform for **CORA** (an RAG/LLM system). It follows a **V-model** flow: generate exam-style questions (Teacher) → run them against CORA (Examiner / Interrogator) → grade answers (Judge).

---

## What it does

- **Layer 1 – Teacher:** Generates question sets (with expected answers) from documents or topics using configurable personas (e.g. Auditor, Consultant) and strategies (Strict Context, Discovery, etc.).
- **Layer 2 – Examiner:** Runs Teacher question sets against CORA (or other “candidates”) in different modes: **Discovery**, **Project**, **Single Document**, **User Document**. Produces transcripts (Q/A + citations).
- **Layer 2a – Interrogator:** Interactive “viva” session: a judge LLM asks CORA questions; you can save the session for later grading.
- **Layer 3 – Judge:** Grades Examiner/Interrogator transcripts (accuracy, grounding, failure categories) and produces structured reports.

Use cases: compliance auditing, certification runs, regression testing, and interactive evaluation of CORA.

---

## Data flow: Teacher → Examiner → Judge → Reports

Artifacts are stored under **`data/`** and passed between layers by **filename** or **relative path**:

1. **Teacher** (Layer 1) writes question sets to `data/Teacher/<mode>/` (e.g. `SingleDoc/`, `Project/`, `Discovery/`). Filename example: `Teacher_SDOC_2026-02-06_16h36_26_65bd33.json`.
2. **Examiner** (Layer 2) takes a Teacher **filename**, finds that file under `data/Teacher/`, runs CORA, and writes the candidate transcript to `data/Examiner/` (e.g. `cora_Auto_discovery_*.json`).
3. **Judge** (Layer 3) takes a **candidate file** (Examiner output) and a **reference file** (Teacher output), both as relative paths. It loads them from `data/Examiner/` and `data/Teacher/`, grades turn-by-turn, and writes a report to `data/Judge/<mode>/` (e.g. `Root/Judge_Report_20260206_1741_16a3.json`).
4. **Evaluation tab** lists reports via `GET /judge/results` and loads each with `GET /judge/report?path=...`; it displays scores, details, and can export PDF.

Config used along the way: **`src/config/llm_profiles.json`** (Teacher & Judge models), **`src/config/domain_profiles.json`** (domain for prompts), **`src/config/layer1_config.json`** (personas, modes), **`secrets.json`** / **`.env`** (CORA, API keys, MongoDB). See **[docs/DATA_FLOW_AND_ARTIFACTS.md](docs/DATA_FLOW_AND_ARTIFACTS.md)** for the full flow, file layouts, API endpoints, and config reference. For a full technical overview (modules, flows, MongoDB, LLMs), see **[docs/AXIOM_TECHNICAL_OVERVIEW.md](docs/AXIOM_TECHNICAL_OVERVIEW.md)**.

---

## Architecture

### AXIOM Product / System

End-to-end flow: artifacts (`data/`), verification (V-Model), runtime (UI + API), and external services (CORA, LLMs, MongoDB).

![AXIOM Product / System](docs/axiom-product-system.png)

### AXIOM – Repository Map

How the repo is organized: frontend (`axiom_ui`), backend (`axiom_core`), run outputs (`data/`), and config (profiles, CORA, Mongo, secrets).

![AXIOM – Repository Map](docs/axiom-repository-map.png)

---

## Repository structure

```
aai.genai.axiom/
├── README.md                 # This file
├── requirements.txt          # Python dependencies
├── data/                     # JSON artifacts (Teacher, Examiner, Judge)
├── scripts/                  # Verification, batch, debug (run from repo root)
│   ├── verify_full_pipeline.py   run_verification.py   run_certification_batch.py
│   ├── verify_master_release.py   test_models.py
│   ├── debug/   oneoff/   legacy/   # See scripts/README.md
├── src/
│   ├── axiom_core/           # Backend
│   │   ├── api/              # FastAPI app & routers (recommended entry)
│   │   ├── layer1_teacher/   # Question generation
│   │   ├── layer2_harness/   # CORA SDK & harness
│   │   └── layer3_judge/     # Grading engine
│   ├── axiom_ui/             # Frontends
│   │   ├── app.py            # Streamlit UI
│   │   └── src/              # React (Vite) UI
│   └── config/               # JSON configs (layer1, domain, LLM, Mongo)
├── docs/                     # DATA_FLOW_AND_ARTIFACTS.md, AXIOM_TECHNICAL_OVERVIEW.md, LLM_PROFILES_README.md
└── tests/
```

---

## Prerequisites

- **Python 3.10+**
- **Node.js 18+** (for React UI only)
- **(Optional)** [Ollama](https://ollama.com/) with a model (e.g. `llama3:latest`) for local Teacher/Judge
- **(Optional)** CORA instance and credentials for Examiner/Interrogator
- **(Optional)** MongoDB for document library

For **LLM setup** (local Ollama models and cloud API keys, where to edit profiles, and how the UI uses them), see **[docs/LLM_PROFILES_README.md](docs/LLM_PROFILES_README.md)**.

---

## Quick start (new users)

1. **Clone and install:**  
   `cd aai.genai.axiom && python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt`

2. **Run the API (no config required for health/docs):**  
   `PYTHONPATH=. uvicorn src.axiom_core.api.main:app --host 0.0.0.0 --port 8000`  
   Open http://localhost:8000 and http://localhost:8000/docs.

3. **Optional:** Create a `.env` in the repo root with `CORA_BASE_URL`, `CORA_USERNAME`, `CORA_PASSWORD` for Examiner; and/or `src/config/secrets.json` with a `cora_dev` object (see Configuration below). For Teacher/Judge with a local LLM, install Ollama and add a profile in `src/config/llm_profiles.json`.

---

## Installation

### 1. Clone and create a virtual environment

```bash
cd aai.genai.axiom
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
```

### 2. Install Python dependencies

```bash
pip install -r requirements.txt
```

This installs FastAPI, Uvicorn, Pydantic, Streamlit, and core deps. For **cloud LLMs and MongoDB** (optional), uncomment the relevant lines in `requirements.txt` or run:

```bash
pip install openai anthropic google-generativeai pymongo
```

### 3. (Optional) React UI dependencies

Only if you want the React dashboard:

```bash
cd src/axiom_ui && npm install && cd ../..
```

---

## Configuration

You can get started with **no config** (API health and docs work; Teacher/Judge need an LLM). For Examiner, Interrogator, and document library you need credentials.

- **CORA (Examiner / Interrogator):** Use **either** of the following.
  - **Option A – `.env` (repo root):** Set `CORA_BASE_URL`, `CORA_USERNAME`, `CORA_PASSWORD`. The harness and debug scripts read these.
  - **Option B – `src/config/secrets.json`:** Used by the API and Streamlit for Examiner/Interrogator. Create the file with:
    ```json
    {
      "cora_dev": {
        "base_url": "https://your-cora-instance.com",
        "username": "your-user",
        "password": "your-password"
      }
    }
    ```
  The API looks for `src/config/secrets.json` or `config/secrets.json` (under repo root). If both are missing, Examiner/Interrogator endpoints will fail until you add one. Do not commit real credentials; add `secrets.json` to `.gitignore` if you keep it under `src/config/`.

- **API keys (cloud LLMs):** Put `openai`, `anthropic`, `gemini` in `src/config/secrets.json`, or set `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, etc. in `.env`. The UI Settings tab can also write keys into `secrets.json`.

- **Environment (`.env` at repo root):** Used by the app and many scripts. Useful variables: `CORA_BASE_URL`, `CORA_USERNAME`, `CORA_PASSWORD`, `MONGO_URI`, `OPENAI_API_KEY`, `LOG_LEVEL`, `LOG_DIR`. If `MONGO_URI` is unset or empty, the document library is disabled (no connection attempted). `.env` is in `.gitignore`—do not commit credentials.

- **Logging (optional – save logs to a folder):** The API uses a central logging config (`src/axiom_core/log_config.py`). By default, logs go to the console only. To **also** write logs to a file, set `LOG_DIR` in `.env` (repo root) to a directory path (e.g. `logs` or `/var/log/axiom`). The app will create that directory if needed and write to `LOG_DIR/axiom.log` (same format as console; no ANSI colors in the file). Optionally set `LOG_LEVEL` (e.g. `DEBUG`, `INFO`, `WARNING`) to control verbosity. The `logs/` directory is in `.gitignore` when using a local `logs` folder.

- **MongoDB (optional – document library):** The app supports local or **cloud** MongoDB (e.g. Atlas). No code changes needed.
  1. **Connection:** Set `MONGO_URI` in `.env` (repo root). For a cloud dev DB use your provider’s connection string (e.g. `mongodb+srv://<user>:<password>@<cluster>.mongodb.net`). Do not commit credentials.
  2. **Profile:** `src/config/mongo_config.json` defines profiles `local`, `dev`, `prod`. Default is `dev`, which uses `MONGO_URI` and database `corax-dev`, collection `documents`. For production, set `active_profile` to `prod` and use `MONGO_URI_PROD`.
  3. **Database/collection:** Ensure the target DB has a `documents` collection (or match `collection_name` in the active profile). Documents are expected to have at least `id`/`_id`, `title` (or `document_name`), and `content`/`text`/`full_text`.
  4. **When things run:** `.env` is loaded at startup (API: when `dependencies` is first imported; Streamlit: when `app.py` runs; `mongo_loader`: when first imported). The MongoDB connection is created at that same time (API/Streamlit). If `MONGO_URI` is missing, the app does **not** fall back to `localhost:27017`; it leaves MongoDB disabled.

- **Local LLM:** If using Ollama, start it and pull a model, e.g. `ollama run llama3:latest`. The Teacher and Judge can use `local:llama3:latest` (or similar) when configured.

---

## How to run

All commands below assume you are in the **repository root** and the virtualenv is activated.

### Option A: API only (backend)

This is the **recommended** way to run the backend. The API serves the Teacher, Examiner, Interrogator, and Judge endpoints.

```bash
# From repo root
export PYTHONPATH=.
uvicorn src.axiom_core.api.main:app --host 0.0.0.0 --port 8000 --reload
```

Or:

```bash
python -m uvicorn src.axiom_core.api.main:app --host 0.0.0.0 --port 8000 --reload
```

- API: **http://localhost:8000**
- Health: **http://localhost:8000/**  
- Docs: **http://localhost:8000/docs**

### Option B: React UI (needs API)

1. Start the API (Option A).
2. In another terminal:

```bash
cd src/axiom_ui
npm run dev
```

- React app runs at the URL shown (e.g. **http://localhost:5173**).
- It talks to the API at **http://localhost:8000** (hardcoded in components; override via env if you add support).

### Option C: Streamlit UI

Streamlit can use the same API or internal imports. Run from repo root so that `src` is on the path:

```bash
# From repo root
export PYTHONPATH=src
streamlit run src/axiom_ui/app.py
```

- Streamlit opens in the browser (e.g. **http://localhost:8501**).
- Configure CORA and (optionally) MongoDB in the sidebar.

### Option D: Legacy server (not recommended)

`scripts/legacy/server.py` is a standalone FastAPI app that duplicates much of the API and currently has a **broken import** (`AxiomJudge` from a missing module). Prefer **Option A** unless you are fixing that server.

```bash
python scripts/legacy/server.py
# Serves on http://localhost:8000 (run from repo root)
```

---

## Testing

Run tests **from the repository root** with `PYTHONPATH` set so that `src.axiom_core` resolves:

```bash
# All tests (pytest discovers tests/)
PYTHONPATH=. pytest tests/ -v

# API smoke tests only (no live server; uses TestClient)
PYTHONPATH=. pytest tests/api/test_api_health.py -v

# Teacher layer test (requires API running and optional test_teacher_config.json)
PYTHONPATH=. pytest tests/api/test_teacher_layer.py -v
```

See **`tests/api/`** for API-level tests. Unit tests for Layer 1 (brains, generator) can be run via `tests/test_axiom.py` with `PYTHONPATH=. python tests/test_axiom.py`.

---

## Quick verification

- **API health:**  
  `curl http://localhost:8000/`
- **Teacher config:**  
  `curl http://localhost:8000/config/layer1`
- **Full pipeline script:**  
  `python scripts/verify_full_pipeline.py` (requires CORA; set `CORA_BASE_URL`, `CORA_USERNAME`, `CORA_PASSWORD` in `.env` or edit the script).

---

## CLI entrypoints (optional)

You can run the pipeline from the command line without the API:

```bash
# From repo root
PYTHONPATH=. python scripts/run_teacher.py --domain automotive --count 5
PYTHONPATH=. python scripts/run_examiner.py --l1-filename Teacher_DISC_2026-02-06_16h36_26_65bd33.json
PYTHONPATH=. python scripts/run_judge.py --candidate path/to/cora_*.json --teacher path/to/Teacher_*.json
```

See `scripts/run_teacher.py`, `scripts/run_examiner.py`, and `scripts/run_judge.py` for options.

---

## Development

- **Single version source:** The API is served by `src/axiom_core/api/main.py` only (no legacy server for production).
- **Env vars:** `.env` in the repo root is loaded by `dependencies.py` (e.g. `MONGO_URI`, `CORA_BASE_URL`, `OPENAI_API_KEY`). Scripts and the API use it when started from the root or with `PYTHONPATH` set.
- **PYTHONPATH:** Use `PYTHONPATH=.` or `PYTHONPATH=src` (for Streamlit) when running from the repo root so that `src.axiom_core` and `src.axiom_ui` resolve.

---

## Summary of run commands

| What        | Command (from repo root) |
|------------|---------------------------|
| **API**    | `PYTHONPATH=. uvicorn src.axiom_core.api.main:app --host 0.0.0.0 --port 8000 --reload` |
| **React**  | Start API, then `cd src/axiom_ui && npm run dev` |
| **Streamlit** | `PYTHONPATH=src streamlit run src/axiom_ui/app.py` |
| **Verify pipeline** | `PYTHONPATH=. python scripts/verify_full_pipeline.py` |

---

## Troubleshooting

- **Import errors when running API:** Ensure you run from repo root and set `PYTHONPATH=.` (or `PYTHONPATH=src` where noted) so that `src.axiom_core` and `src.axiom_ui` resolve.
- **React cannot reach API:** Ensure the API is running on port 8000. The UI uses `http://localhost:8000` by default.
- **CORA / MongoDB errors:** Check `src/config/secrets.json` or `.env` (repo root) and that CORA and MongoDB (if used) are reachable. For scripts, set `CORA_BASE_URL`, `CORA_USERNAME`, `CORA_PASSWORD` in `.env` and run from repo root with `PYTHONPATH=.` or `PYTHONPATH=src` as needed.
- **Ollama not found:** Install Ollama and run e.g. `ollama run llama3:latest`. Use model names like `llama3:latest` in config or requests.

---

## License and contact

See the repository’s license file and maintainers for terms and contact.
