#!/usr/bin/env python3
"""
CLI entrypoint for Judge (Layer 3) evaluation.
Usage (from repo root):
  PYTHONPATH=. python scripts/run_judge.py --candidate path/to/cora_*.json --teacher path/to/Teacher_*.json
Writes report to data/Judge/<mode>/.
"""
import argparse
import json
import os
import sys
import uuid

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from src.axiom_core.services.judge_service import JudgeService


def main():
    ap = argparse.ArgumentParser(description="Run Judge evaluation (Layer 3)")
    ap.add_argument("--candidate", required=True, help="Relative path to candidate (Examiner) file under data/Examiner/")
    ap.add_argument("--teacher", required=True, help="Relative path to reference (Teacher) file under data/Teacher/")
    ap.add_argument("--model", default="gpt-4o", help="Judge LLM profile ID")
    args = ap.parse_args()

    run_id = str(uuid.uuid4())
    try:
        JudgeService.run_evaluation(
            run_id=run_id,
            candidate_file=args.candidate,
            teacher_file=args.teacher,
            model_name=args.model,
        )
        print(json.dumps({"status": "Success", "run_id": run_id}, indent=2))
    except FileNotFoundError as e:
        print(json.dumps({"status": "Error", "detail": str(e)}), file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"status": "Error", "detail": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
