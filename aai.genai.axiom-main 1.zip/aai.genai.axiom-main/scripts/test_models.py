import os
import json
import sys
from typing import Dict, Any

# --- SETUP PATHS ---
# Run from repo root: python scripts/test_models.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, _REPO_ROOT)

CONFIG_PATH = os.path.join(_REPO_ROOT, "src", "config", "llm_profiles.json")

# --- LOAD CONFIGURATION ---
print(f"📂 Loading config from: {CONFIG_PATH}")
if not os.path.exists(CONFIG_PATH):
    print(f"❌ Error: Config file not found at {CONFIG_PATH}")
    sys.exit(1)

with open(CONFIG_PATH, 'r') as f:
    LLM_PROFILES = json.load(f)

# --- IMPORT BRAINS ---
try:
    from src.axiom_core.layer1_teacher.brains import OpenSourceTeacher, PremiumTeacher
    try:
        from src.axiom_core.dependencies import load_api_keys
    except ImportError:
        def load_api_keys(): return {} 
except ImportError as e:
    print(f"❌ Critical Import Error: {e}")
    print("Run from project root: python scripts/test_models.py")
    sys.exit(1)

def test_model(model_key: str, config: Dict[str, Any]):
    print(f"\n🧪 Testing Model: [{model_key}]")
    print(f"   - Name: {config.get('model_name')}")
    print(f"   - Provider: {config.get('provider', 'local')}")
    
    try:
        brain = None
        provider = config.get("provider", "local")
        model_name = config.get("model_name", "unknown")
        
        # 1. Instantiate
        if provider in ["openai", "anthropic", "azure"]:
            keys = load_api_keys()
            api_key = keys.get(provider)
            if not api_key:
                print("   ⚠️ SKIPPED: Missing API Key for premium provider.")
                return False
            brain = PremiumTeacher(api_key=api_key, model_name=model_name)
        else:
            # Local / Ollama
            brain = OpenSourceTeacher(model_name=model_name)
            
        # 2. Generate
        print("   - Sending prompt...")
        response = brain.generate("Reply with the word 'Working'.")
        
        # 3. Validate
        if response and len(response) > 0:
            print(f"   ✅ SUCCESS! Response: {response.strip()[:50]}...")
            return True
        else:
            print("   ❌ FAILED: Empty response.")
            return False
            
    except Exception as e:
        print(f"   ❌ FAILED: Error -> {str(e)}")
        return False

def run_suite():
    print("="*40)
    print("  AXIOM MODEL DIAGNOSTIC TOOL")
    print("="*40)
    
    profiles = LLM_PROFILES.get("profiles", {})
    if not profiles:
        print("❌ No profiles found in LLM_PROFILES (key 'profiles' is empty).")
        return

    results = {"success": [], "failed": []}
    
    for key, conf in profiles.items():
        if test_model(key, conf):
            results["success"].append(key)
        else:
            results["failed"].append(key)

    print("\n" + "="*40)
    print("  SUMMARY")
    print("="*40)
    print(f"✅ Working Models ({len(results['success'])}): {', '.join(results['success'])}")
    if results["failed"]:
        print(f"❌ Broken Models  ({len(results['failed'])}): {', '.join(results['failed'])}")
    print("="*40)

if __name__ == "__main__":
    run_suite()
