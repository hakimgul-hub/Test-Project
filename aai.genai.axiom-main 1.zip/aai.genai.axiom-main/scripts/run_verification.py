import os
import sys
import uuid
import json
import time

# Setup Path — run from repo root: python scripts/run_verification.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(_REPO_ROOT, "src"))
from axiom_core.layer2_harness.adapters import CoraHarness

# --- CONFIGURATION ---
BASE_URL = "https://corax-dev.automotive-ai.com"
USERNAME = "aai-cora-customer-01@automotive-ai.com" 
PASSWORD = "g6/N)%9:@sfqBIsz"  # <--- UPDATE THIS
# ---------------------

def run_tests():
    print("🛡️ AXIOM SYSTEM DIAGNOSTIC (WITH 'LEGAL ACT' FIX) 🛡️")
    print("====================================================")
    
    # 1. AUTH TEST
    print("\n[TEST 1] Authentication...")
    h = CoraHarness(BASE_URL, USERNAME, PASSWORD)
    if h.connect():
        print("✅ PASS: Connected to CORA.")
    else:
        print("❌ FAIL: Authentication rejected.")
        return

    # 2. DISCOVERY MODE TEST (Global Search)
    print("\n[TEST 2] Discovery Mode (Adversarial)...")
    disc_payload = {
        "questions": [{"question": "What are the requirements for UN R157?", "type": "Adversarial"}]
    }
    
    # ✅ FIX: Using the discovered version "Legal act"
    disc_conf = {
        "cora_version_name": "Legal act", 
        "discovery_doc_id": "36f27a7f-badb-4701-be01-4d7c1baeda78"
    }
    
    res_disc = h.run_axiom_batch(disc_payload, disc_conf)
    
    questions = res_disc.get('results_questions', [])
    if questions:
        ans = questions[0].get('actual_answer', '')
        # Check if we got a real answer (not "No Response" or error)
        if len(ans) > 20 and "No Response" not in ans:
            print(f"✅ PASS: Answered successfully ({len(ans)} chars).")
            print(f"   Sample: {ans[:100]}...")
            print(f"   Mode Used: {questions[0].get('cora_mode_used')}")
        else:
            print(f"❌ FAIL: Answer too short/empty: {ans}")
    else:
        print("❌ FAIL: No results returned (Thread creation likely failed).")

    # 3. SINGLE DOC TEST (Auditor)
    print("\n[TEST 3] Single Document Mode (Auditor)...")
    # This checks if the adapter handles missing IDs without crashing
    audit_payload = {
        "questions": [{"question": "Verify Section 4.", "type": "Standard"}]
    }
    audit_conf = {
        "cora_document_id": "00000000-0000-0000-0000-000000000000", 
        "cora_version_name": "Legal act"
    }
    
    res_audit = h.run_axiom_batch(audit_payload, audit_conf)
    
    if not res_audit.get('results_questions'):
        print("✅ PASS: System handled Invalid ID gracefully (No crash).")
    else:
        print("❓ NOTE: Unexpected success with invalid ID?")

    print("\n====================================================")

if __name__ == "__main__":
    if "YOUR_PASSWORD" in PASSWORD:
        PASSWORD = input("Enter CORA Password: ")
    run_tests()
