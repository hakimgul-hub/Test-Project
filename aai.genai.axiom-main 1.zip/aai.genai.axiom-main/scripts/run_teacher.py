#!/usr/bin/env python3
"""
CLI entrypoint for Teacher (Layer 1) generation.
Usage (from repo root):
  PYTHONPATH=. python scripts/run_teacher.py
  PYTHONPATH=. python scripts/run_teacher.py --domain automotive --count 5
Reads config from env or defaults; writes to data/Teacher/<mode>/.
"""
import argparse
import json
import os
import sys

# Ensure repo root on path
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from src.axiom_core.services.teacher_service import TeacherService


def main():
    ap = argparse.ArgumentParser(description="Run Teacher generation (Layer 1)")
    ap.add_argument("--domain", default="automotive", help="Domain (automotive, pharma, legal)")
    ap.add_argument("--persona", default="Auditor", help="Persona name")
    ap.add_argument("--technique", default="Strict Context", help="Technique")
    ap.add_argument("--context", default="", help="Free-form context text (or use --context-file)")
    ap.add_argument("--context-file", help="Path to file with context text")
    ap.add_argument("--count", type=int, default=5, help="Number of questions")
    ap.add_argument("--models", nargs="+", default=["local_llama3"], help="LLM profile IDs")
    ap.add_argument("--source-type", default="discovery", choices=["discovery", "single_doc", "project"], help="Source type")
    ap.add_argument("--topic", default="", help="Topic (for discovery)")
    args = ap.parse_args()

    context = args.context
    if args.context_file and os.path.exists(args.context_file):
        with open(args.context_file, "r", encoding="utf-8") as f:
            context = f.read()
    if not context:
        context = "Sample regulatory context: All software units must undergo static analysis. MC/DC coverage is required for ASIL D."

    source_metadata = {"source_type": args.source_type, "topic": args.topic or "General"}

    try:
        artifact_dict, filename = TeacherService.run_generation(
            domain=args.domain,
            persona=args.persona,
            technique=args.technique,
            context=context,
            count=args.count,
            source_metadata=source_metadata,
            models=args.models,
        )
        print(json.dumps({"status": "Success", "filename": filename, "run_id": artifact_dict.get("run_id")}, indent=2))
    except Exception as e:
        print(json.dumps({"status": "Error", "detail": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
