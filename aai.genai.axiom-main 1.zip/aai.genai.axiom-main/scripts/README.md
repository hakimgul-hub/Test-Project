# Scripts

Run all scripts **from the repository root**, e.g.:

```bash
python scripts/verify_full_pipeline.py
python scripts/run_verification.py
python scripts/test_models.py
python scripts/debug/check_zombies.py
PYTHONPATH=. python scripts/debug/debug_cora.py    # CORA login + thread + chat (set CORA_* in .env)
PYTHONPATH=. python scripts/debug/list_cora_endpoints.py
python scripts/oneoff/fix_broken_projects.py
python scripts/legacy/server.py   # Legacy server (broken Judge import)
```

| Script | Purpose |
|--------|--------|
| `verify_full_pipeline.py` | Full pipeline verification (documented in main README) |
| `run_verification.py` | Auth + discovery sanity check |
| `run_certification_batch.py` | Batch run Teacher → Examiner via API (localhost:8000) |
| `verify_master_release.py` | Full release verification with mongo_loader |
| `test_models.py` | Test LLM profiles from `src/config/llm_profiles.json` |
| **debug/** | CORA discovery, Ollama smoke, zombie check, API scanning, MongoDB inspect. CORA helpers: `debug_cora.py` (login + thread + chat), `fetch_cora_content.py` (TOC dump), `list_cora_endpoints.py` (OpenAPI GET list), `extract_text_from_toc.py` (TOC → axiom_ready_content.json). Use CORA_* in .env. |
| **oneoff/** | Data fixes (e.g. remove poison doc ID from Teacher JSONs) |
| **legacy/** | Legacy FastAPI server (prefer `uvicorn src.axiom_core.api.main:app`) |
| **run_teacher.py** | CLI: run Teacher generation (Layer 1) without API. `PYTHONPATH=. python scripts/run_teacher.py --domain automotive --count 5` |
| **run_examiner.py** | CLI: run Examiner batch (Layer 2). `PYTHONPATH=. python scripts/run_examiner.py --l1-filename Teacher_*.json` |
| **run_judge.py** | CLI: run Judge evaluation (Layer 3). `PYTHONPATH=. python scripts/run_judge.py --candidate <path> --teacher <path>` |
| **organize_examiner_data.py** | One-off: move Examiner JSON files into mode subfolders (Discovery, PCT, Document, UserDoc). Run from repo root: `python3 scripts/organize_examiner_data.py` |

See **[docs/ROOT_SCRIPTS_ANALYSIS.md](../docs/ROOT_SCRIPTS_ANALYSIS.md)** for full classification and impact.
