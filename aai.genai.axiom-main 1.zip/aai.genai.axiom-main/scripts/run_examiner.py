#!/usr/bin/env python3
"""
CLI entrypoint for Examiner (Layer 2) batch run.
Usage (from repo root):
  PYTHONPATH=. python scripts/run_examiner.py --l1-filename Teacher_DISC_2026-02-06_16h36_26_65bd33.json
Requires CORA credentials in secrets.json; writes to data/Examiner/.
"""
import argparse
import json
import os
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from src.axiom_core.services.examiner_service import ExaminerService, is_sdk_available


def main():
    ap = argparse.ArgumentParser(description="Run Examiner batch (Layer 2)")
    ap.add_argument("--l1-filename", required=True, help="Teacher output filename (e.g. Teacher_DISC_*.json)")
    ap.add_argument("--project-id", default=None, help="Optional project ID")
    ap.add_argument("--cora-model", default="gpt-4o", help="CORA model")
    args = ap.parse_args()

    if not is_sdk_available():
        print(json.dumps({"status": "Error", "detail": "CORA SDK not available or misconfigured"}), file=sys.stderr)
        sys.exit(1)

    run_id = "cli-run"
    try:
        ExaminerService.run_batch(
            run_id=run_id,
            l1_filename=args.l1_filename,
            project_id=args.project_id,
            cora_model=args.cora_model,
        )
        print(json.dumps({"status": "Success", "run_id": run_id}, indent=2))
    except (FileNotFoundError, RuntimeError) as e:
        print(json.dumps({"status": "Error", "detail": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
