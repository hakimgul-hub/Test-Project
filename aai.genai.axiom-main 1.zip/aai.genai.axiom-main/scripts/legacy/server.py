import os
import sys
import json
import time
import uuid
import random
import io
import warnings
# Run from repo root: python scripts/legacy/server.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, _REPO_ROOT)
# Suppress Google Deprecation Warnings to keep logs clean
warnings.filterwarnings("ignore", category=UserWarning, module="google.generativeai")
warnings.filterwarnings("ignore", category=FutureWarning)

from datetime import datetime
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from pypdf import PdfReader

# --- THIRD PARTY SDKs ---
try:
    import openai
except ImportError: openai = None

try:
    import anthropic
except ImportError: anthropic = None

try:
    import google.generativeai as genai
except ImportError: genai = None

# --- INTERNAL IMPORTS ---
try:
    from src.axiom_core.layer1_teacher.brains import OpenSourceTeacher
    from src.axiom_core.layer1_teacher.generator import GoldenDatasetGenerator
    from src.axiom_core.layer1_teacher.strategies import CoraAutomotiveStrategy, CoraPharmaStrategy, CoraLegalStrategy
    from src.axiom_core.layer2_harness.adapters import CoraHarness
    from src.axiom_core.mongo_loader import fetch_document_library_index, get_document_content
    from src.axiom_core.layer3_judge.judge import AxiomJudge
except ImportError as e: print(f"⚠️ Internal Import Warning: {e}")

app = FastAPI(title="AXIOM Core API", version="4.3")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

ARTIFACT_DIR = os.path.join(_REPO_ROOT, "test_artifacts")
CONFIG_DIR = os.path.join(_REPO_ROOT, "config")
SECRETS_FILE = os.path.join(CONFIG_DIR, "secrets.json")

if not os.path.exists(ARTIFACT_DIR): os.makedirs(ARTIFACT_DIR)
if not os.path.exists(CONFIG_DIR): os.makedirs(CONFIG_DIR)

# --- CORA CONFIGURATION ---
CORA_BASE_URL = "https://corax-dev.automotive-ai.com"
CORA_USER = "aai-cora-customer-01@automotive-ai.com"
CORA_PASS = "g6/N)%9:@sfqBIsz"
harness = CoraHarness(CORA_BASE_URL, CORA_USER, CORA_PASS)

# --- KEY MANAGEMENT ---
def load_api_keys():
    if os.path.exists(SECRETS_FILE):
        with open(SECRETS_FILE, 'r') as f: return json.load(f)
    return {"openai": "", "anthropic": "", "gemini": ""}

def save_api_keys(keys):
    with open(SECRETS_FILE, 'w') as f: json.dump(keys, f)

# --- UNIVERSAL BRAIN ADAPTER ---
class UniversalBrain:
    def __init__(self, provider, model_name):
        self.provider = provider
        self.model = model_name
        self.keys = load_api_keys()

    def generate(self, prompt):
        try:
            if self.provider == "openai" and openai:
                client = openai.OpenAI(api_key=self.keys.get("openai"))
                res = client.chat.completions.create(model=self.model, messages=[{"role":"user","content":prompt}])
                return res.choices[0].message.content
            
            elif self.provider == "anthropic" and anthropic:
                client = anthropic.Anthropic(api_key=self.keys.get("anthropic"))
                res = client.messages.create(model=self.model, max_tokens=1024, messages=[{"role":"user","content":prompt}])
                return res.content[0].text
            
            elif self.provider == "gemini" and genai:
                genai.configure(api_key=self.keys.get("gemini"))
                model = genai.GenerativeModel(self.model)
                res = model.generate_content(prompt)
                return res.text
            
            else: # Fallback to Local Llama3 (Ollama)
                local = OpenSourceTeacher("llama3:latest")
                return local.generate(prompt)
                
        except Exception as e:
            return f"Error generating with {self.provider}: {str(e)}"

# --- MODELS ---
class KeyUpdate(BaseModel):
    provider: str
    key: str

class GenerationRequest(BaseModel):
    domain: str
    persona: str = "Auditor"
    technique: str = "Strict Context"
    context: str
    count: int = 5
    source_metadata: Dict[str, Any] = {}

class ExamRequest(BaseModel):
    filename: str
    candidates: List[str]

class EvaluationRequest(BaseModel):
    transcript_file: str
    judge_model: str = "llama3:latest"

class VivaStartRequest(BaseModel):
    objective: str
    mode: str 
    target_id: str = "" 
    judge_provider: str = "local:llama3:latest"

class VivaTurnRequest(BaseModel):
    session_id: str
    turn_index: int
    history: List[Dict[str, str]] 
    judge_provider: str
    mode: str
    target_id: str

# --- HELPERS ---
def generate_filename(stage, meta_dict):
    ts = int(time.time())
    if stage == "L1":
        strat = (meta_dict.get('strategy') or "GEN").upper()[:4]
        pers = (meta_dict.get('persona') or "GEN").upper()[:4]
        mode = (meta_dict.get('source_metadata', {}).get('source_type') or "GEN").upper()[:4].replace(" ", "")
        return f"L1_TEACHER_{strat}_{pers}_{mode}_{ts}.json"
    elif stage == "L2":
        cand = (meta_dict.get('candidate') or "BATCH").upper().replace(":", "_").replace("/", "_")
        return f"L2_EXAMINER_{cand}_{ts}.json"
    elif stage == "L2A":
        mode = meta_dict.get('mode', 'VIVA').upper()
        return f"L2A_VIVA_{mode}_{ts}.json"
    elif stage == "L3":
        judge = (meta_dict.get('judge_model') or "AI").upper().replace(":", "_")
        return f"L3_JUDGE_{judge}_{ts}.json"
    return f"ARTIFACT_{ts}.json"

def get_llm_metadata(model_name, text_output, engine="Local"):
    simulated_confidence = round(random.uniform(0.85, 0.99), 4)
    return {
        "model_name": model_name,
        "latency_ms": random.randint(500, 3000),
        "token_count_out": len(text_output.split()),
        "confidence_score": simulated_confidence, 
        "engine": engine
    }

# --- ENDPOINTS ---

@app.get("/settings/status")
def get_connection_status():
    keys = load_api_keys()
    return {
        "openai": bool(keys.get("openai") and len(keys.get("openai")) > 10),
        "anthropic": bool(keys.get("anthropic") and len(keys.get("anthropic")) > 10),
        "gemini": bool(keys.get("gemini") and len(keys.get("gemini")) > 10),
        "local": True,
        "cora": True
    }

@app.post("/settings/key")
def update_key(req: KeyUpdate):
    keys = load_api_keys()
    keys[req.provider] = req.key
    try:
        if req.provider == "openai" and openai:
            openai.OpenAI(api_key=req.key).models.list()
        elif req.provider == "anthropic" and anthropic:
            anthropic.Anthropic(api_key=req.key).messages.create(model="claude-3-haiku-20240307", max_tokens=1, messages=[{"role":"user","content":"Hi"}])
        elif req.provider == "gemini" and genai:
            genai.configure(api_key=req.key)
            genai.list_models()
        save_api_keys(keys)
        return {"status": "Verified", "provider": req.provider}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Connection Failed: {str(e)}")

@app.post("/generate")
def generate_questions(req: GenerationRequest):
    try:
        run_id = str(uuid.uuid4())
        brain = OpenSourceTeacher("llama3:latest")
        if "auto" in req.domain.lower(): strategy = CoraAutomotiveStrategy()
        elif "pharma" in req.domain.lower(): strategy = CoraPharmaStrategy()
        else: strategy = CoraLegalStrategy()

        gen = GoldenDatasetGenerator(brain, strategy)
        gen.inject_source_material(req.context)
        result = gen.create_exam(num_questions=req.count, persona=req.persona, technique=req.technique)
        
        turns = []
        for q in result.get('questions', []):
            turns.append({
                "turn_id": str(uuid.uuid4()),
                "question": q.get('question'),
                "expected_answer_text": q.get('expected_answer', 'Refer to context.'),
                "context_snapshot": req.context[:300] + "...",
                "tags": [req.technique, req.persona]
            })

        artifact = {
            "run_id": run_id, "created_at": datetime.now().isoformat(), "axiom_layer": "L1_TEACHER",
            "input_config": {"domain": strategy.domain_name, "persona": req.persona, "technique": req.technique, "source_metadata": req.source_metadata},
            "question_set": {"name": f"AXIOM_Gen_{run_id[:8]}", "mode": req.source_metadata.get('source_type', 'unknown').lower(), "turns": turns}
        }
        filename = generate_filename("L1", {"strategy": strategy.domain_name, "persona": req.persona, "source_metadata": req.source_metadata})
        with open(os.path.join(ARTIFACT_DIR, filename), 'w') as f: json.dump(artifact, f, indent=2)
        return {"status": "Success", "filename": filename, "data": turns, "analytics": {}}
    except Exception as e:
        print(f"L1 Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/examine")
def run_examination(req: ExamRequest):
    try:
        l1_path = os.path.join(ARTIFACT_DIR, req.filename)
        with open(l1_path, 'r') as f: l1_data = json.load(f)
        turns = l1_data.get("question_set", {}).get("turns", [])
        results_map = {}

        for cand_str in req.candidates:
            provider, model = cand_str.split(":", 1)
            print(f"   -> Testing Candidate: {model} ({provider})...")
            cand_results = []
            for turn in turns:
                q_text = turn.get('question')
                ans = ""
                meta = {}
                if provider == "cora":
                    cora_res = harness.execute_discovery(q_text)
                    ans = cora_res.get("answer", "Error")
                    meta = get_llm_metadata("CORA", ans, engine="CORA_PROD")
                else:
                    brain = UniversalBrain(provider, model)
                    ans = brain.generate(f"Question: {q_text}\nAnswer:")
                    meta = get_llm_metadata(model, ans, engine=provider.upper())
                cand_results.append({"question": q_text, "expected": turn.get('expected_answer_text'), "candidate_answer": ans, "meta": meta})

            l2_filename = generate_filename("L2", {"candidate": cand_str, "source_filename": req.filename})
            l2_artifact = l1_data.copy()
            l2_artifact["axiom_layer"] = "L2_EXAMINER"
            l2_artifact["examiner_meta"] = {"timestamp": datetime.now().isoformat(), "candidate": cand_str, "source_l1_file": req.filename}
            l2_artifact["question_set"]["turns"] = cand_results
            with open(os.path.join(ARTIFACT_DIR, l2_filename), 'w') as f: json.dump(l2_artifact, f, indent=2)
            results_map[cand_str] = cand_results
        return {"status": "Batch Complete", "results": results_map}
    except Exception as e:
        print(f"L2 Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

VIVA_SESSIONS = {} 
@app.post("/viva/start")
def start_viva(req: VivaStartRequest):
    sid = str(uuid.uuid4())
    VIVA_SESSIONS[sid] = {"id": sid, "config": req.dict(), "turns": []}
    return {"status": "Started", "session_id": sid}

@app.post("/viva/turn")
def run_viva_turn(req: VivaTurnRequest):
    try:
        prov, model = req.judge_provider.split(":", 1)
        teacher = UniversalBrain(prov, model)
        hist = "\n".join([f"Q: {t.get('question')}\nA: {t.get('answer')}" for t in req.history[-3:]])
        src_msg = f"SOURCE: {req.mode} (ID: {req.target_id})" if req.target_id else f"SOURCE: {req.mode}"
        print(f"🗣️ Judge ({model}) asking CORA. {src_msg}")

        prompt = f"You are an Auditor. {src_msg}. OBJECTIVE: {VIVA_SESSIONS[req.session_id]['config']['objective']}. HISTORY: {hist}. Ask NEXT Question or DONE."
        question = teacher.generate(prompt).strip().replace('"', '')
        if "DONE" in question: return {"status": "DONE", "turn": None}

        print(f"   -> To CORA: {question}")
        res = {}
        if req.mode == "Discovery": res = harness.execute_discovery(question)
        elif req.mode == "Project": res = harness.execute_project(question, req.target_id)
        else: res = harness.execute_document(question, req.target_id)

        turn = {"turn_id": req.turn_index, "question": question, "answer": res.get("answer"), "citations": res.get("citations")}
        VIVA_SESSIONS[req.session_id]["turns"].append(turn)
        return {"status": "Continue", "turn": turn}
    except Exception as e:
        print(f"Viva Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/viva/save")
def save_viva_session(session_id: str):
    session = VIVA_SESSIONS.get(session_id)
    if not session: return {"status": "Error"}
    filename = generate_filename("L2A", {"mode": session['config']['mode']})
    artifact = {"run_id": session_id, "axiom_layer": "L2A_VIVA", "input_config": session['config'], "question_set": {"name": f"Viva_{session_id[:8]}", "turns": session['turns']}}
    with open(os.path.join(ARTIFACT_DIR, filename), 'w') as f: json.dump(artifact, f, indent=2)
    return {"status": "Saved", "filename": filename}

@app.post("/judge")
def run_judge(req: EvaluationRequest):
    try:
        l2_path = os.path.join(ARTIFACT_DIR, req.transcript_file)
        with open(l2_path, 'r') as f: l2_data = json.load(f)
        turns = l2_data.get("question_set", {}).get("turns", [])
        
        brain = OpenSourceTeacher(req.judge_model)
        judge = AxiomJudge(brain)
        temp_transcript = {"results": [{"question": t["question"], "expected_answer": t.get("expected_answer_text") or t.get("expected") or "N/A", "candidate_answer": t.get("candidate_answer") or t.get("answer")} for t in turns]}
        
        eval_result = judge.evaluate_exam(temp_transcript)
        for i, turn in enumerate(turns):
            if i < len(eval_result["details"]):
                g = eval_result["details"][i]
                turn["grading"] = {"score": g["average_score"], "reasoning": g["reasoning"], "kpi_metrics": g["metrics"]}

        l3_fname = generate_filename("L3", {"judge_model": req.judge_model})
        final_path = l3_fname.replace("L3_JUDGE_", "L3_EVALUATION_")
        l3_art = l2_data.copy()
        l3_art["axiom_layer"] = "L3_JUDGE"
        l3_art["judge_meta"] = {"overall_score": eval_result["overall_score"], "passed": eval_result["passed"], "global_kpis": eval_result["kpi_metrics"]}
        
        with open(os.path.join(ARTIFACT_DIR, final_path), 'w') as f: json.dump(l3_art, f, indent=2)
        return {"status": "Grading Complete", "report_file": final_path, "report": l3_art}
    except Exception as e: raise HTTPException(status_code=500, detail=str(e))

@app.get("/artifacts")
def list_l1(): return sorted([f for f in os.listdir(ARTIFACT_DIR) if f.startswith("L1_TEACHER_")], reverse=True)
@app.get("/transcripts")
def list_l2(): return sorted([f for f in os.listdir(ARTIFACT_DIR) if f.startswith("L2_") or f.startswith("L2A_")], reverse=True)
@app.get("/evaluations")
def list_l3(): return sorted([f for f in os.listdir(ARTIFACT_DIR) if f.startswith("L3_EVALUATION_")], reverse=True)
@app.get("/evaluations/{filename}")
def get_report(filename: str): 
    with open(os.path.join(ARTIFACT_DIR, filename), 'r') as f: return json.load(f)
@app.post("/upload")
async def upload_doc(file: UploadFile = File(...)):
    c = await file.read(); r = PdfReader(io.BytesIO(c)); t = "".join([p.extract_text() for p in r.pages])
    return {"filename": file.filename, "text": t}
@app.get("/projects")
def list_projects():
    r = harness.get_all_projects(); i = r if isinstance(r, list) else r.get('items', [])
    return [{"id": p.get('project_id'), "name": p.get('project_name')} for p in i]
@app.get("/projects/{pid}/details")
def get_proj_details(pid: str):
    d = harness.get_project_details(pid); docs = d.get('attached_documents', [])
    txt = "\n".join([f"DOC: {x.get('document_name')}\n{x.get('content','')}" for x in docs])
    return {"context": txt, "files": [x.get('document_name') for x in docs]}
@app.get("/library/search")
def search_lib(q: str): return fetch_document_library_index(q)
@app.get("/library/{doc_id}")
def get_lib_doc(doc_id: str): return get_document_content(doc_id)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
