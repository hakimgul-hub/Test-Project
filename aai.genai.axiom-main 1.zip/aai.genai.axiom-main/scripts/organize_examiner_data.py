#!/usr/bin/env python3
"""
One-off script: move Examiner JSON files into mode subfolders (Discovery, PCT, Document, UserDoc).
Run from repo root: python scripts/organize_examiner_data.py

- Infers mode from JSON "mode" key when present and usable; only then falls back to filename
  (cora_Auto_<mode>_*). This ensures files with explicit mode in JSON are not misplaced by
  filename patterns.
- Moves files into data/Examiner/<Folder>/; creates folders if needed.
- Skips if file already in correct folder.
"""
import json
import os
import shutil
import sys
from typing import Optional

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.path.join(REPO_ROOT, "data")
if not os.path.exists(DATA_DIR):
    DATA_DIR = os.path.join(REPO_ROOT, "Data")
EXAMINER_DIR = os.path.join(DATA_DIR, "Examiner")

MODE_TO_FOLDER = {
    "discovery": "Discovery",
    "pct": "PCT",
    "document": "Document",
    "user_document": "UserDoc",
}
CANONICAL_FOLDERS = set(MODE_TO_FOLDER.values())


def infer_mode_from_filename(filename: str) -> str:
    """Infer mode from filename like cora_Auto_discovery_*.json or cora_Auto_document_*.json."""
    name = (filename or "").lower()
    if "_discovery_" in name:
        return "discovery"
    if "_pct_" in name:
        return "pct"
    if "_document_" in name:
        return "document"
    if "_user_" in name or "user_doc" in name:
        return "user_document"
    return "discovery"


def infer_mode_from_content(filepath: str) -> Optional[str]:
    """Read JSON and return mode from 'mode' key if present and usable. Returns None if missing or uncertain."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        raw = (data.get("mode") or "").lower().strip()
        if not raw:
            return None
        if raw in MODE_TO_FOLDER:
            return raw
        if "pct" in raw or "project" in raw:
            return "pct"
        if "document" in raw and "user" in raw:
            return "user_document"
        if "document" in raw or "single" in raw:
            return "document"
        if "user" in raw:
            return "user_document"
        if "discovery" in raw or "topic" in raw:
            return "discovery"
    except Exception:
        pass
    return None


def main():
    if not os.path.isdir(EXAMINER_DIR):
        print("Examiner dir not found:", EXAMINER_DIR)
        sys.exit(1)
    for folder in CANONICAL_FOLDERS:
        os.makedirs(os.path.join(EXAMINER_DIR, folder), exist_ok=True)

    moved = 0
    for root, _, files in os.walk(EXAMINER_DIR, topdown=False):
        rel_root = os.path.relpath(root, EXAMINER_DIR)
        parent_folder = os.path.basename(root) if rel_root != "." else None
        for f in files:
            if not f.endswith(".json"):
                continue
            path = os.path.join(root, f)
            # Infer mode: trust JSON "mode" when present; only then fall back to filename
            mode = infer_mode_from_content(path)
            if mode is None:
                mode = infer_mode_from_filename(f)
            if mode is None:
                mode = "discovery"
            folder = MODE_TO_FOLDER.get(mode, "Discovery")
            target_dir = os.path.join(EXAMINER_DIR, folder)
            target_path = os.path.join(target_dir, f)
            if os.path.normpath(path) == os.path.normpath(target_path):
                continue
            if os.path.exists(target_path):
                print("Skip (exists):", f, "->", folder)
                continue
            try:
                shutil.move(path, target_path)
                print("Moved:", path, "->", target_path)
                moved += 1
            except Exception as e:
                print("Error moving", path, e)
    print("Done. Moved", moved, "files.")


if __name__ == "__main__":
    main()
