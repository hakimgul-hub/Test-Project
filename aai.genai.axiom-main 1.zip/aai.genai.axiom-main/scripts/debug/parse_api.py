import requests
import sys

SPEC_URL = "https://corax-dev.automotive-ai.com/openapi.json"

print(f"📥 Downloading API Map from {SPEC_URL}...")

try:
    r = requests.get(SPEC_URL, timeout=10)
    r.raise_for_status()
    data = r.json()
    
    paths = data.get("paths", {}).keys()
    print(f"✅ Downloaded successfully! Analyzing {len(paths)} endpoints...\n")
    
    candidates = [p for p in paths if "login" in p or "auth" in p or "token" in p]
    
    if candidates:
        print("🎯 FOUND AUTH CANDIDATES:")
        for p in candidates:
            print(f"   - {p}")
            
        print("\n👇 HOW TO FIX CONFIG.PY:")
        example = candidates[0]
        if "/auth/" in example:
            prefix = example.split("/auth/")[0]
            print(f"   Set self.api_prefix = '{prefix}'")
        else:
            print(f"   (Use the start of the string above as your prefix)")
            
    else:
        print("❌ No 'login', 'auth', or 'token' paths found in the spec.")
        for p in list(paths)[:10]:
            print(f"   - {p}")

except Exception as e:
    print(f"❌ Error: {e}")
