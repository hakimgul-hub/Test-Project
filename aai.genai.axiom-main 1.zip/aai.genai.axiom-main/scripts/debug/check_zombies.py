import os
import json
import re
from collections import Counter

# Run from repo root: python scripts/debug/check_zombies.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
TEACHER_DIR = os.path.join(_REPO_ROOT, "data", "Teacher")

# Intensive Keyword Dictionary
DOMAIN_SIGNATURES = {
    "tyre": ["tyre", "tire", "adhesion", "rolling", "flange", "rim", "sidewall", "tread"],
    "brake": ["brake", "braking", "abs", "deceleration", "retarder", "lining", "caliper"],
    "steering": ["steer", "turning", "circle", "acsf", "command", "angle"],
    "light": ["lamp", "headlight", "beam", "lumen", "glare", "dipped", "visibility"],
    "alks": ["lane", "keeping", "automated", "holding", "transition", "driver", "monitor"],
    "coupling": ["coupling", "hitch", "drawbar", "towing", "pin", "hook", "eye"]
}

def get_text_fingerprint(text):
    text = text.lower()
    counts = Counter()
    for topic, keywords in DOMAIN_SIGNATURES.items():
        for word in keywords:
            if re.search(r'\b' + re.escape(word) + r'\b', text):
                counts[topic] += text.count(word)
    if not counts: return "unknown", 0
    return counts.most_common(1)[0]

def analyze_file_intensive(filepath):
    try:
        with open(filepath, 'r') as f: data = json.load(f)
        questions = []
        if isinstance(data, list): questions = data
        elif "question_set" in data: questions = data["question_set"].get("turns", [])
        elif "data" in data: questions = data["data"]
            
        if not questions: return "EMPTY", "none", 0

        content_blob = " ".join([str(q.get("question", "")) + " " + str(q.get("expected_answer", "")) for q in questions])
        detected_topic, score = get_text_fingerprint(content_blob)
        filename = os.path.basename(filepath).lower()

        status = "CLEAN"
        # Zombie Check: Filename vs Content Mismatch
        for topic in DOMAIN_SIGNATURES:
            if topic in filename and detected_topic != topic and detected_topic != "unknown":
                if score > 5: status = "ZOMBIE" 
        
        # Weak Content Check
        if score < 3: status = "WEAK"

        return status, detected_topic, score
    except Exception as e: return "ERROR", str(e), 0

def scan_group(group_name, file_prefix, all_files):
    print(f"\n🔎 SCANNING GROUP: {group_name} ({file_prefix}...)")
    print(f"{'STATUS':<10} | {'TOPIC':<10} | {'SCORE':<5} | {'FILENAME'}")
    print("-" * 80)
    
    group_files = [f for f in all_files if os.path.basename(f).startswith(file_prefix)]
    stats = {"CLEAN": 0, "ZOMBIE": 0, "WEAK": 0, "EMPTY": 0, "ERROR": 0}
    
    for f in sorted(group_files):
        status, topic, score = analyze_file_intensive(f)
        fname = os.path.basename(f)
        icon = "✅"
        if status == "ZOMBIE": icon = "🧟"
        elif status == "WEAK": icon = "⚠️ "
        elif status == "EMPTY": icon = "🗑️ "
        elif status == "ERROR": icon = "❌"
        
        print(f"{icon} {status:<7} | {topic:<10} | {score:<5} | {fname}")
        stats[status] += 1

    return stats

def main():
    all_files = []
    for root, _, fs in os.walk(TEACHER_DIR):
        for f in fs:
            if f.endswith(".json"): all_files.append(os.path.join(root, f))
    
    # 1. Single Documents
    sdoc_stats = scan_group("Single Documents", "Teacher_SDOC", all_files)
    
    # 2. Discovery
    disc_stats = scan_group("Discovery Research", "Teacher_DISC", all_files)
    
    # 3. Projects
    proj_stats = scan_group("Project Threads", "Teacher_PROJ", all_files)

    print("\n" + "="*60)
    print("🏁 FINAL SUMMARY")
    print(f"Single Doc Zombies: {sdoc_stats['ZOMBIE']}")
    print(f"Discovery Zombies:  {disc_stats['ZOMBIE']}")
    print(f"Project Zombies:   {proj_stats['ZOMBIE']}")
    
    total_zombies = sdoc_stats['ZOMBIE'] + disc_stats['ZOMBIE'] + proj_stats['ZOMBIE']
    if total_zombies == 0:
        print("\n✅ ALL CLEAR. You can run the Certification Batch script now.")
    else:
        print("\n❌ ZOMBIES DETECTED. Delete corrupted files before running.")

if __name__ == "__main__":
    main()
