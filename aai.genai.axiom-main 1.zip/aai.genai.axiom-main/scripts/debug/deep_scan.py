import requests
import sys

# ✅ CONFIRMED DOMAIN
BASE = "https://corax-dev.automotive-ai.com"

# Common places where developers hide APIs
PATHS_TO_CHECK = [
    "/openapi.json",
    "/api/openapi.json",
    "/v1/openapi.json",
    "/api/v1/openapi.json",
    "/swagger.json",
    "/docs",
    "/api/docs",
    "/redoc",
    "/health",
    "/api/health",
    "/status",
    "/api/status",
    "/",
    "/api",
    "/cora/openapi.json",
    "/cora/api/v1/openapi.json"
]

print(f"📡 Scanning {BASE} to find the API Door...\n")

success = False

with requests.Session() as s:
    for path in PATHS_TO_CHECK:
        url = f"{BASE}{path}"
        try:
            r = s.get(url, timeout=3)
            print(f"👉 GET {path:<25} -> Status: {r.status_code}")
            
            if r.status_code == 200:
                print(f"\n✅ FOUND IT! The API is exposing: {url}")
                
                if "json" in path:
                    try:
                        data = r.json()
                        if "paths" in data:
                            print("   📜 This is the OpenAPI Spec. Analyzing paths...")
                            for p in data["paths"].keys():
                                if "login" in p:
                                    print(f"   🎯 FOUND LOGIN PATH: {p}")
                                    print(f"   💡 ACTION: Set api_prefix in config.py based on this.")
                                    sys.exit(0)
                    except:
                        pass
                
                success = True
                break
                
        except Exception as e:
            print(f"⚠️ Error checking {path}: {e}")

if not success:
    print("\n❌ CRITICAL: The server is online (DNS works), but it returned 404 for EVERYTHING.")
    print("   Please check VPN and ask CORA team for openapi.json location.")
