import requests
import json
import sys

# --- CONFIG ---
BASE_URL = "https://corax-dev.automotive-ai.com/cora/api/v1"
USERNAME = "aai-cora-customer-01@automotive-ai.com"
PASSWORD = "g6/N)%9:@sfqBIsz" # <--- UPDATE THIS
DISC_ID = "36f27a7f-badb-4701-be01-4d7c1baeda78"
# --------------

def run_debug():
    print(f"🕵️ CORA VERSION HUNTER (FINAL FIX)")
    print(f"Target Doc: {DISC_ID}")
    
    # 1. AUTH
    s = requests.Session()
    print("1️⃣ Authenticating...")
    login_url = f"{BASE_URL}/auth/login"
    payload = {"username": USERNAME, "password": PASSWORD}
    
    # Try JSON
    auth_res = s.post(login_url, json=payload, headers={"Accept": "application/json"})
    
    # Fallback to Form Data
    if auth_res.status_code >= 400:
        print("   ⚠️ JSON Auth failed, trying Form Data...")
        auth_res = s.post(login_url, data=payload, headers={"Accept": "application/json"})
    
    if auth_res.status_code != 200:
        print(f"❌ Auth Failed: {auth_res.status_code} {auth_res.text}")
        return
    
    data = auth_res.json()
    token = data.get("access_token") or data.get("token")
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    print("✅ Authenticated.")

    # 2. VERSION GUESSING
    guesses = ["Legal act", "v1", "1", "1.0", "0.1", "Initial Version", "Draft", "Published", "v1.0", "default"]
    
    print("\n2️⃣ Attempting Thread Creation...")
    
    success_version = None
    
    for v_name in guesses:
        sys.stdout.write(f"   👉 Trying version_name='{v_name}'... ")
        sys.stdout.flush()
        
        payload = {
            "document_id": DISC_ID,
            "version_name": v_name,
            "thread_name": f"Debug_{v_name}",
            "language": "EN"
        }
        
        try:
            r = s.post(f"{BASE_URL}/threads/", json=payload, headers=headers)
            
            if r.status_code in [200, 201]:
                print("✅ SUCCESS!")
                success_version = v_name
                print(f"\n🎉 FOUND IT! The correct version name is: '{v_name}'")
                print("ACTION: Go to src/axiom_ui/app.py and set 'cora_version_name': 'Legal act'")
                break
            elif r.status_code == 404:
                print("❌ 404 (Not Found)")
            elif r.status_code == 422:
                print("❌ 422 (Invalid Format)")
            else:
                print(f"❌ {r.status_code}")
                
        except Exception as e:
            print(f"❌ Error: {e}")

    if not success_version:
        print("\n❌ All guesses failed.")

if __name__ == "__main__":
    if "YOUR_PASSWORD" in PASSWORD:
        PASSWORD = input("Enter Password: ")
    run_debug()
