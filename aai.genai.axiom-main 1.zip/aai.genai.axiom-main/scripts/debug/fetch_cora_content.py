"""
Fetch CORA document table-of-contents and save to cora_toc_dump.json in this folder.
Uses CORA_BASE_URL, CORA_USERNAME, CORA_PASSWORD, and optionally CORA_DOC_ID, CORA_VERSION_NAME.
Run from repo root: PYTHONPATH=. python scripts/debug/fetch_cora_content.py
"""
import os
import json
import urllib.parse
import requests

_script_dir = os.path.dirname(os.path.abspath(__file__))
_repo_root = os.path.abspath(os.path.join(_script_dir, "../.."))
if os.path.exists(os.path.join(_repo_root, ".env")):
    try:
        from dotenv import load_dotenv
        load_dotenv(os.path.join(_repo_root, ".env"))
    except Exception:
        pass

BASE_URL = os.getenv("CORA_BASE_URL", "https://corax-dev.automotive-ai.com/cora/api/v1")
USERNAME = os.getenv("CORA_USERNAME", "")
PASSWORD = os.getenv("CORA_PASSWORD", "")
DOC_ID = os.getenv("CORA_DOC_ID", "91bd2a5b-13cc-46de-a68d-3e4b7926554d")
VERSION_NAME = os.getenv("CORA_VERSION_NAME", "Legal act")
LANGUAGE = os.getenv("CORA_LANGUAGE", "EN")
OUTPUT_FILE = os.path.join(_script_dir, "cora_toc_dump.json")


def login(session):
    print(f"Connecting to {BASE_URL}...")
    try:
        resp = session.post(f"{BASE_URL}/auth/login", json={"username": USERNAME, "password": PASSWORD})
        if resp.status_code != 200:
            resp = session.post(f"{BASE_URL}/auth/login", data={"username": USERNAME, "password": PASSWORD})
        if resp.status_code == 200:
            print("Login successful.")
            return resp.json().get("access_token")
    except Exception as e:
        print(f"Login error: {e}")
    return None


def inspect_structure(session, token):
    headers = {"Authorization": f"Bearer {token}"}
    safe_ver = urllib.parse.quote(VERSION_NAME)
    url = f"{BASE_URL}/documents/{DOC_ID}/versions/{safe_ver}/languages/{LANGUAGE}"
    print(f"\nInspecting table_of_contents from:\n  {url}")
    resp = session.get(url, headers=headers)
    if resp.status_code != 200:
        print(f"Request failed: {resp.status_code}")
        return
    data = resp.json()
    if isinstance(data, dict):
        data = data.get("data", data)
    toc = data.get("table_of_contents")
    if toc:
        print(f"Found table of contents with {len(toc)} items.")
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(toc, f, indent=2, ensure_ascii=False)
        print(f"Saved to {OUTPUT_FILE}")
    else:
        print("'table_of_contents' is empty or null.")
    if data.get("source_info"):
        print("Source info:", data.get("source_info"))


def main():
    if not USERNAME or not PASSWORD:
        print("Set CORA_USERNAME and CORA_PASSWORD in .env (repo root).")
        return
    session = requests.Session()
    token = login(session)
    if token:
        inspect_structure(session, token)


if __name__ == "__main__":
    main()
