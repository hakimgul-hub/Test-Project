import requests
import json
import time
import os

# Run from repo root: python scripts/debug/debug_ollama.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
CONFIG_FILE = os.path.join(_REPO_ROOT, "src", "config", "smoke_tests.json")

# CONFIGURATION
OLLAMA_URL = "http://localhost:11434"
MODEL_TO_TEST = "llama3:latest"

def load_tests():
    if not os.path.exists(CONFIG_FILE):
        print(f"⚠️ Config not found at {CONFIG_FILE}. Using fallback.")
        return {"fallback": {"prompt": "Say 'Hello'", "expected_fragment": "Hello"}}
    with open(CONFIG_FILE, 'r') as f:
        return json.load(f)

def run_smoke_test():
    print(f"🛡️  AXIOM SMOKE TESTER")
    print(f"    Target: {OLLAMA_URL} | Model: {MODEL_TO_TEST}\n")

    # 1. Load Tests
    tests = load_tests()
    print(f"📋 Loaded {len(tests)} test scenarios.\n")

    # 2. Run Loop
    passed = 0
    total = 0
    
    for key, test in tests.items():
        total += 1
        prompt = test['prompt']
        expect = test.get('expected_fragment', '').lower()
        
        print(f"👉 [{key.upper()}] Sending...")
        
        payload = {
            "model": MODEL_TO_TEST,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.1}
        }

        try:
            start = time.time()
            resp = requests.post(f"{OLLAMA_URL}/api/generate", json=payload, timeout=30)
            duration = time.time() - start
            
            if resp.status_code == 200:
                ans = resp.json().get("response", "").strip()
                print(f"   🤖 Reply: \"{ans}\" ({duration:.2f}s)")
                
                if expect in ans.lower():
                    print("   ✅ PASS")
                    passed += 1
                else:
                    print(f"   ⚠️ WARN: Expected '{expect}' but got above.")
                    passed += 1 
            else:
                print(f"   ❌ FAILED: Status {resp.status_code}")
                
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
        
        print("-" * 50)

    # 3. Summary
    print(f"\n🏁 RESULT: {passed}/{total} Tests Passed.")
    return passed > 0

if __name__ == "__main__":
    run_smoke_test()
