"""
Extract text blocks from cora_toc_dump.json (in this folder) and write axiom_ready_content.json.
Run after fetch_cora_content.py. Run from repo root: python scripts/debug/extract_text_from_toc.py
"""
import json
import os

_script_dir = os.path.dirname(os.path.abspath(__file__))
INPUT_FILE = os.path.join(_script_dir, "cora_toc_dump.json")
OUTPUT_FILE = os.path.join(_script_dir, "axiom_ready_content.json")


def extract_text_recursive(data, text_blocks):
    if isinstance(data, dict):
        content = data.get("text") or data.get("content") or data.get("body")
        heading = data.get("title") or data.get("heading") or data.get("label") or "Section"
        if content and isinstance(content, str) and len(content.strip()) > 5:
            text_blocks.append({"section": heading, "text": content.strip()})
        for key in ["children", "sub_sections", "items", "parts", "content_nodes"]:
            if key in data:
                extract_text_recursive(data[key], text_blocks)
        for key, value in data.items():
            if isinstance(value, (dict, list)) and key not in ["children", "items"]:
                extract_text_recursive(value, text_blocks)
    elif isinstance(data, list):
        for item in data:
            extract_text_recursive(item, text_blocks)


def main():
    if not os.path.exists(INPUT_FILE):
        print(f"Error: {INPUT_FILE} not found. Run fetch_cora_content.py first.")
        return
    print(f"Opening {INPUT_FILE}...")
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        toc_data = json.load(f)
    text_blocks = []
    extract_text_recursive(toc_data, text_blocks)
    if text_blocks:
        print(f"Extracted {len(text_blocks)} sections.")
        total_chars = sum(len(b["text"]) for b in text_blocks)
        print(f"Total content size: {total_chars} characters.")
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(text_blocks, f, indent=2, ensure_ascii=False)
        print(f"Saved to {OUTPUT_FILE} (use as JSON source in Layer 1).")
    else:
        print("No body text in table of contents. Use local PDF in AXIOM Layer 1 if needed.")


if __name__ == "__main__":
    main()
