import sys
import os

# Run from repo root: python scripts/debug/debug_pipeline.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(_REPO_ROOT, "src"))

print("🔍 Importing Modules...")
try:
    from axiom_core.layer1_teacher.brains import OpenSourceTeacher
    from axiom_core.layer1_teacher.generator import GoldenDatasetGenerator
    from axiom_core.layer1_teacher.strategies import CoraAdasStrategy
    print("✅ Imports Successful.")
except ImportError as e:
    print(f"❌ Import Failed: {e}")
    sys.exit(1)

def run_debug_test():
    print("\n🧠 1. Initializing Brain (Llama 3)...")
    try:
        brain = OpenSourceTeacher(model_name="llama3:latest") 
        print(f"   Brain initialized: {brain.model_name}")
    except Exception as e:
        print(f"❌ Brain Init Failed: {e}")
        return

    print("\n⚙️ 2. Initializing Generator...")
    try:
        strategy = CoraAdasStrategy()
        gen = GoldenDatasetGenerator(brain, strategy)
        gen.inject_source_material("AXIOM is a testing platform for AI. It has 3 layers: Teacher, Examiner, Auditor.")
        print("   Generator ready.")
    except Exception as e:
        print(f"❌ Generator Init Failed: {e}")
        import traceback
        traceback.print_exc()
        return

    print("\n🚀 3. Executing Generation (This should print Brain logs)...")
    try:
        result = gen.create_exam(num_questions=1, mission_mode="Audit", difficulty=5)
        
        print("\n✅ Execution Finished!")
        print("   Result Keys:", list(result.keys()))
        if result.get("questions"):
            print(f"   Generated: {result['questions'][0]['question']}")
        else:
            print("   ⚠️ Result was empty (but didn't crash).")
            
    except Exception as e:
        print(f"\n❌ CRASH DETECTED!")
        print(f"Error Message: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    run_debug_test()
