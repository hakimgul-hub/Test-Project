import requests

BASE_URL = "https://corax-dev.automotive-ai.com"

PREFIXES = [
    "/api/v1",
    "/api",
    "",
    "/v1",
    "/api/v2"
]

print(f"🕵️  Scanning for Login Endpoint on {BASE_URL}...\n")

found_prefix = None

for prefix in PREFIXES:
    url = f"{BASE_URL}{prefix}/auth/login"
    try:
        response = requests.post(url, json={}, timeout=5)
        print(f"👉 Testing: {url} ... Status: {response.status_code}")
        
        if response.status_code != 404:
            print(f"\n✅ SUCCESS! The correct API prefix is: '{prefix}'")
            found_prefix = prefix
            break
            
    except Exception as e:
        print(f"⚠️  Error connecting to {url}: {e}")

if not found_prefix:
    print("\n❌ Could not find login endpoint. Please check the BASE_URL or contact CORA support.")
