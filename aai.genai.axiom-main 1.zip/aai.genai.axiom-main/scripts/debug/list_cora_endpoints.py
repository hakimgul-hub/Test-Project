"""
List CORA API GET endpoints from OpenAPI schema.
Uses CORA_BASE_URL, CORA_USERNAME, CORA_PASSWORD from .env (repo root).
Run from repo root: PYTHONPATH=. python scripts/debug/list_cora_endpoints.py
"""
import os
import requests

_script_dir = os.path.dirname(os.path.abspath(__file__))
_repo_root = os.path.abspath(os.path.join(_script_dir, "../.."))
if os.path.exists(os.path.join(_repo_root, ".env")):
    try:
        from dotenv import load_dotenv
        load_dotenv(os.path.join(_repo_root, ".env"))
    except Exception:
        pass

BASE_URL = os.getenv("CORA_BASE_URL", "https://corax-dev.automotive-ai.com/cora/api/v1")
USERNAME = os.getenv("CORA_USERNAME", "")
PASSWORD = os.getenv("CORA_PASSWORD", "")


def login(session):
    try:
        resp = session.post(f"{BASE_URL}/auth/login", json={"username": USERNAME, "password": PASSWORD})
        if resp.status_code != 200:
            resp = session.post(f"{BASE_URL}/auth/login", data={"username": USERNAME, "password": PASSWORD})
        if resp.status_code == 200:
            return resp.json().get("access_token")
    except Exception:
        pass
    return None


def list_all_endpoints():
    session = requests.Session()
    token = login(session)
    if not token:
        print("Login failed. Set CORA_USERNAME and CORA_PASSWORD in .env.")
        return
    headers = {"Authorization": f"Bearer {token}"}
    print("\nDownloading API schema...")
    resp = session.get(f"{BASE_URL}/openapi.json", headers=headers)
    if resp.status_code != 200:
        print(f"Failed to get schema: {resp.status_code}")
        return
    paths = resp.json().get("paths", {})
    print(f"\n======== GET ENDPOINTS ({len(paths)}) ========")
    for path, methods in paths.items():
        if "get" in methods:
            print(f"  {path}")
    print("================================================")


if __name__ == "__main__":
    list_all_endpoints()
