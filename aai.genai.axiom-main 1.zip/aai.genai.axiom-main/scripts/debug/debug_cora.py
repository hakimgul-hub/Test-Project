"""
Debug script: test CORA login, create a thread, and send a test chat.
Uses CORA_BASE_URL, CORA_USERNAME, CORA_PASSWORD from .env (repo root) if set.
Run from repo root: PYTHONPATH=. python scripts/debug/debug_cora.py
"""
import os
import sys
import requests
import json

# Load .env from repo root
_script_dir = os.path.dirname(os.path.abspath(__file__))
_repo_root = os.path.abspath(os.path.join(_script_dir, "../.."))
if os.path.exists(os.path.join(_repo_root, ".env")):
    try:
        from dotenv import load_dotenv
        load_dotenv(os.path.join(_repo_root, ".env"))
    except Exception:
        pass

BASE_URL = os.getenv("CORA_BASE_URL", "https://corax-dev.automotive-ai.com/cora/api/v1")
USERNAME = os.getenv("CORA_USERNAME", "")
PASSWORD = os.getenv("CORA_PASSWORD", "")


def login():
    print(f"Connecting to {BASE_URL}...")
    url = f"{BASE_URL}/auth/login"
    if not USERNAME or not PASSWORD:
        print("Set CORA_USERNAME and CORA_PASSWORD in .env (repo root) or edit this script.")
        return None
    try:
        resp = requests.post(url, json={"username": USERNAME, "password": PASSWORD})
        if resp.status_code not in [200, 201]:
            resp = requests.post(url, data={"username": USERNAME, "password": PASSWORD})
        if resp.status_code == 200:
            data = resp.json()
            token = data.get("access_token") or data.get("token") or data.get("id_token")
            print("Login successful.")
            return token
        print(f"Login failed: {resp.status_code} | {resp.text[:200]}")
        return None
    except Exception as e:
        print(f"Connection error: {e}")
        return None


def find_valid_document(headers):
    print("\nScanning for valid Projects & Documents...")
    url = f"{BASE_URL}/projects/"
    resp = requests.get(url, headers=headers)
    if resp.status_code != 200:
        print(f"Could not list projects: {resp.status_code}")
        return None
    json_data = resp.json()
    data_content = json_data.get("data", json_data)
    if isinstance(data_content, list):
        projects = data_content
    elif isinstance(data_content, dict):
        projects = data_content.get("projects", []) or data_content.get("items", data_content.get("results", []))
    else:
        projects = []
    print(f"Found {len(projects)} projects.")
    for p in projects:
        p_id = p.get("project_id") or p.get("id")
        p_name = p.get("project_name") or p.get("name") or "Unnamed Project"
        print(f"  Project: '{p_name}' (ID: {p_id})")
        attached = p.get("attached_documents", [])
        if attached:
            doc = attached[0]
            return {
                "project_id": p_id,
                "document_id": doc.get("document_id"),
                "version_name": doc.get("version_name", "v1"),
            }
    print("No valid documents found.")
    return None


def run_test():
    token = login()
    if not token:
        return
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    context = find_valid_document(headers)
    if not context:
        return
    print("\nCreating test thread...")
    thread_payload = {
        "thread_name": "DEBUG_TEST_CONNECTION",
        "version_name": context["version_name"],
        "document_id": context["document_id"],
        "project_id": context["project_id"],
        "language": "EN",
    }
    resp = requests.post(f"{BASE_URL}/threads/", json=thread_payload, headers=headers)
    if resp.status_code != 200:
        print(f"Thread creation failed: {resp.status_code}\n{resp.text[:300]}")
        return
    thread_data = resp.json().get("data", resp.json())
    thread_id = thread_data.get("thread_id") or thread_data.get("id")
    version_id = thread_data.get("version_id")
    store_id = thread_data.get("document_store_id")
    print("Thread created:", thread_id)
    print("\nSending test message...")
    chat_payload = {
        "version_id": version_id,
        "document_trace": {
            "thread_id": thread_id,
            "document_store_id": store_id,
            "document_id": context["document_id"],
            "document_version_name": context["version_name"],
            "document_language": "EN",
            "document_part": "search-engine",
        },
        "question": "How are you?",
    }
    chat_resp = requests.post(
        f"{BASE_URL}/llm-connect/ask-llm/stream",
        json=chat_payload,
        headers=headers,
        stream=True,
    )
    if chat_resp.status_code == 200:
        print("Stream success (first 100 chars per line):")
        for line in chat_resp.iter_lines():
            if line:
                print(f"  {line.decode('utf-8')[:100]}...")
        print("\nTest completed successfully.")
    else:
        print(f"Chat failed: {chat_resp.status_code}\n{chat_resp.text[:300]}")


if __name__ == "__main__":
    run_test()
