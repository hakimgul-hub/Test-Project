import pymongo
import json
import sys
import os
from bson.json_util import dumps

# --- CONFIGURATION ---
MONGO_URI = os.getenv("MONGO_URI")
DB_NAME = os.getenv("DB_NAME")

def inspect_mongo():
    print("🔍 MONGODB EXPLORER")
    print("====================")
    
    try:
        client = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        client.server_info()
        print("✅ Connected to MongoDB successfully.")
    except Exception as e:
        print(f"❌ Connection Failed: {e}")
        return

    print("\n📂 Available Databases:")
    dbs = client.list_database_names()
    for db in dbs:
        print(f" - {db}")
    
    if DB_NAME in dbs:
        target_db = DB_NAME
    else:
        non_system = [d for d in dbs if d not in ['admin', 'local', 'config']]
        target_db = non_system[0] if non_system else 'test'
    
    print(f"\n👉 Inspecting Database: '{target_db}'")
    db = client[target_db]

    collections = db.list_collection_names()
    print(f"   Found Collections: {collections}")
    
    candidates = [c for c in collections if any(x in c.lower() for x in ['doc', 'file', 'lib', 'project'])]
    
    if not candidates:
        candidates = collections

    for col_name in candidates:
        print(f"\n📄 SAMPLE DATA: Collection '{col_name}'")
        print("-" * 40)
        
        cursor = db[col_name].find().limit(3)
        docs = list(cursor)
        
        if not docs:
            print("   (Collection is empty)")
            continue

        for i, doc in enumerate(docs):
            print(f"   [Doc {i+1}]:")
            print(json.loads(dumps(doc, indent=2)))
            print("")
            keys = doc.keys()
            print(f"   💡 UI SUGGESTION for '{col_name}':")
            if 'title' in keys: print(f"      Label: '{doc['title']}'")
            elif 'name' in keys: print(f"      Label: '{doc['name']}'")
            elif 'filename' in keys: print(f"      Label: '{doc['filename']}'")
            if '_id' in keys: print(f"      Value: '{str(doc['_id'])}'")
            print("-" * 40)

if __name__ == "__main__":
    inspect_mongo()
