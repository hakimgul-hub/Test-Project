import os
import sys
import json
import time
import uuid
import datetime

# --- SETUP PATHS ---
# Run from repo root: python scripts/verify_full_pipeline.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(_REPO_ROOT, "src"))
from axiom_core.layer2_harness.adapters import CoraHarness

# --- CONFIGURATION ---
BASE_URL = "https://corax-dev.automotive-ai.com"
USERNAME = "aai-cora-customer-01@automotive-ai.com"
PASSWORD = "g6/N)%9:@sfqBIsz"  # <--- UPDATE THIS
CORA_VERSION = "Legal act"       # <--- CONFIRMED WORKING VERSION
DISC_ID = "36f27a7f-badb-4701-be01-4d7c1baeda78" 

# --- LOGGING UTILS ---
class Logger:
    def info(self, msg): print(f"ℹ️  {msg}")
    def success(self, msg): print(f"✅ {msg}")
    def error(self, msg): print(f"❌ {msg}")
    def section(self, title): print(f"\n{'='*60}\n🛡️  {title}\n{'='*60}")

log = Logger()

class AxiomPipelineTester:
    def __init__(self):
        self.harness = CoraHarness(BASE_URL, USERNAME, PASSWORD)
        self.generated_artifacts = {} # Stores L1 mock files
        self.l2_results = {}          # Stores L2 outputs
        self.viva_results = []        # Stores L2a outputs

    def connect(self):
        log.section("STEP 0: Connectivity Check")
        if self.harness.connect():
            log.success("Connected to CORA successfully.")
            return True
        else:
            log.error("Failed to connect. Check credentials.")
            return False

    # --- STRICT VALIDATOR ENGINE ---
    def validate_no_na(self, data_obj, stage_name):
        """Recursively checks for forbidden values (N/A, NA, None, Empty)"""
        errors = []
        forbidden_values = {"N/A", "NA", "None", "", None, "No Response"}
        
        def check_item(item, path):
            if isinstance(item, dict):
                for k, v in item.items():
                    check_item(v, f"{path}.{k}")
            elif isinstance(item, list):
                for i, v in enumerate(item):
                    check_item(v, f"{path}[{i}]")
            else:
                # Check String Values
                if str(item).strip() in forbidden_values:
                    errors.append(f"Field '{path}' contains forbidden value: '{item}'")

        check_item(data_obj, stage_name)
        
        if errors:
            for e in errors: log.error(e)
            return False
        return True

    # ==========================================================
    # LAYER 1: SYNTHETIC GENERATION
    # ==========================================================
    def test_layer1_combinations(self):
        log.section("STEP 1: Generating L1 Data Combinations")
        
        # We simulate what the LLM (OpenAI/Ollama) would return
        scenarios = [
            {
                "name": "L1_Auditor_Standard",
                "meta": {"persona": "Auditor", "strategy": "Strict Context"},
                "payload": [{"question": "What are the sensing requirements?", "expected_answer": "Radar and Lidar redundancy.", "type": "Standard", "topic": "Sensing"}]
            },
            {
                "name": "L1_Adversarial_Discovery",
                "meta": {"persona": "Adversarial", "strategy": "Discovery"},
                "payload": [{"question": "What are the requirements for UN R157?", "expected_answer": "ALKS regulations.", "type": "Adversarial", "topic": "Compliance"}]
            }
        ]

        for s in scenarios:
            artifact = {
                "id": str(uuid.uuid4()),
                "type": "L1_GENERATION",
                "metadata": s['meta'],
                "payload": s['payload']
            }
            
            # STRICT CHECK: Ensure L1 generator isn't producing garbage
            if self.validate_no_na(artifact, f"L1_{s['name']}"):
                self.generated_artifacts[s['name']] = artifact
                log.success(f"Generated & Validated: {s['name']}")
            else:
                log.error(f"L1 Generation Failed Validation for {s['name']}")

    # ==========================================================
    # LAYER 2: STATIC VERIFICATION (Actual CORA Execution)
    # ==========================================================
    def test_layer2_execution(self):
        log.section("STEP 2: Running Layer 2 Verification (CORA)")
        
        for name, l1_data in self.generated_artifacts.items():
            log.info(f"▶️ Testing Input: {name}")
            
            config = {
                "cora_version_name": CORA_VERSION,
                "cora_document_id": DISC_ID, 
                "discovery_doc_id": DISC_ID,
                "project_context_id": DISC_ID 
            }
            if "Adversarial" in name: config['manual_cora_mode'] = "Discovery"
            
            # Execute Adapter
            start_t = time.time()
            result = self.harness.run_axiom_batch({"questions": l1_data['payload']}, config)
            
            # STRICT CHECK: Validate output immediately
            if self.validate_no_na(result, f"L2_Result_{name}"):
                self.l2_results[name] = result
                ans = result['results_questions'][0]['actual_answer']
                log.success(f"  L2 Validated: {len(ans)} chars. Mode: {result['meta']['mode']}")
            else:
                log.error(f"  L2 Validation Failed for {name}")

    # ==========================================================
    # LAYER 2A: VIVA MODE (Dynamic Loop Simulation)
    # ==========================================================
    def test_layer2a_viva(self):
        log.section("STEP 2a: Testing Viva Mode (Dynamic Loop)")
        
        objective = "Verify Braking Params"
        
        for i in range(2): 
            question = f"Regarding {objective}, explain param {i}."
            log.info(f"   Judge asks: {question}")
            
            config = {"cora_version_name": CORA_VERSION, "cora_document_id": DISC_ID}
            res = self.harness.run_axiom_batch({"questions": [{"question": question}]}, config)
            
            # Validate Turn
            if self.validate_no_na(res, f"L2a_Turn_{i}"):
                ans = res['results_questions'][0]['actual_answer']
                self.viva_results.append(res)
                log.success(f"   Turn {i} Validated: ({len(ans)} chars)")
            else:
                log.error(f"   Turn {i} Failed Validation (Contains N/A)")
                break

    # ==========================================================
    # STEP 3: MASTER INTEGRITY CHECK (Layer 3 Readiness)
    # ==========================================================
    def verify_final_readiness(self):
        log.section("STEP 3: Final Data Integrity Check")
        
        # Check L2 Data
        log.info("Checking L2 Artifacts...")
        for name, res in self.l2_results.items():
            for item in res.get('results_questions', []):
                # 1. Check Latency
                if not isinstance(item.get('latency'), (int, float)) or item['latency'] <= 0:
                    log.error(f"{name}: Invalid Latency")
                
                # 2. Check Citations (Must be list, can be empty but not None)
                if item.get('found_citations') is None:
                    log.error(f"{name}: Citations is None")

                # 3. Check Answer Quality
                if len(item.get('actual_answer', '')) < 10:
                     log.error(f"{name}: Answer too short/empty")
        
        log.success("L2 Artifacts: READY for Grading")

        # Check Viva Data
        log.info("Checking Viva Artifacts...")
        if not self.viva_results:
            log.error("Viva Results Empty")
        else:
            log.success(f"Viva Artifacts: {len(self.viva_results)} turns captured.")

    def run(self):
        if self.connect():
            self.test_layer1_combinations()
            self.test_layer2_execution()
            self.test_layer2a_viva()
            self.verify_final_readiness()
            log.section("🎉 FULL PIPELINE VERIFIED & CLEAN")

if __name__ == "__main__":
    if "YOUR_PASSWORD" in PASSWORD:
        PASSWORD = input("Enter CORA Password: ")
    tester = AxiomPipelineTester()
    tester.run()
