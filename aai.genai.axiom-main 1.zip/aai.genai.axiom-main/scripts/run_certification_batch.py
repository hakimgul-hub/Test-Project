import requests
import json
import os
import time
from datetime import datetime
from itertools import zip_longest

# Run from repo root: python scripts/run_certification_batch.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# CONFIG
API_URL = "http://localhost:8000"
TEACHER_DIR = os.path.join(_REPO_ROOT, "data", "Teacher")
OUTPUT_DIR = os.path.join(_REPO_ROOT, "data", "Examiner", "Batch")
BATCH_SIZE = 27  # Pause after this many files

os.makedirs(OUTPUT_DIR, exist_ok=True)

def get_completed_files():
    """Scans the output directory to find files we've already done."""
    completed = set()
    if not os.path.exists(OUTPUT_DIR): return completed
    
    for f in os.listdir(OUTPUT_DIR):
        if f.startswith("cora_") and f.endswith(".json"):
            # Reconstruct original teacher filename: cora_Teacher_X.json -> Teacher_X.json
            original_name = f.replace("cora_", "", 1)
            completed.add(original_name)
    return completed

def get_files_by_category(completed_set):
    sdoc, disc, proj = [], [], []
    skipped_count = 0
    
    for root, _, fs in os.walk(TEACHER_DIR):
        for f in fs:
            if not f.endswith(".json") or "Teacher_" not in f: continue
            
            # CHECK: Has this already been run?
            if f in completed_set:
                skipped_count += 1
                continue
            
            full_path = os.path.join(root, f)
            if "SDOC" in f: sdoc.append(full_path)
            elif "DISC" in f: disc.append(full_path)
            elif "PROJ" in f: proj.append(full_path)
            
    return sorted(sdoc), sorted(disc), sorted(proj), skipped_count

def create_round_robin_schedule(sdoc, disc, proj):
    schedule = []
    # Interleave them: SDOC, DISC, PROJ, SDOC...
    for s, d, p in zip_longest(sdoc, disc, proj):
        if s: schedule.append(s)
        if d: schedule.append(d)
        if p: schedule.append(p)
    return schedule

def run_single_file_audit(file_path, index, total):
    filename = os.path.basename(file_path)
    print(f"\n📂 [{index}/{total}] Processing: {filename}...")

    try:
        # 1. LOAD QUESTIONS
        with open(file_path, 'r') as f:
            teacher_data = json.load(f)
        
        questions = []
        if isinstance(teacher_data, list): questions = teacher_data
        elif "question_set" in teacher_data: questions = teacher_data["question_set"].get("turns", [])
        elif "data" in teacher_data: questions = teacher_data["data"]

        if not questions: 
            print("   ⚠️  No questions found. Skipping.")
            return

        # 2. DETERMINING MODE & DOC ID
        raw_mode = "single_doc"
        if "DISC" in filename: raw_mode = "discovery"
        elif "PROJ" in filename: raw_mode = "project"
        
        t_config = teacher_data.get("teacher_configuration", {})
        doc_id = t_config.get("document_id")
        
        # 3. START FRESH SESSION (The Anti-Zombie Step)
        start_payload = {"mode": raw_mode}
        if doc_id and raw_mode == "single_doc": start_payload["doc_id"] = doc_id
        if raw_mode == "project": 
            proj_name = t_config.get("project_name")
            if proj_name: start_payload["project_name"] = proj_name

        res = requests.post(f"{API_URL}/interrogator/start", json=start_payload)
        if res.status_code != 200: 
            print(f"   ❌ Failed to start session: {res.text}")
            return
        
        session_ctx = res.json().get("session_context")

        # 4. RUN QUESTIONS
        answers = []
        for i, item in enumerate(questions):
            q_text = item.get("question")
            
            chat_res = requests.post(f"{API_URL}/interrogator/chat", json={
                "session_context": session_ctx,
                "question": q_text,
                "model_id": "gpt-4o" 
            })
            
            if chat_res.status_code == 200:
                resp_data = chat_res.json()
                answers.append({
                    "question": q_text,
                    "student_answer": resp_data.get("answer_text"),
                    "grounding_sources_details": resp_data.get("clean_grounding", []),
                    "links": resp_data.get("links", [])
                })
            else:
                print(f"      ❌ Error on Q{i+1}")
        
        # 5. SAVE RESULT
        out_name = f"cora_{filename}"
        with open(os.path.join(OUTPUT_DIR, out_name), 'w') as f:
            json.dump({
                "source_teacher_file": filename,
                "run_date": datetime.now().isoformat(),
                "examiner_configuration": {"mode": raw_mode, "strict_isolation": True},
                "results": answers
            }, f, indent=2)
            
        print(f"   ✅ Saved {len(answers)} answers to {out_name}")

    except Exception as e:
        print(f"   🔥 CRITICAL FAILURE: {e}")

def main():
    print("🚀 Initializing Smart Resume (Output: data/Examiner/Batch)...")
    
    # 1. Identify Completed Work
    completed = get_completed_files()
    print(f"   found {len(completed)} existing reports.")
    
    # 2. Build Queue (excluding completed)
    sdoc, disc, proj, skipped = get_files_by_category(completed)
    
    if skipped > 0:
        print(f"   ⏭️  Skipping {skipped} files (already done).")
    
    schedule = create_round_robin_schedule(sdoc, disc, proj)
    total_files = len(schedule)
    
    if total_files == 0:
        print("\n🎉 ALL FILES COMPLETED! Ready for Judge.")
        return

    print(f"   📋 Remaining Queue: {total_files} files (Interleaved)\n")

    # 3. Run Execution Loop
    for i, file_path in enumerate(schedule):
        run_single_file_audit(file_path, i+1, total_files)
        
        # BATCH CHECKPOINT
        processed_count = i + 1
        if processed_count % BATCH_SIZE == 0 and processed_count < total_files:
            print("\n" + "="*60)
            print(f"⏸️  BATCH COMPLETE: {processed_count} files processed this run.")
            input(f"   Press [ENTER] to start the next batch of {BATCH_SIZE} files...")
            print("="*60 + "\n")
            
        time.sleep(1) 

    print("\n🎉 BATCH RUN COMPLETE! Results in data/Examiner/Batch")

if __name__ == "__main__":
    main()
