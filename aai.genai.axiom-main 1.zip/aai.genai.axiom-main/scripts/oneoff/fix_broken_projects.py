import os
import json
import shutil

# Run from repo root: python scripts/oneoff/fix_broken_projects.py
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
TEACHER_DIR = os.path.join(_REPO_ROOT, "data", "Teacher")

# The ID causing the "Language 'EN' not available" error
POISON_ID_HYPHENS = "aeb4b41d-113e-4933-8233-ad228d1e569a"
POISON_ID_CLEAN   = "aeb4b41d113e49338233ad228d1e569a"

def fix_file(filepath):
    try:
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        modified = False
        
        t_config = data.get("teacher_configuration", {})
        docs = t_config.get("documents", [])
        
        new_docs = []
        for d in docs:
            did = str(d.get("id", "")).lower().strip()
            if did == POISON_ID_HYPHENS or did == POISON_ID_CLEAN:
                print(f"   ✂️  Removing Bad Doc Object: {did}")
                modified = True
            else:
                new_docs.append(d)
        
        if modified:
            t_config["documents"] = new_docs
            
        ctx_info = data.get("context_info", {})
        doc_ids = ctx_info.get("document_ids", [])
        
        if isinstance(doc_ids, list):
            new_doc_ids = []
            for did in doc_ids:
                did_str = str(did).lower().strip()
                if did_str == POISON_ID_HYPHENS or did_str == POISON_ID_CLEAN:
                    print(f"   ✂️  Removing Bad Doc ID String: {did_str}")
                    modified = True
                else:
                    new_doc_ids.append(did)
            if modified:
                ctx_info["document_ids"] = new_doc_ids

        if modified:
            backup_path = filepath + ".bak"
            shutil.copy2(filepath, backup_path)
            
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
            print(f"   ✅ FIXED: {os.path.basename(filepath)}")
            return True
            
    except Exception as e:
        print(f"   ❌ Error reading {os.path.basename(filepath)}: {e}")
    
    return False

def main():
    print(f"🚑 STARTING SURGICAL REPAIR on '{TEACHER_DIR}'...")
    print(f"   Targeting Poison ID: {POISON_ID_CLEAN} (and hyphenated)")
    
    count = 0
    files_fixed = 0
    
    for root, _, fs in os.walk(TEACHER_DIR):
        for f in fs:
            if f.endswith(".json") and "Teacher_" in f:
                path = os.path.join(root, f)
                
                with open(path, 'r', errors='ignore') as raw:
                    content = raw.read()
                    
                if (POISON_ID_HYPHENS in content) or (POISON_ID_CLEAN in content):
                    print(f"\n🔍 Found Infection in: {f}")
                    if fix_file(path):
                        files_fixed += 1
                count += 1
                
    print("\n" + "="*50)
    print(f"🏁 REPAIR COMPLETE")
    print(f"   Scanned: {count} files")
    print(f"   Fixed:   {files_fixed} files")
    print("="*50)

if __name__ == "__main__":
    main()
