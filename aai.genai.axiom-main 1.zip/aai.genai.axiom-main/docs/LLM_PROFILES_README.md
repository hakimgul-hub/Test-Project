# LLM Profiles – Setup Guide

This guide explains how to configure and run the AI models (Teacher, Interrogator, Judge) used by AXIOM.

---

## Where the config lives

- **Profiles (models list):** `src/config/llm_profiles.json`
- **API keys (cloud only):** `src/config/secrets.json` — or use the **Settings** tab in the UI to add keys (they are written here).

The app reads `llm_profiles.json` at startup and when you open the Teacher, Interrogator, or Judge screens. Each profile has a **status** in the UI: **Online**, **Not set up**, or **Unavailable**, depending on whether the model is reachable and configured.

---

## Local models (Ollama)

Local models use [Ollama](https://ollama.com). The app talks to Ollama over HTTP and only uses models that are **pulled** on your machine.

### 1. Install and run Ollama

- Install from [https://ollama.com](https://ollama.com) and start the Ollama service (usually runs at `http://localhost:11434`).

### 2. Pull a model

Pull the exact model name that appears in your profile’s `model_name`:

```bash
# Examples (use the name that matches llm_profiles.json)
ollama pull llama3
ollama pull deepseek-r1:14b
ollama pull mistral
ollama pull qwen2.5-coder:latest
```

You can also run a model once to pull it: `ollama run llama3`.

### 3. Match the profile in `llm_profiles.json`

Each **local** profile in `src/config/llm_profiles.json` looks like this:

```json
"local_llama3": {
  "display_name": "🦙 Local - Llama 3 (Fast)",
  "provider": "ollama",
  "model_name": "llama3",
  "api_key_env": "",
  "base_url": "http://localhost:11434",
  "description": "Meta's open standard. High speed, reliable instruction following."
}
```

- **`model_name`** — Must match what Ollama has (e.g. `llama3`, `deepseek-r1:14b`). Use `ollama list` to see installed models.
- **`base_url`** — Ollama API URL. Default is `http://localhost:11434`. Change only if Ollama runs on another host/port.

If the model is not pulled or Ollama is not running, the UI will show **Not set up** or **Unavailable** for that profile and will disable actions that use it.

---

## Cloud models (OpenAI, Anthropic, Gemini)

Cloud profiles in `llm_profiles.json` look like this:

```json
"cloud_gpt5": {
  "display_name": "🧠 OpenAI - GPT-4o (Reasoning)",
  "provider": "openai",
  "model_name": "gpt-4o",
  "api_key_env": "openai",
  "base_url": "",
  "description": "Placeholder for next-gen reasoning capabilities."
}
```

- **`provider`** — One of: `openai`, `anthropic`, `gemini`.
- **`api_key_env`** — Name used to look up the API key (see below).

### Where to add API keys

**Option A – UI (recommended)**  
Open the app → **Settings** → enter and verify the key for **OpenAI**, **Anthropic**, or **Gemini**. Keys are stored in `src/config/secrets.json`.

**Option B – Edit `src/config/secrets.json`**  
Create or edit the file and add:

```json
{
  "openai": "sk-your-openai-key",
  "anthropic": "sk-ant-your-anthropic-key",
  "gemini": "your-gemini-key"
}
```

Use the keys that match how the app looks them up: `openai`, `anthropic`, `gemini` (Settings uses these names).

**Option C – Environment variables**  
You can also set the key in the environment, e.g.:

- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY`
- `GEMINI_API_KEY`

If `api_key_env` in the profile is set to e.g. `GEMINI_API_KEY`, the app will use that env var when present.

Until a key is set, the UI shows the profile as **Not set up** and disables actions that use that model.

---

## Adding or editing a profile

1. Open `src/config/llm_profiles.json`.
2. Under **`profiles`**, copy an existing entry that is similar (local or cloud).
3. Change the **key** (e.g. `local_my_model`) and the fields:
   - **Local:** `display_name`, `model_name` (must match Ollama), `base_url` if needed.
   - **Cloud:** `display_name`, `provider`, `model_name`, `api_key_env` (must match a key in `secrets.json` or an env var).
4. Save the file. Restart or refresh the app so it reloads config.

The **`active_profile`** at the top of `llm_profiles.json` is the default “Active Brain” in the sidebar; you can change it or pick another model in the UI.

---

## How the UI uses profiles

- **Sidebar – Active Brain:** Shows the current model and status (Online / Not set up / Unavailable). You can switch the active model from the dropdown.
- **Teacher:** Choose one or more Teacher models; **Start Generation** is disabled if any selected model is not available.
- **Interrogator:** Choose the Interrogator model; **Start Live** and the chat **Send** button are disabled if the selected model is not available.
- **Judge:** Choose the Judge model; **Run Evaluation** is disabled if the selected Judge model is not available.

Fixing “Not set up” or “Unavailable” means: for **local** — install/pull the model in Ollama and ensure `model_name`/`base_url` match; for **cloud** — add the API key in Settings or in `secrets.json` / environment.

---

## Quick reference

| Item              | Location / action |
|-------------------|-------------------|
| Model list        | `src/config/llm_profiles.json` → `profiles` |
| Default model     | `src/config/llm_profiles.json` → `active_profile` |
| Cloud API keys    | **Settings** in UI, or `src/config/secrets.json` |
| Ollama URL        | Profile’s `base_url` (default `http://localhost:11434`) |
| Local model name  | Must match `ollama list`; set in profile’s `model_name` |
