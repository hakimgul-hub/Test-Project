# AXIOM Platform – Technical Documentation

This document explains **how AXIOM works**: concept, runtime, Teacher/Examiner/Judge modules and code flow, MongoDB, and LLMs. For **file layouts, filename conventions, API endpoint list, and JSON artifact structures**, see **[DATA_FLOW_AND_ARTIFACTS.md](DATA_FLOW_AND_ARTIFACTS.md)**.

---

## 1. Overall Concept

**AXIOM** is a verification and evaluation platform for **CORA** (an RAG/LLM system). It implements a **V-model** flow:

1. **Teacher (Layer 1)** – Generates exam-style question sets (questions + expected answers) from documents or topics.
2. **Examiner (Layer 2)** – Runs those questions against CORA (or other "candidates") and records Q/A + citations.
3. **Interrogator (Layer 2a)** – Optional interactive "viva": an LLM asks CORA questions; sessions can be saved for later grading.
4. **Judge (Layer 3)** – Grades Examiner/Interrogator transcripts (accuracy, grounding, failure categories) and produces structured reports.

Artifacts are **file-based**: Teacher → Examiner → Judge pass data by **filename** or **relative path** under `data/`. There is no database storing links between runs; the filesystem and paths in the Judge report are the only durable links.

---

## 2. How Things Actually Work

### 2.1 Runtime Entry and API

- **Single backend:** `src/axiom_core/api/main.py` – FastAPI app, CORS, lifespan.
- **Routers:** System (config/health), Teacher, Examiner, Interrogator, Judge, Projects. Routers validate requests and delegate to **services**.
- **Services** (`src/axiom_core/services/`): `TeacherService`, `ExaminerService`, `JudgeService` orchestrate config loading, layer calls (Teacher generator, CORA SDK, Judge LLM), and writing JSON under `data/`.
- **Paths:** All `data/` paths come from `src/axiom_core/api/dependencies.py`: `DATA_DIR`, `TEACHER_DIR`, `EXAMINER_DIR`, `JUDGE_DIR`, `VIVA_DIR`. `.env` is loaded there first so `MONGO_URI`, `CORA_*`, API keys, etc. are available.

### 2.2 Config and Secrets

- **Config dir:** `src/config/` (or `config/` at repo root for some lookups).
- **Secrets:** `src/config/secrets.json` (or `config/secrets.json`). Used for CORA credentials (`cora_dev` / `cora`) and API keys (`openai`, `anthropic`, `gemini`). Env vars (e.g. `OPENAI_API_KEY`) can override.
- **Config files:** `layer1_config.json`, `layer2_config.json`, `layer2a_config.json`, `domain_profiles.json`, `llm_profiles.json`, `mongo_config.json` are loaded in `dependencies.py` at startup.

---

## 3. Layer 1 – Teacher (How It Works)

### 3.1 Purpose

Produce a **question set** (questions + expected answers + optional supporting quotes) from:

- Documents fetched from **MongoDB** (by document IDs), or
- Free-form **context** text.

Output is one JSON file per run under `data/Teacher/<mode>/`.

### 3.2 Modules and Flow

| Component | Location | Role |
|-----------|----------|------|
| **Router** | `api/routers/teacher.py` | `POST /generate` → validates `GenerationRequest`, calls `TeacherService.run_generation`, returns `filename` + data. |
| **Service** | `services/teacher_service.py` | Orchestrates: resolve docs from MongoDB or use context, chunk/limit text, pick strategy, run generator per model, dedupe questions, build artifact, write JSON. |
| **Generator** | `layer1_teacher/generator.py` | `GoldenDatasetGenerator`: takes a "brain" (LLM) and a strategy; `inject_source_material(text)` then `create_exam(count, persona, technique)` returns `{ "questions": [{ question, expected_answer, supporting_quote }] }`. |
| **Brains** | `layer1_teacher/brains.py` | `OpenSourceTeacher` (Ollama), `PremiumTeacher` (OpenAI/Anthropic). Both implement `generate(prompt)`; they use `src/axiom_core/llm.generate()`. |
| **Strategies** | `layer1_teacher/strategies.py` | Domain strategies (e.g. `CoraAutomotiveStrategy`, `CoraPharmaStrategy`, `CoraLegalStrategy`) load `layer1_config.json` and build the prompt (persona, technique, context). `get_prompt()` / `get_generation_prompt()` produce the text sent to the LLM. |

**Flow in code:**

1. Request has `source_metadata.id` (list or single ID) and/or `context`, plus `domain`, `persona`, `technique`, `count`, `models`.
2. If document IDs are given, **MongoDB must be enabled**; `mongo.get_doc(d_id)` fetches each document. Text is taken via `_scavenge_text` in dependencies' `MongoHelper` and optionally filtered for English. If only `context` is provided, that text is used.
3. Domain is mapped to a strategy (`_strategy_for_domain`: pharma/legal → specific strategy, else automotive). Strategy gets `domain_profile` from `domain_profiles.json`.
4. Context is chunked and optionally truncated by `context_window` from the LLM profile.
5. For each **model** in `models`, the service builds a brain (Ollama vs cloud from profile + API key), wraps it in `TracingBrainWrapper` (for JSON/thought extraction), and calls `GoldenDatasetGenerator(brain, strategy).create_exam(ask_count, persona=..., technique=...)` in a loop until `count` questions or retries are exhausted. New questions are deduped (e.g. by similarity).
6. Resulting turns are merged. Artifact is built with `teacher_configuration`, `context_info`, `question_set.turns`, then written to `TEACHER_DIR/<folder_name>/Teacher_<prefix>_<timestamp>_<run_id_6>.json`. Folder/prefix come from `source_metadata.source_type` (e.g. single_doc → SingleDoc/SDOC, discovery → Discovery/DISC, project → Project/PROJ).

### 3.3 Teacher Config

- **`layer1_config.json`:** `personas` (e.g. Auditor, Consultant, Adversarial) with `system_prompt`, `description`, `complexity`; `modes` and `allowed_strategies` per mode.
- **`domain_profiles.json`:** Domain name, reasoning style, ontology keywords, hallucination traps, system prompt extras; keyed by request `domain`.
- **`llm_profiles.json`:** Used to resolve each entry in `models` to provider, model_name, api_key_env, base_url, context_window. Cloud keys from `load_api_keys()` (secrets + env).

### 3.4 Teacher Output (Artifact)

- **Path:** `data/Teacher/<mode>/Teacher_<prefix>_<timestamp>_<run_id>.json`.
- **Content:** `run_id`, `created_at`, `teacher_configuration` (mode, model, document_title, document_id, documents, topic, project_name, domain_profile), `context_info` (source_type, document_ids, document_metadata), `question_set.turns` (question, expected_answer, supporting_quote, source_ref, generator_model, etc.). This file is the **reference** for Examiner and Judge.

---

## 4. Layer 2 – Examiner (How It Works)

### 4.1 Purpose

Take a **Teacher output file** (by filename), run each question against **CORA** via the CORA SDK, and write a **candidate transcript** (Q + CORA answers + evidence/citations) to `data/Examiner/<mode>/`.

### 4.2 Modules and Flow

| Component | Location | Role |
|-----------|----------|------|
| **Router** | `api/routers/examiner.py` | `POST /examiner/run_batch` with `l1_filename`; lists artifacts/results. |
| **Service** | `services/examiner_service.py` | Finds Teacher file under `TEACHER_DIR`, loads JSON, builds SDK `Config`, injects credentials from secrets, authenticates with CORA, fetches OpenAPI, builds project map (for PCT), iterates **run units**, runs the correct mode (discovery / pct / document / user_document), then **hydrates** missing grounding text in the written JSON. |
| **CORA SDK** | `layer2_harness/cora_sdk/` | Config, auth, OpenAPI, threads, projects, LLM (streaming), grounding. **Runner:** `runner/spec.py` (e.g. `iter_run_units`), `runner/modes.py` (e.g. `run_discovery`, `run_pct`, `run_document`, `run_user_document`), `runner/results.py` (`init_run_log`, `write_run_log`). |

**Flow in code:**

1. **Resolve Teacher file:** Walk `TEACHER_DIR` to find `l1_filename`; load spec JSON.
2. **SDK config:** `Config()` from `cora_sdk.config`; credentials from `secrets.json` (`cora_dev` or `cora`) injected (username, password, base_url).
3. **Auth:** `login(sess, cfg)`; if no token/cookies, service raises (CORA auth failed).
4. **OpenAPI:** `fetch_openapi(sess, token, cfg)` for API version and structure.
5. **Run units:** If spec has `threads` or `question_sets`, `iter_run_units(spec)` returns unit dicts. Else the service builds one unit from `question_set.turns` (or `data`), infers mode from filename (PROJ/SDOC/USER/DISC) and uses `context_info` for document_ids, version_name, project_id.
6. **Per unit:** Mode folder is chosen (`EXAMINER_MODE_FOLDERS`: discovery→Discovery, pct→PCT, document→Document, user_document→UserDoc). `cfg.results_dir = EXAMINER_DIR/<mode_folder>`. Questions normalized to strings; custom prompts merged. For **PCT**, project_id is resolved or a unique run project is created and documents attached. Then:
   - **Discovery:** `run_discovery(sess, token, cfg, name, questions, project_id, custom_prompts, openapi, openapi_version)`
   - **PCT:** `run_pct(..., project_id=pid, ...)`
   - **Document:** `run_document(..., document_id, version_name, language, ...)`
   - **User document:** `run_user_document(..., document_id, version_name, ...)`
7. **Inside runner (modes.py):** Common path is `run_mode_questions`: create or reuse thread, then for each question call CORA (e.g. `ask_llm_stream`), parse answer/links/grounding, optionally resolve grounding sources via API, append turn to run_log. `write_run_log(cfg, thread_name, run_log)` writes one JSON file per run to `cfg.results_dir`.
8. **Hydration:** After all units, `_hydrate_missing_text` scans Examiner output files for the run and, for turns where grounding chunks have no text, can call `resolve_grounding_sources_cached` to fill text. It also writes `teacher_source` / `teacher_run_id` into the Examiner JSON for traceability.

### 4.3 Examiner Output (Candidate File)

- **Path:** `data/Examiner/<Discovery|PCT|Document|UserDoc>/<thread_name>.json`.
- **Content:** run_id, created_at, question_set name, mode, thread info, document info, **turns** (question, `resp` with answer_text, links, grounding_sources, grounding_sources_details). This file is the **candidate** input for the Judge.

---

## 5. Layer 3 – Judge (How It Works)

### 5.1 Purpose

Take a **candidate file** (Examiner output) and a **reference file** (Teacher output), align turns by index, and for each turn call an **LLM** to score accuracy, grounding, completeness, and safety. Write one **report** JSON to `data/Judge/<mode>/`.

### 5.2 Modules and Flow

| Component | Location | Role |
|-----------|----------|------|
| **Router** | `api/routers/judge.py` | `POST /judge/run` (candidate_file, teacher_file, model_name); list artifacts, results; get report/artifact content. |
| **Service** | `services/judge_service.py` | Load candidate and teacher from `EXAMINER_DIR` and `TEACHER_DIR` by relative path; extract turns; build run_context and domain_profile from teacher artifact; for each turn build prompt (question, reference answer, student answer, student evidence); call Judge LLM; parse JSON verdict (score, metrics, reasoning, failure_category); aggregate scores; write report. |

**Flow in code:**

1. **Load files:** `_load_json_file(EXAMINER_DIR, candidate_file)` and `_load_json_file(TEACHER_DIR, teacher_file)`. Paths are relative (e.g. `Discovery/cora_Auto_....json`, `Discovery/Teacher_DISC_....json`).
2. **Turns:** Candidate turns from `turns` or `results` (or root list); reference turns from `question_set.turns` or `data`.
3. **Judge LLM:** Profile for `model_name` from `llm_profiles.json`; provider (ollama vs openai/anthropic/gemini); API key from secrets/env. `LLMCaller` from `axiom_core.llm` is built with provider, model, temperature, base_url, api_key.
4. **Per turn:** Build prompt with question, reference answer, candidate answer, and candidate evidence (from grounding_sources_details / grounding_sources / links). Ask for JSON: score (0–10), metrics (accuracy, grounding, completeness, safety), reasoning, **failure_category** (NONE | HALLUCINATION | MISSING | SAFETY). Response is cleaned (strip `<think>` blocks, extract JSON) and appended to `evaluations`.
5. **Report:** run_id, created_at, candidate_file, teacher_file, judge_model, run_context (mode, title, description, teacher_model, documents), teacher_configuration, context_info, domain_profile, total_turns, average_score, **details** = list of per-turn evaluations. Folder under JUDGE_DIR is inferred from run_context.mode (Single→SingleDoc, Project/PCT→Project, Discovery/Topic→Discovery, User→UserDoc; else Root). Filename: `Judge_Report_YYYYMMDD_HHMM_<run_id_4>.json`.

---

## 6. MongoDB – Document Library

### 6.1 Role

- **Teacher:** When the user selects documents by ID, the Teacher service fetches document content from MongoDB to use as context for question generation. Without MongoDB, Teacher can still run with **context**-only (no document IDs).
- **Interrogator / UI:** Document library listing and "pick a document" flows use MongoDB for metadata and content.

### 6.2 Two Access Paths

| Path | File | When used |
|------|------|-----------|
| **API / Teacher** | `api/dependencies.py` → `MongoHelper` | Teacher router and TeacherService. Loads `mongo_config.json`; `active_profile` (e.g. dev) selects profile; URI from `SECRETS["mongo_uri"]` or env (e.g. `MONGO_URI`). Collection: `db[collection_name]` (e.g. `documents`). |
| **Document library / scripts** | `mongo_loader.py` | Same `mongo_config.json` and `active_profile`; URI from same env. Exposes `get_mongo_client()`, `is_mongo_available()`, `fetch_document_library_index(search_query)`, `get_document_content(doc_id)`, `find_document_hierarchy(cora_id)`. |

If `MONGO_URI` (or the profile's URI env) is not set, the app does **not** connect to MongoDB; Teacher then requires **context** only (no document IDs).

### 6.3 MongoHelper (dependencies.py)

- **Document fetch:** `get_doc(doc_id)` finds a document by id / _id / UUID / ObjectId, then uses `_scavenge_text(doc)` to get the main text (root keys like `text`, `content`, `full_text`; or `consolidated_versions` with language preference; or recursive fallback). Also returns chunks, extraction_logs, _raw, document_meta, source_info.
- **Search:** `search(query)` does a simple regex on title/content/id for listing.

### 6.4 Config

- **`mongo_config.json`:** `active_profile` (e.g. `"dev"`), `profiles`: each has `uri_env_var`, `db_name`, `collection_name`. Example: dev uses `MONGO_URI`, `corax-dev`, `documents`. Documents are expected to have at least id/_id, title/document_name, and content/text/full_text (or equivalent used by _scavenge_text).

---

## 7. External and Local LLMs

### 7.1 Where It's Used

- **Teacher:** One or more LLM profiles (from request `models`) to generate questions.
- **Judge:** One LLM profile to grade each turn.
- **Interrogator:** One LLM profile to generate follow-up questions in the viva.
- **System/chat:** Optional simple chat using a chosen profile.

### 7.2 Profile Config: `llm_profiles.json`

- **Location:** `src/config/llm_profiles.json`.
- **Structure:** Top-level `active_profile` (default for UI); `profiles` is a map: profile id → `{ display_name, provider, model_name, api_key_env, base_url, description, ... }`.
- **Provider:** `ollama` (local), `openai`, `anthropic`, `gemini`, etc.

### 7.3 How the App Calls LLMs

- **Shared client:** `src/axiom_core/llm/`:
  - `generate(prompt, system_prompt=..., provider, model, temperature, base_url, api_key)` – used by Teacher brains and Judge. For Ollama: POST to `base_url/api/generate` (single merged prompt). For OpenAI/Anthropic: uses their SDK with api_key.
  - `LLMCaller` – thin wrapper holding provider/model/temperature/base_url/api_key and exposing `generate(prompt, system_prompt)`.
  - `LLMClient` (profile_client.py) – loads `llm_profiles.json`, exposes `generate_completion(model_id, prompt, system_prompt)` (Ollama `/api/chat`, OpenAI placeholder).
- **Teacher:** Service reads `LLM_PROFILES["profiles"][model_key]`; if provider is cloud, gets API key from `load_api_keys()` or env (`api_key_env`); builds `OpenSourceTeacher` or `PremiumTeacher`; both use `axiom_core.llm.generate`.
- **Judge:** Same: profile → provider, model_name, api_key_env, base_url; API key from secrets/env; builds `LLMCaller` and calls `generate` for each turn.
- **Interrogator:** Uses same LLM profile + `LLMCaller` to generate the next question in the viva.

### 7.4 API Keys and Env

- **Cloud:** Keys in `src/config/secrets.json` under `openai`, `anthropic`, `gemini`, or set via env (e.g. `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`). Profile's `api_key_env` can point to a key name in secrets or an env var.
- **Local (Ollama):** No key; `base_url` (e.g. `http://localhost:11434`). Model must be pulled (e.g. `ollama run llama3`). If Ollama is down or model missing, the profile shows as unavailable in the UI.

---

## 8. Interrogator (Layer 2a)

- **Purpose:** Interactive session where an LLM (Interrogator) asks CORA questions; user can send messages and get CORA's answers; session can be saved for later Judge evaluation.
- **Router:** `api/routers/interrogator.py` – session start (mode, doc_id, model_id, topic_text), chat (question + session_context), next-question (LLM suggests next question). Uses same CORA SDK (threads, `ask_llm_stream`) and same secrets for CORA; same LLM profile/client for the Interrogator model.
- **Config:** `layer2a_config.json`; LLM from `llm_profiles.json`. Saved sessions go under `VIVA_DIR` or similar for later use as "candidate" input to Judge when format is compatible.

---

## 9. End-to-End Data Flow Summary

| Step | Input | Output | Handoff |
|------|--------|--------|---------|
| 1. Teacher | Document IDs (MongoDB) or context; domain, persona, technique, count, models | `data/Teacher/<mode>/Teacher_<prefix>_<ts>_<id>.json` | **Filename** (e.g. returned in API response). |
| 2. Examiner | Teacher **filename** (and optional cora_config, project_id, cora_model) | `data/Examiner/<mode>/<thread_name>.json` | **Relative path** (e.g. `Discovery/cora_Auto_....json`) + optional teacher_source in JSON. |
| 3. Judge | **candidate_file** (relative under Examiner), **teacher_file** (relative under Teacher), **model_name** | `data/Judge/<mode>/Judge_Report_<date>_<time>_<id>.json` | Report JSON contains `candidate_file` and `teacher_file`. |
| 4. Evaluation UI | `GET /judge/results` then `GET /judge/report?path=<rel_path>` | Display / PDF | Path is relative to `data/Judge`. |

No DB stores these links; the filesystem and the paths inside the Judge report are the only durable connection between Teacher, Examiner, and Judge outputs.

---

## 10. Quick Reference – Key Files

| Concern | Files |
|--------|--------|
| Paths & env | `src/axiom_core/api/dependencies.py` |
| Teacher pipeline | `services/teacher_service.py`, `layer1_teacher/generator.py`, `layer1_teacher/brains.py`, `layer1_teacher/strategies.py` |
| Examiner pipeline | `services/examiner_service.py`, `layer2_harness/cora_sdk/runner/modes.py`, `runner/spec.py`, `runner/results.py` |
| Judge pipeline | `services/judge_service.py`, `api/dependencies.LLM_PROFILES` + `axiom_core.llm` |
| LLM calls | `src/axiom_core/llm/__init__.py`, `llm/profile_client.py` |
| MongoDB (API/Teacher) | `api/dependencies.MongoHelper`, `mongo_config.json` |
| MongoDB (library) | `mongo_loader.py`, `mongo_config.json` |
| Config | `src/config/layer1_config.json`, `domain_profiles.json`, `llm_profiles.json`, `mongo_config.json`, `secrets.json` |
| Artifact shapes | `src/axiom_core/artifacts.py` (Pydantic models for Teacher/Examiner/Judge) |

---

## See also

- **[DATA_FLOW_AND_ARTIFACTS.md](DATA_FLOW_AND_ARTIFACTS.md)** – Data directory layout, Teacher/Examiner/Judge folder and filename rules, API endpoints, JSON artifact schemas, Evaluation tab, persistence.
- **[LLM_PROFILES_README.md](LLM_PROFILES_README.md)** – LLM setup (Ollama, cloud API keys, profile editing).
