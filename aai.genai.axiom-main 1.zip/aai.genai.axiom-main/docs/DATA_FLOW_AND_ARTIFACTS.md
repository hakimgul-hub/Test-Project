# AXIOM Data Flow: Teacher → Examiner → Judge → Evaluation Reports

This document describes the **end-to-end flow** of artifacts in AXIOM: where files are generated, where they are stored, and how each module consumes the output of the previous one. It focuses on **file layouts, filename conventions, API endpoints, and JSON artifact structures**. For implementation detail (modules, code flow, MongoDB, LLMs), see **[AXIOM_TECHNICAL_OVERVIEW.md](AXIOM_TECHNICAL_OVERVIEW.md)**.

---

## 1. High-Level Flow

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│  LAYER 1: TEACHER                                                                       │
│  Input: Documents (MongoDB) or context, domain, persona, LLM profile                    │
│  Output: Question set (Q + expected answers) → saved under data/Teacher/<mode>/         │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                          │
                                          │ filename e.g. Teacher_SDOC_2026-02-06_16h36_26_65bd33.json
                                          ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│  LAYER 2: EXAMINER                                                                      │
│  Input: Teacher JSON file (by filename), CORA credentials, run mode                     │
│  Output: Candidate transcript (Q + student answers + evidence) → data/Examiner/         │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                          │
                                          │ candidate_file (e.g. cora_Auto_discovery_*.json)
                                          │ teacher_file (relative path, e.g. Discovery/Teacher_*.json)
                                          ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│  LAYER 3: JUDGE                                                                         │
│  Input: Candidate file + Teacher (reference) file, Judge LLM profile                    │
│  Output: Evaluation report (scores, metrics, verdicts) → data/Judge/<mode>/             │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                          │
                                          │ Judge_Report_YYYYMMDD_HHMM_<run_id>.json
                                          ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│  EVALUATION TAB (UI)                                                                    │
│  Input: List from GET /judge/results, report content from GET /judge/report?path=...    │
│  Output: View reports, filter by mode, export PDF                                       │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Data Directory Layout

All persistent artifacts live under the **repository data directory**: `data/` (or `Data/` if that exists). Path is resolved in each router from `PROJECT_ROOT`.

| Path | Purpose |
|------|--------|
| `data/Teacher/` | Teacher (Layer 1) outputs: question sets with expected answers. Subfolders by mode. |
| `data/Examiner/` | Examiner (Layer 2) outputs: candidate transcripts (CORA answers + evidence). Flat or in subfolders. |
| `data/Judge/` | Judge (Layer 3) outputs: evaluation reports. Subfolders by inferred mode. |
| `data/temp_uploads/` | Temporary uploads (e.g. system router). |

### 2.1 Teacher Folders

Teacher saves by **source type** (from `req.source_metadata.source_type`):

| `source_type` (request) | Folder | Filename prefix | Example |
|-------------------------|--------|-----------------|---------|
| `single_doc` | `Teacher/SingleDoc/` | `Teacher_SDOC_` | `Teacher_SDOC_2026-02-06_16h36_26_65bd33.json` |
| `project` | `Teacher/Project/` | `Teacher_PROJ_` | `Teacher_PROJ_2026-02-01_02h29_07_58bdf2.json` |
| `discovery` (default) | `Teacher/Discovery/` | `Teacher_DISC_` | `Teacher_DISC_2026-02-01_02h27_37_a3f911.json` |
| `user_doc` / `user_document` | `Teacher/UserDoc/` | `Teacher_UDOC_` | `Teacher_UDOC_2026-02-01_12h00_00_abc123.json` |

- **Filename format:** `Teacher_<prefix>_<timestamp>_<run_id_6chars>.json`
- **Timestamp:** `%Y-%m-%d_%Hh%M_%S` (e.g. `2026-02-06_16h36_26`)

### 2.2 Examiner Output Location

- **Structured folders:** Examiner writes into **`data/Examiner/<mode_folder>/`** so that Discovery, PCT, Document, and User Doc runs are separated:
  - **Discovery** → `data/Examiner/Discovery/`
  - **PCT (project)** → `data/Examiner/PCT/`
  - **Single document** → `data/Examiner/Document/`
  - **User document** → `data/Examiner/UserDoc/`
- **SDK:** `layer2_harness/cora_sdk/runner/results.py` → `write_run_log(cfg, thread_name, run_log)` writes to `cfg.results_dir / {safe_filename(thread_name)}.json`; the service sets `cfg.results_dir` per run to the mode subfolder above.

### 2.3 Judge Folders

Judge chooses folder from **run_context.mode** (inferred from Teacher + Candidate):

| Inferred mode | Folder |
|---------------|--------|
| Contains "Single" | `Judge/SingleDoc/` |
| Contains "Project" or "PCT" | `Judge/Project/` |
| Contains "Discovery" or "Topic" | `Judge/Discovery/` |
| Contains "User" | `Judge/UserDoc/` |
| **Unrecognized / legacy** | **`Judge/Root/`** |

- **Filename format:** `Judge_Report_<YYYYMMDD>_<HHMM>_<run_id_4chars>.json`

---

## 3. Layer 1: Teacher (Detail)

### 3.1 Entry Point

- **API:** `POST /generate` (Teacher router mounted at root; no `/teacher` prefix).
- **UI:** TeacherTab → `POST http://localhost:8000/generate`.

### 3.2 Inputs (Request Body)

- **Source:** Document IDs from MongoDB (`source_metadata.id`), or free-form `context`.
- **Config:** `models` (LLM profile ids), `domain`, `persona`, `technique`, `count`, `source_metadata` (e.g. `source_type`, `topic`, `project_name`).

### 3.3 Config Used

- **LLM:** `src/config/llm_profiles.json` → `profiles[model_key]` (provider, model_name, api_key_env, context_window). Cloud keys from `secrets.json` or env.
- **Domain:** `src/config/domain_profiles.json` → `DOMAIN_PROFILES.get(req.domain)` (name, reasoning_style, ontology_keywords, hallucination_traps, system_prompt_extras).
- **Layer1:** `src/config/layer1_config.json` (personas, modes, etc.).

### 3.4 Output Artifact (Saved File)

Written to: `data/Teacher/<folder_name>/Teacher_<prefix>_<timestamp>_<run_id_6>.json`

**Structure (relevant for downstream):**

```json
{
  "run_id": "uuid",
  "created_at": "ISO datetime",
  "teacher_configuration": {
    "mode": "Human readable mode",
    "model": "profile id",
    "document_title": "...",
    "document_id": "...",
    "documents": [...],
    "topic": "...",
    "project_name": "...",
    "domain_profile": { ... }
  },
  "context_info": {
    "source_type": "SingleDoc|Discovery|Project",
    "document_ids": [...],
    "document_metadata": [...]
  },
  "question_set": {
    "turns": [
      {
        "question": "...",
        "expected_answer": "...",
        "supporting_quote": "...",
        "source_ref": { ... }
      }
    ]
  }
}
```

- **Returned to client:** `{"status": "Success", "filename": "<filename>", "data": merged_results}`. The **filename** is used by the Examiner (and UI) to select the Teacher run.

---

## 4. Layer 2: Examiner (Detail)

### 4.1 Entry Point

- **API:** `POST /examiner/run_batch` (Examiner router, prefix `/examiner`).
- **UI:** ExaminerTab → `POST http://localhost:8000/examiner/run_batch`.

### 4.2 Inputs

- **Teacher file:** `l1_filename` (e.g. `Teacher_SDOC_2026-02-06_16h36_26_65bd33.json`). The router **searches** `data/Teacher/` recursively to find this file.
- **Optional:** `cora_config`, `project_id`, `cora_model`.

### 4.3 Where It Reads From

- **Teacher JSON:** Resolved by walking `os.path.join(DATA_DIR, "Teacher")` until `req.l1_filename` is found; then loaded and parsed.
- **CORA:** Credentials from `src/config/secrets.json` (or `config/secrets.json`) under `cora_dev` / `cora`; injected into SDK `Config`. The service sets `cfg.results_dir` to `data/Examiner/<mode_folder>/` (Discovery, PCT, Document, or UserDoc) per run.

### 4.4 Output Artifact (Candidate File)

- **Written by:** `layer2_harness/cora_sdk/runner/results.py` → `write_run_log(cfg, thread_name, run_log)`.
- **Path:** `data/Examiner/<mode_folder>/<thread_name>.json`, where `<mode_folder>` is one of `Discovery`, `PCT`, `Document`, or `UserDoc` (see §2.2). The service sets `cfg.results_dir` to that subfolder before each run.
- **Content:** Run log with `turns` (or `results`) per question: candidate answer, evidence, thread/document info. After the run, **hydration** (`_hydrate_missing_text`) may add or link `teacher_source` / `teacher_run_id` into Examiner outputs for traceability.

**Structure (what Judge expects):**

- `turns` or `results`: list of items with at least:
  - `question`
  - Answer content (e.g. `answer`, `candidate_answer`, or from stream)
  - Evidence (e.g. grounding sources, citations)

### 4.5 Listing Teacher Files (for UI)

- **API:** `GET /examiner/artifacts` → lists Teacher files under `data/Teacher/` (with mode, question_count, created_at).
- **API:** `GET /examiner/results` → lists Examiner output files under `data/Examiner/`.

---

## 5. Layer 3: Judge (Detail)

### 5.1 Entry Point

- **API:** `POST /judge/run` with body `JudgeRunRequest`: `candidate_file`, `teacher_file`, `model_name`.
- **UI:** JudgeTab → selects candidate + reference (Teacher), then `POST http://localhost:8000/judge/run`.

### 5.2 Inputs (Files)

- **Candidate (student):** `candidate_file` = **relative path** under `data/Examiner/` (e.g. `cora_Auto_discovery_a845_2026-02-01_15-43-33_6dc68f.json` or `Discovery/cora_Auto_document_0cfe_....json`).
- **Reference (ground truth):** `teacher_file` = **relative path** under `data/Teacher/` (e.g. `Discovery/Teacher_DISC_2026-02-01_02h27_37_a3f911.json`).

Paths are **relative** because the API scans recursively and returns `relative_path`; the Judge then does:

- `candidate_data = _load_json_file(os.path.join(DATA_DIR, "Examiner"), req.candidate_file)`
- `teacher_data = _load_json_file(os.path.join(DATA_DIR, "Teacher"), req.teacher_file)`

### 5.3 Config Used

- **Judge LLM:** `src/config/llm_profiles.json` → `profiles[model_name]` (provider, model_name, api_key_env). Same as Teacher for cloud/ollama.
- **Domain profile:** Taken from Teacher artifact (`teacher_configuration.domain_profile` or `context_info.domain_profile`) and passed into the Judge prompt/rubric.

### 5.4 Output Artifact (Report)

Written to: `data/Judge/<folder_name>/Judge_Report_<YYYYMMDD>_<HHMM>_<run_id_4>.json`

**Structure (used by Evaluation tab):**

```json
{
  "run_id": "uuid",
  "created_at": "ISO datetime",
  "candidate_file": "relative path to Examiner file",
  "teacher_file": "relative path to Teacher file",
  "judge_model": "resolved model name",
  "run_context": { "mode", "title", "description", "teacher_model", "documents" },
  "teacher_configuration": { ... },
  "context_info": { ... },
  "domain_profile": { ... },
  "total_turns": 50,
  "average_score": 5.48,
  "details": [
    {
      "turn_index": 0,
      "question": "...",
      "candidate_answer": "...",
      "reference_answer": "...",
      "score": 8.5,
      "metrics": { "accuracy", "grounding", "completeness", "safety" },
      "judge_verdict": "...",
      "failure_category": "NONE|HALLUCINATION|...",
      "student_evidence": [ ... ],
      "teacher_context": "..."
    }
  ]
}
```

### 5.5 Judge API Endpoints (File Discovery & Content)

- **GET /judge/artifacts** → `{"candidates": [...], "references": [...]}`. Scans `data/Examiner` and `data/Teacher` recursively; each item has `filename`, `relative_path`, `type`, `folder`, `created_at`.
- **GET /judge/results** → list of Judge report entries (same structure: `filename`, `relative_path`, etc.) from `data/Judge`.
- **GET /judge/report?path=<relative_path>** → full JSON of one report. Path is relative to `data/Judge` (e.g. `Root/Judge_Report_20260206_1741_16a3.json`).
- **GET /judge/artifact_content?path=<path>** → content of a **candidate** (Examiner) file; used by UI for deep auto-matching (e.g. run_id) to suggest Teacher file.

---

## 6. Evaluation Tab (UI)

- **Report list:** `GET /judge/results` → list of Judge reports (with `relative_path`, `folder`, etc.).
- **Filter:** By mode (all, SingleDoc, Discovery, Project, UserDoc) using `item.folder`.
- **Load report:** `GET /judge/report?path=<relative_path>` → full report JSON.
- **Display:** Uses `average_score`, `details`, `teacher_configuration`, `context_info`, `domain_profile`, `candidate_file`, `teacher_file`, etc. PDF export uses the same report object (and optional logo assets from `GET /judge/assets/logos`).

---

## 7. Configuration Summary

| Config File | Used By | Purpose |
|-------------|---------|---------|
| `src/config/llm_profiles.json` | Teacher, Judge, Interrogator, System | LLM profiles (provider, model_name, api_key_env, base_url, judge_configuration). |
| `src/config/domain_profiles.json` | Teacher, Judge (via Teacher artifact) | Domain name, reasoning_style, ontology_keywords, hallucination_traps, system_prompt_extras. |
| `src/config/layer1_config.json` | Teacher, System | Personas, modes, strategies for Layer 1. |
| `src/config/secrets.json` | Examiner, System | CORA credentials (cora_dev), API keys (openai, anthropic, gemini). |
| `src/config/mongo_config.json` | dependencies.py | MongoDB connection (active_profile, uri_env_var, db_name, collection_name). |
| `.env` (repo root) | dependencies (load_dotenv), scripts | MONGO_URI, CORA_*, OPENAI_API_KEY, etc. |

- **DATA_DIR** is set in multiple routers and in `dependencies.py`: `data/` if it exists, else `Data/`.
- **CONFIG_DIR** = `src/config` (from dependencies). Secrets and LLM/domain configs are loaded at startup.

---

## 8. Quick Reference: API Endpoints

| Method | Endpoint | Role |
|--------|----------|------|
| POST | `/generate` | Teacher: generate question set → save to `data/Teacher/<mode>/`. |
| GET | `/examiner/artifacts` | List Teacher files (for Examiner/Judge UI). |
| GET | `/examiner/results` | List Examiner (candidate) files. |
| POST | `/examiner/run_batch` | Run Examiner using a Teacher file → write to `data/Examiner/`. |
| GET | `/judge/artifacts` | List candidates + references (Examiner + Teacher). |
| GET | `/judge/results` | List Judge reports. |
| GET | `/judge/report?path=` | Get one Judge report JSON. |
| GET | `/judge/artifact_content?path=` | Get candidate file content (for auto-matching). |
| POST | `/judge/run` | Run Judge → save report to `data/Judge/<mode>/`. |
| GET | `/config/llms` | LLM profiles for dropdowns. |
| GET | `/config/layer1` | Layer1 config (strategies, personas, modes). |
| POST | `/projects/init` | Create project with CELEX IDs (Projects router). |

---

## 9. Connection Summary

- **Teacher → Examiner:** Examiner run is triggered with **Teacher filename**; backend finds that file under `data/Teacher/` and uses its `question_set.turns` to drive CORA. Output is written to `data/Examiner/`.
- **Examiner → Judge:** User (or UI) selects a **candidate file** (Examiner output) and a **reference file** (Teacher output). Judge loads both by relative path, aligns turns, and grades. Report is written to `data/Judge/`.
- **Judge → Evaluation Tab:** Tab lists reports via `/judge/results` and loads each report via `/judge/report?path=...`. All persisted fields (teacher_configuration, context_info, domain_profile, details) come from the Judge report JSON.

No database stores these artifact links; the **file system** and **relative paths** in the Judge report (`candidate_file`, `teacher_file`) are the only durable links between Teacher, Examiner, and Judge outputs.

---

## 10. Persistence & path source

- **Single path source:** All API writers (Teacher, Examiner, Judge) use the directories defined in **`src/axiom_core/api/dependencies.py`**: `TEACHER_DIR`, `EXAMINER_DIR`, `JUDGE_DIR` (and `DATA_DIR`). There is no second definition of these paths in the API layer.
- **API routers** (Teacher, Examiner, Judge) delegate writing to the **service layer** (`TeacherService.run_generation`, `ExaminerService.run_batch`, `JudgeService.run_evaluation`), which use the same dirs from dependencies. List endpoints (e.g. `/examiner/artifacts`, `/judge/results`) also resolve paths via dependencies.
- **Streamlit UI** uses **`src/axiom_core/persistence.py`**, which imports `TEACHER_DIR`, `EXAMINER_DIR`, `JUDGE_DIR`, `VIVA_DIR` from dependencies and then defines **subfolders** (`L1_DIR = Teacher/Streamlit`, `L2_DIR = Examiner/Streamlit`, etc.) for its own artifacts. So:
  - **API** writes to `data/Teacher/<mode>/`, `data/Examiner/`, `data/Judge/<mode>/`.
  - **Streamlit** (when using persistence) writes to `data/Teacher/Streamlit/`, `data/Examiner/Streamlit/`, `data/Judge/Streamlit/`, `data/Viva/`.
- **System router** lists config and artifacts; it reads from the same `CONFIG_DIR` and does not write pipeline artifacts.

---

## 11. Architecture (API → services → layers)

- **API (FastAPI):** Routers validate requests and return HTTP responses. They delegate core work to the **service layer**.
- **Services** (`src/axiom_core/services/`): `TeacherService`, `ExaminerService`, `JudgeService` orchestrate config loading, strategy/SDK usage, and file writes. They use **artifact models** (`src/axiom_core/artifacts.py`) as the in-memory representation of pipeline outputs (no change to on-disk JSON shape).
- **Shared LLM:** Teacher and Judge (and Interrogator) use the shared **`src/axiom_core/llm/`** client for cloud and local (Ollama) models; API key resolution and fallback are centralized.
- **File-based handoff:** Teacher writes a filename; Examiner is triggered with that filename and writes candidate files; Judge is given candidate + teacher relative paths and writes reports. No DB links—only file paths in the report JSON.

For **module-level and implementation detail** (generator, brains, strategies, CORA SDK runner, Judge prompt flow, MongoDB, LLM profiles), see **[AXIOM_TECHNICAL_OVERVIEW.md](AXIOM_TECHNICAL_OVERVIEW.md)**.

---

## See also

- **[AXIOM_TECHNICAL_OVERVIEW.md](AXIOM_TECHNICAL_OVERVIEW.md)** – Platform concept, how each layer works in code, MongoDB, external/local LLMs, Interrogator, key files.
- **[LLM_PROFILES_README.md](LLM_PROFILES_README.md)** – LLM setup (Ollama, cloud API keys, profile editing).
